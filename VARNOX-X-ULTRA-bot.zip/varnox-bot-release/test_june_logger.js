'use strict';
const assert = require('assert');
const logger = require('./helper/logger');
const captured = [];
const originalLog = console.log;
const originalError = console.error;
console.log = (...args) => captured.push(args.join(' '));
console.error = (...args) => captured.push(args.join(' '));
logger.logInfo('STARTUP', 'logger test');
logger.logSuccess('SESSION', 'connected');
logger.logJune('VARNOX X TECH INC boot sequence starting...');
console.log = originalLog;
console.error = originalError;
assert(captured.length === 3, `expected 3 log lines, got ${captured.length}`);
assert(captured.every(line => line.includes('[ VARNOX ULTRA ]')), 'every line must use June Ultra prefix');
assert(captured.some(line => line.includes('VARNOX X TECH INC boot sequence starting...')), 'startup message missing');
console.log(JSON.stringify({ ok: true, lines: captured }));

process.exit(0);
