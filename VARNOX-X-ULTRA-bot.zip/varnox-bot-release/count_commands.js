'use strict';
const { CMDS } = require('./case');
const bridge = require('./june-compat/bridge');
const native = Object.values(CMDS).flatMap((value) => Array.isArray(value) ? value : []).map(String).map((value) => value.toLowerCase());
const june = bridge.getJuneLoadReport();
const juneMap = bridge.getJuneCategoryMap();
const juneNames = [...new Set([...juneMap.values()].flat().map(String).map((value) => value.toLowerCase()))];
const nativeUnique = new Set(native);
const juneUnique = new Set(juneNames);
const overlap = [...nativeUnique].filter((name) => juneUnique.has(name));
const combinedUnique = new Set([...nativeUnique, ...juneUnique]);
console.log(JSON.stringify({
  nativeEntries: native.length,
  nativeUnique: nativeUnique.size,
  juneCommands: june.commandNames,
  juneUnique: juneUnique.size,
  juneCategories: june.categories,
  overlap: overlap.length,
  combinedUnique: combinedUnique.size,
  juneLoadErrors: june.errors.length,
}, null, 2));
