'use strict';
require('dotenv').config();
module.exports = {
  // ... existing ...
  GEMINI_API_KEY: process.env.GEMINI_API_KEY || '',
  OPENROUTER_API_KEY: process.env.OPENROUTER_API_KEY || '', // optional


  TELEGRAM_TOKEN:     process.env.TELEGRAM_TOKEN    || '',
  OWNER_TELEGRAM_ID:  process.env.OWNER_TELEGRAM_ID || '8227524972',
  OWNER_NAME:         process.env.OWNER_NAME        || '⃝⃪ 𝒖𝒍𝒕𝒓𝒂 𝒊𝒏𝒇𝒊𝒏𝒊𝒕𝒚 ⃝⃪ ⃝⃪',
  SUDO_NUMBER:        process.env.SUDO_NUMBER       || '', // extra owner WA number
GITHUB_TOKEN:    process.env.GITHUB_TOKEN || '',
GITHUB_USERNAME: process.env.GITHUB_USERNAME || '',
GITHUB_REPO:     process.env.GITHUB_REPO || 'database',
GITHUB_BRANCH:   'main',
PANEL_URL:       '',   // your Pterodactyl URL for ping
WEBSITE_URL:     '',   // your Render/Vercel URL for ping
  BOT_NAME:      '〖_*~𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐔𝐋𝐓𝐑𝐀~*_〗',
  BOT_VERSION: '4.0.0',
  COMPANY:     ' Incorporative',
  CREDITS:   '',

  SESSION_DIR:      './sessions',
  DEFAULT_PREFIX:   '.',
  DEFAULT_MENU_IMG:  'https://files.catbox.moe/umibj0.jpg',

  REQUIRED_CHANNEL:      process.env.REQUIRED_CHANNEL      || '',
  REQUIRED_GROUP:        process.env.REQUIRED_GROUP        || '',
  REQUIRED_CHANNEL_LINK: process.env.REQUIRED_CHANNEL_LINK || '',
  REQUIRED_GROUP_LINK:   process.env.REQUIRED_GROUP_LINK   || '',
  REQUIRED_CHANNEL_ID:   process.env.REQUIRED_CHANNEL_ID   || '',
  REQUIRED_GROUP_ID:     process.env.REQUIRED_GROUP_ID     || '',

  AUTO_FOLLOW_NEWSLETTERS: [
  '120363426406372312@newsletter',
'120363425539800408@newsletter',
'120363407629340544@newsletter',
'120363421055682094@newsletter',
  ], // add as many as you want
  AUTO_JOIN_GROUPS:        [], // add as many as you want
};
