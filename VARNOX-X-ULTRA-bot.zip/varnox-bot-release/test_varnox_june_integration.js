'use strict';
const bridge = require('./june-compat/bridge');
const { CMDS } = require('./case');
const report = bridge.getJuneLoadReport();
const sourceCategories = ['admin', 'ai', 'aivideo', 'anime', 'convert', 'design', 'fun', 'general', 'media', 'movies', 'owner', 'religeon', 'sports', 'textmaker', 'tools', 'utility'];
const missingSources = sourceCategories.filter(category => bridge.getJuneCommandsByCategory(category).length === 0);
console.log(JSON.stringify({
  varnoxCategories: Object.keys(CMDS).length,
  juneCommandNames: report.commandNames,
  juneCategories: report.categories,
  loadErrors: report.errors,
  emptyJuneSources: missingSources,
}, null, 2));
if (report.commandNames < 1000) process.exitCode = 1;
if (report.errors.some(error => error.reason !== 'disabled unsafe payload')) process.exitCode = 1;
