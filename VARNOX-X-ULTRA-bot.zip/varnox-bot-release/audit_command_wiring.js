'use strict';

const bridge = require('./june-compat/bridge');
const { CMDS } = require('./case');

const report = bridge.getJuneLoadReport();
const categoryMap = bridge.getJuneCategoryMap();
const juneNames = [...new Set([...categoryMap.values()].flat())];
const missingHandlers = juneNames.filter(name => {
  const command = bridge.getJuneCommand(name);
  return !command || typeof command.execute !== 'function';
});
const emptyCategories = [...categoryMap.entries()]
  .filter(([, commands]) => !Array.isArray(commands) || commands.length === 0)
  .map(([category]) => category);
const nativeCommandCount = Object.values(CMDS)
  .reduce((total, commands) => total + (Array.isArray(commands) ? commands.length : 0), 0);

const result = {
  nativeCategories: Object.keys(CMDS).length,
  nativeCommandEntries: nativeCommandCount,
  juneCategories: categoryMap.size,
  juneUniqueCommandNames: juneNames.length,
  juneRegisteredNames: report.commandNames,
  missingHandlers,
  emptyJuneCategories: emptyCategories,
  loadErrors: report.errors,
};
console.log(JSON.stringify(result, null, 2));

if (missingHandlers.length || emptyCategories.length) process.exitCode = 1;
if (report.errors.some(error => error.reason !== 'disabled unsafe payload')) process.exitCode = 1;
