from pathlib import Path
from PIL import Image

root = Path(__file__).parent / 'menu-images'
for source in sorted(root.glob('varnox-menu-*.png')):
    with Image.open(source) as image:
        image = image.convert('RGB')
        image.thumbnail((960, 1280), Image.Resampling.LANCZOS)
        image.save(source, format='JPEG', quality=86, optimize=True, progressive=True)
    target = source.with_suffix('.jpg')
    source.rename(target)
