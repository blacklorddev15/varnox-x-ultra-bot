# VARNOX X ULTRA Bot Release

This archive contains the complete VARNOX bot source used for the ADMIN 2 deployment. It includes the active command dispatcher, June compatibility bridge and command modules, helper modules, database templates, package manifests, tests, menu-image assets, and maintenance scripts.

The deployment version of `case-routing-fixed.js` is copied as the main `case.js` so the archive starts with the current menu routing, grey-bar styling, vertical command layout, One UI status header, June command integration, and rotating menu-image logic.

Runtime dependencies in `node_modules`, WhatsApp authentication sessions, local logs, `.git` metadata, and environment secret files are intentionally excluded. Install dependencies with `npm install`, copy `.env.example` to `.env` if needed, configure the required values, and start the bot with `npm start`. A fresh WhatsApp session must be paired on the target server.

The two unsafe `antibug` payload entries remain disabled by design.

## Included menu artwork

The optimized VARNOX artwork files are included under `menu-images/` and are selected in rotation by the menu renderer.

## Verification

The source passes Node.js syntax validation. The June compatibility audit reports 1,214 registered names, 469 unique command implementations, 18 loaded categories, no empty categories, and no commands without executable handlers. External API availability and account-specific side effects must still be tested on the target environment.
