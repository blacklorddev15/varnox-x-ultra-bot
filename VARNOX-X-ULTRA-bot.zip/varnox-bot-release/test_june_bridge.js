'use strict';
const bridge = require('./june-compat/bridge');
const report = bridge.getJuneLoadReport();
console.log(JSON.stringify({ commandNames: report.commandNames, categories: report.categories, errors: report.errors.slice(0, 20) }, null, 2));
if (!report.commandNames) process.exitCode = 1;
