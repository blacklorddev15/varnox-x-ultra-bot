'use strict';

const fs = require('fs');
const path = require('path');
const STORE = path.join(__dirname, 'june-settings.json');
const defaults = {
  groups: {}, users: {}, warnings: {}, moderators: {}, badWords: {}, muted: {},
  bot: {}, mode: 'public', antiforward: {}, sessions: {}, status: {},
};
let state;
try { state = { ...defaults, ...JSON.parse(fs.readFileSync(STORE, 'utf8')) }; } catch { state = { ...defaults }; }
function persist() { try { fs.writeFileSync(STORE, JSON.stringify(state, null, 2)); } catch (_) {} }
function key(v) { return String(v || ''); }
function list(bucket, id) { if (!state[bucket][key(id)]) state[bucket][key(id)] = []; return state[bucket][key(id)]; }
function getGroupSettings(id) { return state.groups[key(id)] || {}; }
function updateGroupSettings(id, patch) { state.groups[key(id)] = { ...getGroupSettings(id), ...(patch || {}) }; persist(); return state.groups[key(id)]; }
function getUser(id) { return state.users[key(id)] || {}; }
function updateUser(id, patch) { state.users[key(id)] = { ...getUser(id), ...(patch || {}) }; persist(); return state.users[key(id)]; }
function getWarnings(id) { return list('warnings', id); }
function addWarning(id, user) { const a = list('warnings', id); a.push(key(user)); persist(); return a.length; }
function removeWarning(id, user) { state.warnings[key(id)] = list('warnings', id).filter(x => x !== key(user)); persist(); return state.warnings[key(id)].length; }
function clearWarnings(id) { state.warnings[key(id)] = []; persist(); }
function getModerators(id) { return list('moderators', id); }
function addModerator(id, user) { const a = list('moderators', id); if (!a.includes(key(user))) a.push(key(user)); persist(); return true; }
function removeModerator(id, user) { state.moderators[key(id)] = list('moderators', id).filter(x => x !== key(user)); persist(); return true; }
function isModerator(id, user) { return getModerators(id).includes(key(user)); }
function getBadWords(id) { return list('badWords', id); }
function addBadWord(id, word) { const a = list('badWords', id); if (!a.includes(key(word))) a.push(key(word)); persist(); return true; }
function removeBadWord(id, word) { state.badWords[key(id)] = list('badWords', id).filter(x => x !== key(word)); persist(); return true; }
function muteUser(id, user) { const a = list('muted', id); if (!a.includes(key(user))) a.push(key(user)); persist(); return true; }
function unmuteUser(id, user) { state.muted[key(id)] = list('muted', id).filter(x => x !== key(user)); persist(); return true; }
function isUserMuted(id, user) { return list('muted', id).includes(key(user)); }
function getMutedUsers(id) { return list('muted', id); }
function getBotSetting(name) { return state.bot[key(name)]; }
function setBotSetting(name, value) { state.bot[key(name)] = value; persist(); return value; }
function getAllBotSettings() { return { ...state.bot }; }
function updateBotSettings(patch) { state.bot = { ...state.bot, ...(patch || {}) }; persist(); return state.bot; }
function getBotMode() { return state.mode; }
function setBotMode(mode) { state.mode = mode; persist(); return mode; }
function getAntiforwardSettings(id) { return state.antiforward[key(id)] || {}; }
function updateAntiforwardSettings(id, patch) { state.antiforward[key(id)] = { ...getAntiforwardSettings(id), ...(patch || {}) }; persist(); return state.antiforward[key(id)]; }
function addAntiforwardWarning() { return 1; }
function getAntiforwardWarningCount() { return 0; }
function clearAntiforwardWarning() {}
function clearAllAntiforwardWarnings() {}
function saveSession(id, data) { state.sessions[key(id)] = data; persist(); }
function getSession(id) { return state.sessions[key(id)]; }
function clearSession(id) { delete state.sessions[key(id)]; persist(); }
function loadSettings() { return { ...state.status }; }
function saveSettings(data) { state.status = { ...state.status, ...(data || {}) }; persist(); return state.status; }
function cleanEmoji(v) { return String(v || '').replace(/[\u200d\ufe0f]/g, ''); }

module.exports = {
  getGroupSettings, updateGroupSettings, getUser, updateUser,
  getWarnings, addWarning, removeWarning, clearWarnings,
  getModerators, addModerator, removeModerator, isModerator,
  getBadWords, addBadWord, removeBadWord,
  muteUser, unmuteUser, isUserMuted, getMutedUsers,
  getBotSetting, setBotSetting, getAllBotSettings, updateBotSettings,
  BOT_SETTINGS_DEFAULTS: {}, getBotMode, setBotMode,
  VALID_BOT_MODES: ['public', 'private', 'self'],
  getAntiforwardSettings, updateAntiforwardSettings,
  addAntiforwardWarning, getAntiforwardWarningCount, clearAntiforwardWarning, clearAllAntiforwardWarnings,
  saveSession, getSession, clearSession, loadSettings, saveSettings, cleanEmoji,
};
