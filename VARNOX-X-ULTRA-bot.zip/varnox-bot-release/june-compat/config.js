'use strict';

const settings = require('../settings');

const ownerNumbers = () => {
  const raw = settings.OWNER_NUMBER || settings.OWNER || settings.OWNER_NUMBERS || '';
  return (Array.isArray(raw) ? raw : String(raw).split(',')).map(v => String(v).replace(/\D/g, '')).filter(Boolean);
};

module.exports = {
  get ownerNumber() { return ownerNumbers(); },
  get ownerJid() { return `${ownerNumbers()[0] || ''}@s.whatsapp.net`; },
  get ownerName() { return settings.OWNER_NAME || settings.BOT_OWNER || 'VARNOX X TECH INC'; },
  get botName() { return settings.BOT_NAME || '𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐓𝐄𝐂𝐇 𝐈𝐍𝐂'; },
  get prefix() { return settings.DEFAULT_PREFIX || '.'; },
  get version() { return settings.BOT_VERSION || settings.VERSION || '1.0.0'; },
  get timezone() { return settings.TIMEZONE || 'Africa/Nairobi'; },
  get mode() { return settings.MODE || 'public'; },
  get packname() { return settings.PACKNAME || 'VARNOX X TECH INC'; },
  get author() { return settings.AUTHOR || 'VARNOX'; },
  sessionName: '',
  sessionID: '',
  selfMode: false,
  defaultGroupSettings: {},
  autoDownload: false,
  autoReact: false,
  autoRead: false,
  autoTyping: false,
  autoSticker: false,
  logs: true,
};
