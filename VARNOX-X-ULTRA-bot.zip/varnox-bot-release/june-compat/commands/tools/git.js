const {
  sendButtons
} = require("gifted-btns");
const {
  applyFont
} = require("../../utils/fontConverter");
const axios = require("axios");
const config = require("../../config");
const fs = require("fs");
const path = require("path");
const os = require("os");
const GITHUB_USER = "Vinpink2";
const GITHUB_REPO = "June-Ultra";
const REPO_URL = "https://github.com/" + GITHUB_USER + "/" + GITHUB_REPO;
const API_URL = "https://api.github.com/repos/" + GITHUB_USER + "/" + GITHUB_REPO;
function extractButtonResponseId(_0x18cf4d) {
  return _0x18cf4d.message?.buttonsResponseMessage?.selectedButtonId || _0x18cf4d.message?.templateButtonReplyMessage?.selectedId || _0x18cf4d.message?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson || null;
}
function getResponseSender(_0x449fd6) {
  return _0x449fd6.key?.participant || _0x449fd6.key?.remoteJid;
}
function buildMainButtons(_0x28620d, _0x21a43f) {
  const _0x249efe = config.prefix || ".";
  return [{
    name: "cta_url",
    buttonParamsJson: JSON.stringify({
      display_text: "🔗 Open Repo",
      url: _0x28620d
    })
  }, {
    name: "cta_copy",
    buttonParamsJson: JSON.stringify({
      display_text: "📋 Copy Repo URL",
      copy_code: _0x28620d
    })
  }, {
    id: _0x249efe + "ghzip_" + _0x21a43f,
    text: "📦 Download ZIP"
  }];
}
module.exports = {
  name: "github",
  aliases: ["repo", "git", "source", "rp", "script"],
  category: "tools",
  description: "Show bot GitHub repository and statistics",
  usage: ".github",
  ownerOnly: false,
  async execute(_0x294c53, _0x291509, _0x4c7321, _0x8e065a) {
    try {
      const _0x4ee75e = _0x8e065a.from;
      const _0x2207cc = config.prefix || ".";
      const _0x1b1bcb = _0x291509.key?.participant || _0x291509.key?.remoteJid;
      const _0x44b3b3 = "Powered by " + config.botName;
      const _0x152b33 = Date.now();
      let _0x4b07ea;
      let _0xa50e01 = REPO_URL;
      let _0x52a5d9 = "main";
      try {
        const {
          data: _0x4dbf92
        } = await axios.get(API_URL, {
          headers: {
            "User-Agent": "June_X_Ultra"
          },
          timeout: 10000
        });
        _0xa50e01 = _0x4dbf92.html_url;
        _0x52a5d9 = _0x4dbf92.default_branch || "main";
        _0x4b07ea = applyFont("┏━━━━━━━━━━━━━━━━\n\n" + ("✧ Repository:  " + _0x4dbf92.name + "\n") + ("✧ Owner:       " + _0x4dbf92.owner.login + "\n") + ("✧ Description: " + (_0x4dbf92.description || "N/A") + "\n") + ("✧ Language:    " + (_0x4dbf92.language || "N/A") + "\n") + ("✧ License:     " + (_0x4dbf92.license?.name || "N/A") + "\n") + ("✧ Branch:      " + _0x52a5d9 + "\n") + ("✧ Visibility:  " + (_0x4dbf92.private ? "🔒 Private" : "🔓 Public") + "\n\n") + "┗━━━━━━━━━━━━━━━━━\n┏━━━━━━━━━━━━━━━━━\n\n⿻ STATISTICS\n" + ("⿻ Stars:       " + _0x4dbf92.stargazers_count.toLocaleString() + "\n") + ("⿻ Forks:       " + _0x4dbf92.forks_count.toLocaleString() + "\n") + ("⿻ Watchers:    " + _0x4dbf92.watchers_count.toLocaleString() + "\n") + ("⿻ Size:        " + (_0x4dbf92.size / 1024).toFixed(2) + " MB\n") + ("⿻ Issues:      " + _0x4dbf92.open_issues_count.toLocaleString() + "\n\n") + "┗━━━━━━━━━━━━━━━━");
      } catch (_0x5f41fd) {
        console.error("[GitHub] API error:", _0x5f41fd.message);
        _0x4b07ea = applyFont("┏━━『 GITHUB REPOSITORY 』━━\n\n" + ("🤖 Bot Name:   " + config.botName + "\n") + ("📁 Repository: " + GITHUB_REPO + "\n") + ("👤 Owner:      " + GITHUB_USER + "\n") + ("🔗 URL:        " + REPO_URL + "\n\n") + "⚠️ Could not fetch live stats.\n   Visit the repo for latest info.\n\n┗━━━━━━━━━━━━━━━━");
      }
      const _0x341624 = path.join(__dirname, "../../utils/menu1.jpg");
      const _0x57613d = fs.existsSync(_0x341624) ? fs.readFileSync(_0x341624) : null;
      await sendButtons(_0x294c53, _0x4ee75e, {
        image: _0x57613d ? {
          buffer: _0x57613d,
          mimetype: "image/jpeg"
        } : undefined,
        text: _0x4b07ea,
        footer: _0x44b3b3,
        buttons: buildMainButtons(_0xa50e01, _0x152b33)
      }, {
        quoted: _0x291509
      });
      const _0x210bae = async _0x4db8f9 => {
        const _0x2e521d = _0x4db8f9.messages[0];
        if (!_0x2e521d?.message) {
          return;
        }
        const _0x4251eb = extractButtonResponseId(_0x2e521d);
        if (!_0x4251eb) {
          return;
        }
        if (_0x4251eb !== _0x2207cc + "ghzip_" + _0x152b33) {
          return;
        }
        if (_0x2e521d.key?.remoteJid !== _0x4ee75e) {
          return;
        }
        const _0x34f391 = getResponseSender(_0x2e521d);
        if (_0x34f391 !== _0x1b1bcb) {
          return;
        }
        _0x294c53.ev.off("messages.upsert", _0x210bae);
        await _0x294c53.sendMessage(_0x4ee75e, {
          react: {
            text: "⏳",
            key: _0x291509.key
          }
        });
        const _0x1b9598 = _0xa50e01 + "/archive/refs/heads/" + _0x52a5d9 + ".zip";
        let _0x5afce3;
        try {
          _0x5afce3 = path.join(os.tmpdir(), GITHUB_REPO + "-" + _0x152b33 + ".zip");
          const _0x2c2a65 = await axios({
            method: "get",
            url: _0x1b9598,
            responseType: "stream",
            timeout: 120000,
            headers: {
              "User-Agent": "June_X_Ultra"
            },
            maxRedirects: 5
          });
          const _0x51ce58 = fs.createWriteStream(_0x5afce3);
          _0x2c2a65.data.pipe(_0x51ce58);
          await new Promise((_0x34bf5d, _0x393f76) => {
            _0x51ce58.on("finish", _0x34bf5d);
            _0x51ce58.on("error", _0x393f76);
          });
          if (!fs.existsSync(_0x5afce3) || fs.statSync(_0x5afce3).size === 0) {
            throw new Error("ZIP download failed — file is empty");
          }
          const _0x326720 = (fs.statSync(_0x5afce3).size / 1048576).toFixed(2);
          await _0x294c53.sendMessage(_0x4ee75e, {
            document: fs.readFileSync(_0x5afce3),
            mimetype: "application/zip",
            fileName: GITHUB_REPO + ".zip",
            caption: applyFont("┏━━『 ZIP DOWNLOADED 』━━\n\n" + ("📁 Repository: " + GITHUB_REPO + "\n") + ("🌿 Branch:     " + _0x52a5d9 + "\n") + ("💾 Size:       " + _0x326720 + " MB\n\n") + "┗━━━━━━━━━━━━━━━━\n\n" + ("> " + config.botName))
          }, {
            quoted: _0x2e521d
          });
          await _0x294c53.sendMessage(_0x4ee75e, {
            react: {
              text: "✅",
              key: _0x291509.key
            }
          });
        } catch (_0x64607b) {
          console.error("[GitHub] ZIP download error:", _0x64607b.message);
          await _0x294c53.sendMessage(_0x4ee75e, {
            react: {
              text: "❌",
              key: _0x291509.key
            }
          });
          await _0x294c53.sendMessage(_0x4ee75e, {
            text: applyFont("┏━━『 ERROR 』━━\n\n❌ Failed: ZIP Download\n" + ("⚠️ Reason: " + _0x64607b.message + "\n\n") + "  Try copying the link instead.\n\n┗━━━━━━━━━━━━━━━━")
          }, {
            quoted: _0x2e521d
          });
        } finally {
          if (_0x5afce3 && fs.existsSync(_0x5afce3)) {
            fs.unlinkSync(_0x5afce3);
          }
        }
      };
      _0x294c53.ev.on("messages.upsert", _0x210bae);
      setTimeout(() => _0x294c53.ev.off("messages.upsert", _0x210bae), 300000);
    } catch (_0x59b87f) {
      console.error("[GitHub] command error:", _0x59b87f);
      await _0x8e065a.reply("❌ Error: " + _0x59b87f.message);
    }
  }
};