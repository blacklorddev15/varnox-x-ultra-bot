'use strict';
const fs = require('fs');
const path = require('path');
const FILE = path.join(__dirname, '..', 'june-group-stats.json');
let data = {};
try { data = JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch (_) {}
function save() { try { fs.writeFileSync(FILE, JSON.stringify(data, null, 2)); } catch (_) {} }
function today() { return new Date().toISOString().slice(0, 10); }
function addMessage(groupId, senderId) {
  if (!groupId || !String(groupId).endsWith('@g.us')) return;
  const g = data[groupId] || (data[groupId] = {});
  const d = g[today()] || (g[today()] = { total: 0, users: {}, hours: {} });
  const user = String(senderId || 'unknown');
  d.total += 1; d.users[user] = (d.users[user] || 0) + 1;
  const hour = String(new Date().getHours()); d.hours[hour] = (d.hours[hour] || 0) + 1;
  save();
}
function allDays(groupId) { return Object.values(data[groupId] || {}); }
function getStats(groupId) { const g = data[groupId] || {}; return g[today()] || null; }
function getActiveUsers(groupId, limit = 15) {
  const totals = {};
  for (const d of allDays(groupId)) for (const [jid, count] of Object.entries(d.users || {})) totals[jid] = (totals[jid] || 0) + count;
  return Object.entries(totals).map(([jid, count]) => ({ jid, count })).sort((a, b) => b.count - a.count).slice(0, limit);
}
function getInactiveUsers(groupId, allParticipants = []) {
  const active = new Set(getActiveUsers(groupId, Number.MAX_SAFE_INTEGER).map(x => x.jid));
  return allParticipants.filter(jid => !active.has(jid));
}
module.exports = { addMessage, getStats, getActiveUsers, getInactiveUsers };
