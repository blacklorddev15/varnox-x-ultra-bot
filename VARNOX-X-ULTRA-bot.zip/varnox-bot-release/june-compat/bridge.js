'use strict';

const fs = require('fs');
const path = require('path');

const COMPAT_ROOT = __dirname;
// June modules use these globals for their original project layout.
global.__ROOT__ = COMPAT_ROOT;
global.__CORE__ = COMPAT_ROOT;

const UNSAFE_DISABLED = new Set([
  // Do not port crash/bug-payload behavior into production.
  'antibug',
]);

const commands = new Map();
const categories = new Map();
const loadErrors = [];

function loadJuneCommands() {
  if (commands.size || loadErrors.length) return;
  const commandsRoot = path.join(COMPAT_ROOT, 'commands');
  if (!fs.existsSync(commandsRoot)) return;
  for (const category of fs.readdirSync(commandsRoot).sort()) {
    const categoryDir = path.join(commandsRoot, category);
    if (!fs.statSync(categoryDir).isDirectory()) continue;
    for (const file of fs.readdirSync(categoryDir).filter(f => f.endsWith('.js')).sort()) {
      const fullPath = path.join(categoryDir, file);
      try {
        const exported = require(fullPath);
        const list = Array.isArray(exported) ? exported : [exported];
        for (const command of list) {
          if (!command || !command.name || typeof command.execute !== 'function') continue;
          const name = String(command.name).toLowerCase();
          if (UNSAFE_DISABLED.has(name)) {
            loadErrors.push({ file, reason: 'disabled unsafe payload' });
            continue;
          }
          commands.set(name, { ...command, _juneCategory: category });
          if (!categories.has(category)) categories.set(category, new Set());
          categories.get(category).add(name);
          for (const alias of command.aliases || []) {
            const normalized = String(alias).toLowerCase();
            if (!UNSAFE_DISABLED.has(normalized)) commands.set(normalized, { ...command, _juneCategory: category });
          }
        }
      } catch (error) {
        loadErrors.push({ file: path.relative(COMPAT_ROOT, fullPath), reason: error.message });
      }
    }
  }
  console.log(`[JUNE] Loaded ${commands.size} command names across ${categories.size} categories.`);
  if (loadErrors.length) console.warn(`[JUNE] Skipped ${loadErrors.length} modules during compatibility load.`);
}

function getJuneCommand(name) {
  loadJuneCommands();
  return commands.get(String(name || '').toLowerCase());
}
function getJuneCommandsByCategory(category) {
  loadJuneCommands();
  return [...(categories.get(category) || [])].sort();
}
function getJuneCategoryMap() {
  loadJuneCommands();
  return new Map([...categories.entries()].map(([key, values]) => [key, [...values].sort()]));
}
function getJuneLoadReport() {
  loadJuneCommands();
  return { commandNames: commands.size, categories: categories.size, errors: [...loadErrors] };
}

async function executeJuneCommand(command, sock, m, args, context) {
  if (!command || typeof command.execute !== 'function') return false;
  const extra = {
    from: context.from,
    sender: context.sender,
    prefix: context.prefix,
    command: context.command,
    isGroup: context.isGroup,
    isOwner: context.isOwner,
    isSudo: context.isSudo,
    isBotAdmin: context.isBotAdmin,
    groupMetadata: context.groupMetadata,
    getCommandCount: () => commands.size,
    reply: context.reply,
    react: context.reaction,
    forwardToSelf: false,
    triggerLabel: context.command,
  };
  await command.execute(sock, m, args, extra);
  return true;
}

module.exports = { getJuneCommand, getJuneCommandsByCategory, getJuneCategoryMap, getJuneLoadReport, executeJuneCommand };
