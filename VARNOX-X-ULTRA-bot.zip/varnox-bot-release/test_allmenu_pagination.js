'use strict';
const fs = require('fs');
const source = fs.readFileSync('./case.js', 'utf8');
const checks = {
  partBuilder: source.includes('function buildAllCommandParts(prefix, totalParts = 3)'),
  partOneRoute: source.includes('allmenu_part1'),
  dynamicPartRoutes: source.includes("`${menuPrefix}allmenu_part${allMenuPart + 1}`") && source.includes("`${menuPrefix}allmenu_part${allMenuPart - 1}`"),
  nextButton: source.includes("btn.reply('next part'"),
  previousButton: source.includes("btn.reply('previous part'"),
  partLabel: source.includes('PART ${allMenuPart}/3'),
};
console.log(JSON.stringify(checks, null, 2));
if (Object.values(checks).some((value) => !value)) process.exitCode = 1;
