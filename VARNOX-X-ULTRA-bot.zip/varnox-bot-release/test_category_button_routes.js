const assert = require('assert');

function normalizeButton(raw, prefix = '.') {
  const lowered = String(raw).trim().toLowerCase();
  const withoutPrefix = prefix && lowered.startsWith(prefix) ? lowered.slice(prefix.length) : lowered;
  const compact = withoutPrefix.replace(/[\s_-]+/g, '');
  const categoryKeys = new Set(['adminmenu', 'aimenu', 'groupmenu']);
  const aliases = {
    all: 'allmenu_part1',
    allmenu: 'allmenu_part1',
    'all menu': 'allmenu_part1',
    groupmenu: 'cat_groupmenu',
    'group menu': 'cat_groupmenu',
    aimenu: 'cat_aimenu',
    'ai menu': 'cat_aimenu',
  };
  const categoryRoute = categoryKeys.has(withoutPrefix) ? `cat_${withoutPrefix}` : (categoryKeys.has(compact) ? `cat_${compact}` : '');
  return withoutPrefix.startsWith('cat_') ? withoutPrefix : (aliases[withoutPrefix] || aliases[compact] || categoryRoute || withoutPrefix);
}

assert.strictEqual(normalizeButton('.allmenu'), 'allmenu_part1');
assert.strictEqual(normalizeButton('all menu'), 'allmenu_part1');
assert.strictEqual(normalizeButton('.cat_groupmenu'), 'cat_groupmenu');
assert.strictEqual(normalizeButton('group menu'), 'cat_groupmenu');
assert.strictEqual(normalizeButton('.aimenu'), 'cat_aimenu');
assert.strictEqual(normalizeButton('AI MENU'), 'cat_aimenu');
assert.strictEqual(normalizeButton('adminmenu'), 'cat_adminmenu');
assert.strictEqual(normalizeButton('ADMIN MENU'), 'cat_adminmenu');
assert.strictEqual(normalizeButton('groupmenu'), 'cat_groupmenu');
console.log('PASS: ALLMENU, GROUPMENU, AIMENU, and generic category routes normalize correctly');

const source = require('fs').readFileSync('case.js', 'utf8');
for (const label of ['buttonAliases', "groupmenu: 'cat_groupmenu'", "aimenu: 'cat_aimenu'", "allmenu: 'allmenu_part1'", 'categoryNameRoute']) {
  assert.ok(source.includes(label), `missing source marker: ${label}`);
}
console.log('PASS: case.js contains the production route normalization');

