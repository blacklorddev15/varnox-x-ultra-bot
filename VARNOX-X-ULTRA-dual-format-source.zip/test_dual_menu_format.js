const fs = require('fs');
const assert = require('assert');

const source = fs.readFileSync(__dirname + '/case-routing-dual.js', 'utf8');
const buttonsSource = fs.readFileSync('/home/ubuntu/fork-audit/blacklord-btns/index.js', 'utf8');

assert(source.includes('function parseVarnoXMenuVariant'), 'menu variant parser is missing');
assert(source.includes("menufast: 'menu'"), 'menufast alias is missing');
assert(source.includes("menu-raw"), 'raw menu documentation/alias is missing');
assert(source.includes('function sendVarnoXRawMenu'), 'raw menu sender is missing');
assert(source.includes('function resolveVarnoXMenuFormat'), 'menu format resolver is missing');
assert(source.includes("if (menuFormat === 'raw')"), 'raw/native selection is missing');
assert(source.includes('messageVersion: 1'), 'native-flow message version is missing');
assert(source.includes("messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 }"), 'native-flow context metadata is missing');
assert(buttonsSource.includes('export async function sendRaw'), 'forked Buttons sendRaw export is missing');
assert(buttonsSource.includes('export async function sendCompatible'), 'forked Buttons sendCompatible export is missing');
assert(buttonsSource.includes('fallbackRaw'), 'forked Buttons raw fallback option is missing');

console.log('dual_menu_format_test=passed');
console.log('native_default=menufast_and_menu');
console.log('raw_override=menuraw_menu-raw_allmenu_raw');
