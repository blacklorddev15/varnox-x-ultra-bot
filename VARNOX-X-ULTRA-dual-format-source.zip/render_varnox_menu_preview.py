from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageOps

W, H = 720, 1600
root = Path('/home/ubuntu/Xeon-/tele-wa-bot')
out = Path('/home/ubuntu/VARNOX-main-menu-pill-preview.png')

def font(size, bold=False):
    paths = [
        '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
        '/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf',
    ]
    for p in paths:
        if Path(p).exists():
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()

img = Image.new('RGB', (W, H), '#0b141a')
d = ImageDraw.Draw(img)
# WhatsApp-like status/header
for y in range(166):
    d.rectangle((0, y, W, y), fill='#0e171d')
d.text((28, 18), '09:49', fill='#eef3f5', font=font(25))
d.text((570, 18), '4G   44%', fill='#eef3f5', font=font(21, True))
d.text((28, 78), '‹', fill='#ffffff', font=font(57))
d.ellipse((94, 74, 157, 137), fill='#b51f2a')
d.text((106, 90), 'VX', fill='#ffffff', font=font(21, True))
d.text((180, 79), 'VARNOX X ULTRA', fill='#f3f4f4', font=font(23, True))
d.text((180, 115), 'online', fill='#c1cbd0', font=font(18))
d.text((665, 80), '⋮', fill='#eef3f5', font=font(40, True))
# subtle chat background
for y in range(166, H):
    d.rectangle((0, y, W, y), fill='#101a20' if y // 36 % 2 else '#111b21')
for y in range(190, H, 110):
    for x in range(10, W, 130):
        d.text((x, y), '⌁', fill='#1b2b31', font=font(31))
# message card
card = (78, 188, 665, 1452)
d.rounded_rectangle(card, radius=14, fill='#202c32')
pad = 28
cx, right = card[0] + pad, card[2] - pad
# distinct VARNOX branding
brand = '_*~𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐔𝐋𝐓𝐑𝐀~*_'
d.text((cx, 216), brand, fill='#f4c7c7', font=font(22, True))
# One UI status header
status = [
    '╭═━⪩ 〖 ONE UI STATUS 〗══━⩵',
    '│⫹⫺ VARNOX X MD: VARNOX 🟢',
    '│⫹⫺ ONE BUILD: 1.0.0',
    '│⫹⫺ DEVICE MODE: public',
    '│⫹⫺ SCREEN TIME: 0d 0h 04m',
    '│⫹⫺ AI TOOLS: 1569',
    '│⫹⫺ QUICK KEY: .',
    '│⫹⫺ VARNOX NETWORK: Incorporative',
    '╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━│⩵',
]
for i, line in enumerate(status):
    d.text((cx, 270 + i * 26), line, fill='#c2cdd0', font=font(16 if i not in (0, 8) else 18, True if i in (0, 8) else False))
# Main menu categories text
start_y = 535
d.text((cx, start_y), '📂  COMMAND CATEGORIES', fill='#f2f4f4', font=font(20, True))
categories = ['01  ADMIN MENU', '02  AI MENU', '03  AI VIDEO MENU', '04  ANIME MENU', '05  CONVERT MENU', '06  DESIGN MENU', '07  GROUP MENU', '08  MEDIA MENU', '09  OWNER MENU', '10  FUN MENU', '11  MUSIC MENU', '12  TOOLS MENU']
for i, item in enumerate(categories):
    row = i // 2
    col = i % 2
    x = cx + col * 265
    y = start_y + 40 + row * 26
    d.text((x, y), item, fill='#b9c4c8', font=font(15))
# artwork using VARNOX menu image
art = root / 'menu-images' / 'varnox-menu-01.jpg'
if not art.exists():
    art = root / 'menu-images' / 'varnox-menu-02.jpg'
if art.exists():
    artwork = ImageOps.fit(Image.open(art).convert('RGB'), (533, 260), method=Image.Resampling.LANCZOS)
else:
    artwork = Image.new('RGB', (533, 260), '#431820')
img.paste(artwork, (cx, 865))
d = ImageDraw.Draw(img)
# pill buttons; client may render these in two or three columns
buttons = [
    'OWNER', 'AI', 'GROUP', 'DESIGN', 'MEDIA', 'FUN',
    'MUSIC', 'TOOLS', 'ALL MENU', 'CATEGORIES', 'WEBSITE', 'OPEN COMMANDS'
]
y0 = 1155
cols, gap = 3, 10
bw, bh = (right - cx - gap * (cols - 1)) // cols, 56
for i, label in enumerate(buttons):
    col, row = i % cols, i // cols
    x = cx + col * (bw + gap)
    y = y0 + row * (bh + 12)
    d.rounded_rectangle((x, y, x + bw, y + bh), radius=27, fill='#151b1f', outline='#566268', width=2)
    bbox = d.textbbox((0, 0), label, font=font(15, True))
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    d.text((x + (bw - tw) / 2, y + (bh - th) / 2 - 2), label, fill='#edf1f2', font=font(15, True))
# WhatsApp composer and explicit preview label
d.rounded_rectangle((22, 1480, 698, 1560), radius=38, fill='#202c32')
d.text((54, 1501), 'Message', fill='#8d9ba1', font=font(22))
d.text((620, 1496), '◉', fill='#e6eef0', font=font(30))
d.text((25, 1575), 'PREVIEW — LIVE VARNOX BOT NOT CHANGED', fill='#9aa7ac', font=font(15, True))
img.save(out, quality=94)
print(out)
