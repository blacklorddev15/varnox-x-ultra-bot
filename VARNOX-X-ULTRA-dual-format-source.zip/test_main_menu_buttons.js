const fs = require('fs');
const assert = require('assert');

const sourcePath = __dirname + '/case-routing-fixed.js';
const source = fs.readFileSync(sourcePath, 'utf8');

assert(source.includes("if (cmd === 'menu')"), 'main menu branch is missing');
assert(source.includes("btn.url('_*~𝐕𝐈𝐒𝐈𝐓 𝐖𝐄𝐁𝐒𝐈𝐓𝐄~*_', menuWebsite)"), 'website button is missing');
assert(source.includes("btn.reply('_*~𝐀𝐋𝐋 𝐌𝐄𝐍𝐔~*_', `${menuPrefix}allmenu_part1`)"), 'All Menu navigation button is missing');
assert(source.includes("btn.list('_*~𝐂𝐀𝐓𝐄𝐆𝐎𝐑𝐈𝐄𝐒~*_', buildCategorySections(menuPrefix))"), 'Categories list button is missing');
assert(source.includes('sendVarnoXInteractiveMenu(sock, jid, menuPayload)'), 'native-flow sender is missing');
assert(source.includes('btn.reply('), 'reply-button builder usage is missing');
assert(source.includes('btn.list('), 'list-button builder usage is missing');
assert(source.includes("id: `${prefix}cat_${category.key}`"), 'category route IDs are missing');
assert(source.includes("cmd === 'categories'"), 'categories route is missing');
assert(source.includes("cmd === 'ownermenu'"), 'owner menu route is missing');

console.log('main_menu_button_test=passed');
console.log('scope=main_menu_only');
console.log('allmenu_pagination=not_executed');
